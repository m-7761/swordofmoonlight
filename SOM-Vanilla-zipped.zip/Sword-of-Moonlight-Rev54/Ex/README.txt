First off, if you're reading this in a web browser, you need to back your url up to http://svn.swordofmoonlight.net/ex/.

This is a dummy folder which exists to bridge the Sword of Moonlight and Sword of Moonlight Ex repositories when broswing online via http://svn.swordofmoonlight.net. 

The Ex repository contains the source code for Ex, which is useful if you want to help develop Ex or think your project could use a customized version of Ex. Most people probably do not fall into this category. If you think you do, or just want to take a look at what makes Ex tick. You will need to follow the following directions.

Please read the rest of this document before following the following directions. You will want to either delete the hidden .svn folder in this folder, or delete this Ex folder entirely and make a new one. Alternatively you can make a new folder for Ex anywhere on your computer or private network. Then you can "checkout" the Ex repository into your new "unversioned" folder from http://svn.swordofmoonlight.net/Sword-of-Moonlight-Ex/.    

Alternatively, the Ex repository is available for browsing at http://svn.swordofmoonlight.net/ex/.

If you'd like to help translate this file. Just add your translation in your favorite language to the end of the file. That is if your language is not represented already. If it is, feel free to improve the translation. Thanks.    