The KING'S FIELD sample files which accompany a Full Sword of Moolight install are ommitted from this repository for a number of reasons. 

You can download the files in 153MB compressed archive form from www(.)swordofmoonlight(.)net/online/SAMPLE/KING%27S%20FIELD(.)zip. Extract the files into this folder.

Alternatively you can extract the contents of PREVIEW.zip into this folder. This is a lightweight version of the KING'S FIELD sample. Absent are the media files. It is necessary to rebuild the .mpx files via the map editor. This archive is readonly and should not be re-committed to the Sword of Moonlight repository.    
