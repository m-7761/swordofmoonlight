/*
Open Asset Import Library (ASSIMP)
----------------------------------------------------------------------

Copyright (c) 2006-2008, ASSIMP Development Team
All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the 
following conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------
*/


//
//! @file Definition of in-memory structures for the Sword of Moonlight
//  MDL file format. Model reverse engineered from the files themselves.
//

#ifndef AI_SOMHELPER_H_INC
#define AI_SOMHELPER_H_INC

#ifndef AI_N
#define AI_N(n) n //! N array elements. For debugging convenience
#endif

namespace Assimp 
{
	struct ComplexScene; 
}

//Psx::Header_TIM, Packet_TMD, PsxHelper::MaterialMatrix
#include "PsxHelper.h"
#include "./../include/Compiler/pushpack1.h" 

namespace Assimp{  

namespace Som{		 

enum //too many compilers whine about the multi-char spec
{
	tile = 1, vert, norm, prim, anim, diff, vram
};

struct Header_MDL
{
	//! 16 bytes
	uint8_t anim_flags; //! perhaps bitwise flags 
	uint8_t num_anims; //! Joint MIMe animation (PSOne)
	uint8_t num_diffs; //! Vertex/normal MIMe animation
	uint8_t num_skins; //! Textures (PSOne TIM image format)
	uint8_t num_parts; //! one or more required (meshes)
	//RENAME ME
	//THIS IS REALLY LOD OR SOMETHING???
	//it's 1 for add_prims, 2 for add_prims2, up to 3
	uint8_t num_tiles; //! perhaps always one
	uint16_t add_prims; //! dword anims block offset (perhaps 16bit)
	uint16_t _add_prims2; //2021: prims2/3 are a mystery
	uint16_t _add_prims3; //! perhaps always zero
	uint16_t add_anims; //! dword sizeof anims block
	uint16_t add_diffs; //! dword sizeof diffs block

	//! this is the actual order of the data blocks in the file
	inline unsigned int offset(int fourcc, int pt=0)const
	{
		switch(fourcc) 
		{							   
		case Som::tile: return 4+7*num_parts;		
		
		case Som::vert: return 4+AI_BE(parts[pt].off_verts);
		case Som::norm: return 4+AI_BE(parts[pt].off_norms);
		case Som::prim: return 4+AI_BE(parts[pt].off_prims);

		case Som::anim: return 4+AI_BE(add_prims);
		case Som::diff: return 4+AI_BE(add_prims)
						        +AI_BE(add_anims);
		case Som::vram: return 4+AI_BE(add_prims)
						        +AI_BE(add_anims)
							    +AI_BE(add_diffs);

		default: return 0x7FFFFFFF;
		}
	}

	struct Part //! 28 bytes (these may actually be 16bit)
	{
	uint32_t off_verts; //! dword offset to vertex block 
	uint32_t num_verts; //!
	uint32_t off_norms; //! dword offset to normal block 
	uint32_t num_norms; //!		
	uint32_t off_prims; //! dword offset to prim block
	uint32_t num_prims; //!
	uint32_t reserve00; //! probably always zero
	}parts[AI_N(24)] PACK_STRUCT;

} PACK_STRUCT;

struct Stream_MDL
{
	uint16_t id;
	uint16_t num_buffs;

	/** Unaligned data storage.
	* First and last 32bit words (two total)
	* align with the rest of file / announce 
	* the size of the block from either end.
	*/
	union Buff //! variable length
	{
		struct
		{
		uint16_t num_words; //in dwords  
		uint16_t hi;
		} PACK_STRUCT;

		uint32_t words[AI_N(64)];
		uint8_t bytes[AI_N(128)];

		unsigned int size()const //in bytes
		{
			//invalid buffer
			if(words[num_words-1]!=num_words) return 0;

			return 4*num_words;
		}

	}buffs PACK_STRUCT;

} PACK_STRUCT;

//! Loosely adapted from PSOne MIME data (maybe?)
struct Motion_MDL 
{		
	//note: unknown01 is an extension mechanism
	//most likely, since it seems to describe the
	//size of this block of data in 4-byte units
	//when read from memory (1 means no extra data)
	uint16_t num_chans; //read as byte
	uint16_t unknown01;	//read as word (always 1)

	Stream_MDL anims;

} PACK_STRUCT;

struct String_MDL
{
	uint16_t id;

	typedef uint16_t Elem;

	struct Diff{ int8_t lo; uint8_t hi;	} PACK_STRUCT;

	union
	{
		Elem elems[AI_N(64)];  
		Diff diffs[AI_N(64)];
	};

	const String_MDL *end(const void *pcEof)const
	{
		const uint16_t *p = elems;

		do{ if((void*)p>pcEof) return NULL; }while(*p++);

		return (const String_MDL*)p;
	}

	inline long long len(const void *pcEof)const
	{
		return ((long long)end(pcEof)-(long long)&elems)/2-1;
	}

} PACK_STRUCT;

struct Frames_MDL
{
	uint16_t num_anims; //perhaps equal to num_diffs in header
	uint16_t off_steps; //dword offset to steps block
	uint16_t unknown00; //perhaps always 0xFE00
	uint16_t unknown01; //perhaps always 0xFEFF

	String_MDL anims;

	struct Step 
	{
		uint16_t off_codes; //byte offset

		uint8_t unknown00; //perhaps always 0

		uint8_t flags[AI_N(24)];

		//see struct Code for interpretation of this pointer
		inline const int8_t *codes(int fourcc)const
		{
			return fourcc==Som::vert?(int8_t*)this+AI_BE(off_codes):NULL;
		}

	} PACK_STRUCT;
	
	const Step *step(int diff, const void *pcEof)const
	{
		diff = diff<0?-diff-1:diff-1; ai_assert(diff>=0);

		const uint16_t *hops = (const uint16_t*)this+2*AI_BE(off_steps);

		if((const void*)(hops+diff)>pcEof||diff>AI_BE(hops[0])*4/2) return NULL;

		return (const Step*)((int32_t*)this+AI_BE(off_steps)+AI_BE(hops[diff]));
	}

	struct Code //comes in 8bit and 16bit flavors
	{
		int8_t small; uint8_t large; 

		inline int magnitude()const
		{ 
			return small&1?small:(int16_t)((uint16_t)large<<8|(uint8_t)small);
		}

		inline int footprint()const
		{
			return small&1?1:2; //8bit or 16bit
		} 
	};

} PACK_STRUCT;

struct Object_MDO //! 20 bytes
{
	 uint8_t blendmode_etc[4]; //8-bit bool
	 uint16_t texture;
	 uint16_t material;
	 uint16_t indices;
	 uint16_t vertices;
	 uint32_t first_index;
	 uint32_t first_vertex;

} PACK_STRUCT;

} // end namespace Som

#include "./../include/Compiler/poppack1.h"

class SomHelper	//actually this is only for MDL files
{
public:

	int sp_gen_connectivity;

	//http://www.swordofmoonlight.net/bbs2/index.php?topic=312.0
	mutable bool modern; int modernizing;

	//
	//! Each funtion implements a different type of data storage logic present.
	//  Pointers are into a memory mapped view of the file. Double pointers are
	//  incremented before return. Fourcc and 'part' arguments define context.
	//
	// Fourcc codes: tile, prim, vert, norm, anim, diff, and vram (eg. 'vram')

	bool header(const Som::Header_MDL*)const;

	const int32_t *offset(const Som::Header_MDL*, int fourcc, int part=0)const;

	bool packet(const Som::Header_MDL*,
				const Psx::Packet_TMD**, int fourcc, int part=0)const;
	bool motion(const Som::Header_MDL*,
				const Som::Motion_MDL*, int fourcc)const;
	bool stream(const Som::Header_MDL*,
				const Som::Stream_MDL**, int fourcc)const;
	bool frames(const Som::Header_MDL*,
				const Som::Frames_MDL*, int fourcc)const;
	bool string(const Som::Header_MDL*,
				const Som::String_MDL**, int fourcc)const;
	bool psxtim(const Som::Header_MDL*,
				const Psx::Header_TIM**)const;

	//! Automatic pointer casting templates

	template<typename t>
	inline const t *offset(const Som::Header_MDL* in, const t** out, int fourcc, int part=0)const
	{		
		const t *off = (const t*)offset(in,fourcc,part); if(out) *out = off; return off;
	}
	template<typename t>
	inline bool packet(const Som::Header_MDL* in, const t** p, int fourcc, int part=0)const
	{		
		return packet(in,(const Psx::Packet_TMD**)p,fourcc,part);
	}	   
	template<typename t>
	inline bool motion(const Som::Header_MDL *in, const t* p, int fourcc)const
	{		
		return motion(in,(const Som::Motion_MDL*)p,fourcc);
	}	   
	template<typename t>
	inline bool stream(const Som::Header_MDL* in, const t** p, int fourcc)const
	{
		return stream(in,(const Som::Stream_MDL**)p,fourcc);
	}
	template<typename t>
	inline bool frames(const Som::Header_MDL *in, const t* p, int fourcc)const
	{		
		return frames(in,(const Som::Frames_MDL*)p,fourcc);
	}	   
	template<typename t>
	inline bool string(const Som::Header_MDL* in, const t** p, int fourcc)const
	{
		return string(in,(const Som::String_MDL**)p,fourcc);
	}
	template<typename t>
	inline bool psxtim(const Som::Header_MDL *in, const t** p)const
	{		
		return psxtim(in,(const Psx::Header_TIM**)p);
	}	   

	SomHelper(const void* eof, aiScene* out = NULL, Assimp::IOSystem *io=NULL);

	~SomHelper(); //flushes pScene
	
	//avoid construction of chunky helper
	static void CheckEof(const void *eof, const void* szPos);
	static void CheckEof(const void *eof, const void* szPos, const char* szFile, unsigned int iLine);

	inline void CheckEof(const void* szPos)const
	{
		CheckEof(pcEof,szPos);
	}
	inline void CheckEof(const void* szPos, const char* szFile, unsigned int iLine)const
	{
		CheckEof(pcEof,szPos,szFile,iLine);
	}

private:
	
	Assimp::IOSystem *pIo;

	mutable aiScene *pScene; 
	
	mutable Assimp::ComplexScene *pScene2; 

	const void* pcEof;

	inline bool Warning(const char *w)const
	{
		if(pScene) DefaultLogger::get()->warn(w); return false;
	}
	inline bool Warning(const std::string &w)const
	{
		if(pScene) DefaultLogger::get()->warn(w.c_str()); return false;
	}

	static const float xinvert;
	static const float yinvert;
	static const float zinvert;
	static const double tminus;

	//! triangle order
	static inline unsigned int T(unsigned int i)
	{
		//want to be reversible
		//switch(i){ case 0: return 1; case 1: return 0; } return i;
		return 2-i;
	}
	//! quadrangle order
	static inline unsigned int Q(unsigned int i)
	{
		/*3-1 should work but it's not. I don't know, maybe TMD quads
		//are ordered unusually?
		//matching T (may break?)
		//switch(i){ case 0: return 1; case 1: return 0; } return i;
		return 3-i;*/
		return i<=1?!i:i;
	}
		
	mutable unsigned short mUCache[256];
	mutable unsigned short mVCache[256];

	//HACK: UV_ext is set ahead of UV
	mutable unsigned int UV_ext; 
	unsigned int UV(uint16_t)const;

	//! returns UV count and clears cache
	unsigned int UVs()const;

	mutable aiVector3D *pTmpUVs;
	mutable unsigned int nTmpUVs;

	struct JntMIMeDiffData
	{	
		union //! rotation/translation
		{
			struct 
			{	
			short dvx,dvy,dvz;
			short dtx,dty,dtz;			
			short dsx,dsy,dsz;
			};

			short data[9];
		};
		short pose[9];

		int parent,children;

		int pivot,fused,spillover; //modern
		int branch; //bool leaf;
		bool root;

		void reset(){ memset(data,0x00,sizeof(data)); dsx=dsy=dsz=128; }
		
		operator aiQuaternion();
		operator aiVector3D();

		void make_keys(aiNodeAnim *ch, int diffmask, double time);

		JntMIMeDiffData()
		{
			int compile[sizeof(pose)==sizeof(data)];
			reset(); memcpy(pose,data,sizeof(pose));			

			parent = 0xFF; children = 0;

			pivot = fused = spillover = 0xFF; 
			
			branch = 0; root = false;

			joint3 = nullptr;
			joint2.reset(); joint2.cur2.w = 0;
		}

		aiVector3D joint;

		//this is a hack system
		JntMIMeDiffData *joint3;
		struct 
		{
			aiVector3D cur,*src;
			aiQuaternion cur2,*src2;

			void reset()
			{
				memset(this,0x00,sizeof(*this));
				cur2.w = 1;
			}

			aiMatrix4x4 mat,inv;

			void build_mat(JntMIMeDiffData *p)
			{
				mat = aiMatrix4x4(cur2.GetMatrix());
				mat.a4 = cur.x;
				mat.b4 = cur.y;
				mat.c4 = cur.z;

				if(p->joint3)
				if(this==&p->joint2)
				mat = p->joint3->joint2.mat*mat;
				else
				mat = p->joint3->modern.mat*mat;
			}
			void build_inv(JntMIMeDiffData *p)
			{
				mat = mat*p->joint2.mat;

				if(p->children) (inv=mat).Inverse();
			}

		}modern,joint2;
	};
	mutable bool assert_suppress;

	mutable bool fused_root;
	mutable unsigned char root,root2,e113_mdl; //KLUDGE
	mutable int spillover;

	mutable unsigned char mNumJntMIMeChannels;
	mutable JntMIMeDiffData *mJntMIMeChannels;

	JntMIMeDiffData &CH(unsigned char ch)const;

	inline unsigned char CHs()const
	{
		return mNumJntMIMeChannels;
	}

	struct VnMIMeDiffData
	{			
		unsigned int dstart; 

		const aiMesh *ostart;

		aiAnimMesh *vstart;

		void reset(); 

		void restart(aiAnimMesh*); 

		const uint8_t *DiffSect; 

		const int8_t *VertSect;
//		const int8_t *NormSect;
				
		int16_t changed; 

		//optimization: Returns new vnum state
		//to be fed back into next difference()
		//call where vertex data is contiguous.
		int difference(int steps, int vnum=0);

		VnMIMeDiffData()
		{
			memset(this,0x00,sizeof(VnMIMeDiffData));
		}
	};

	mutable unsigned char mNumVnMIMeChannels;
	mutable VnMIMeDiffData *mVnMIMeChannels; 

	VnMIMeDiffData &VN(unsigned char vn)const;

	inline unsigned char VNs()const
	{
		return mNumVnMIMeChannels;	
	}

	//! TPN (texture page number) to mMaterialIndex lookup
	mutable unsigned int mFramebuffer[1+32];
	//OVERKILL	
	//2021: copying from PsxHelper.h (time to get serious)
	mutable PsxHelper::MaterialMatrix mMaterialMatrix;
	//Acquire a material index (assuming TMD compatible)
	inline unsigned int N(uint16_t modeflag, uint16_t tsb=0)const 
	{
		//NOTICE 0x100 IS FORCING THE lgt MODE (flat/gouraud/unlit)

		unsigned int &out = mMaterialMatrix.tmd(modeflag|0x100,tsb);

		if(!out) out = 1+pScene2->mNumMaterials++; return out-1;
	}

	aiString *pOverlay;

	mutable int mCPs;
};

} // end namespace Assimp

#endif // ! AI_SOMHELPER_H_INC
