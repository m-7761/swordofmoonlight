																	/*
Open Asset Import Library (ASSIMP)
----------------------------------------------------------------------

Copyright (c) 2006-2010, ASSIMP Development Team
All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the 
following conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------
*/
/** @file Defines generalizable Euler angle routines */
#ifndef AI_EULER_HPP_INC
#define AI_EULER_HPP_INC

#ifndef __cplusplus
#	error This header requires C++ to be used. 
#endif

namespace Assimp	
{
	///////////////////////////////////////////////////////////////////////////
	//   template arguments -
	// H: handedness. possible values, +1 for right handed, -1 for left handed.
	// A: first angle in a Euler angle sequence; 1 for X, 2 for Y, 3 for Z.
	// B: second angle; C, and so on. 
	///////////////////////////////////////////////////////////////////////////

	//! EulerAnglesToQuaternion: 
	// convert Euler angles to quaternion. 

	template<int H, int A, int B, int C>
	void EulerAnglesToQuaternion(const aiVector3D &vIn, aiQuaternion &qOut)
	{			 
	#define vS(X) sinf(vIn.X/2.0f)

		aiQuaternion qAbc[3] = 
		{ 
			aiQuaternion(cosf(vIn.x/2.0f),A==1?vS(x):0,A==2?vS(x):0,A==3?vS(x)*float(H):0),
			aiQuaternion(cosf(vIn.y/2.0f),B==1?vS(y):0,B==2?vS(y):0,B==3?vS(y)*float(H):0),
			aiQuaternion(cosf(vIn.z/2.0f),C==1?vS(z):0,C==2?vS(z):0,C==3?vS(z)*float(H):0)
		};

	#undef vS

		if(!A||!B||!C)
		{
			qOut = qAbc[0]; if(B) qOut = qOut*qAbc[1]; if(C) qOut = qOut*qAbc[2];
		}
		else qOut = qAbc[0]*qAbc[1]*qAbc[2];
	}

	template<int H, int A, int B, int C>
	AI_FORCE_INLINE void EulerAnglesToQuaternion(float a, float b, float c, aiQuaternion &qOut)
	{
		EulerAnglesToQuaternion<H,A,B,C>(aiVector3D(a,b,c),qOut);
	}

	template<int H, int A, int B, int C>
	AI_FORCE_INLINE void EulerAnglesToQuaternion(const float *vIn, aiQuaternion &qOut)
	{
		EulerAnglesToQuaternion<H,A,B,C>(*(const aiVector3D*)vIn,qOut);
	}

	//! EulerAnglesFromQuaternion: 
	// Convert quaternion to Euler angles. Redundant sequences (eg. XYX) are 
	// regarded meaningless and may produce potentially erroneous results.

	template<int H, int A, int B, int C>
	void EulerAnglesFromQuaternion(aiVector3D &vOut, const aiQuaternion &qIn)
	{
		//! assuming normalized
		aiQuaternion qOut(qIn.w,*((float*)&qIn+A),*((float*)&qIn+B),*((float*)&qIn+C));

		float test = qOut.w*qOut.y + qOut.x*qOut.z*float(H);

		//TESTING: these values are producing turbulence (86.3 degrees?)
		//https://www.euclideanspace.com/maths/geometry/rotations/conversions/quaternionToEuler/jack.htm
		//if(test>0.499f) //! singularity at north pole
		//if(test>=0.499995f) //how high is too high? (approaching +0.5)
		if(test>=0.5f) //how high is too high? (approaching +0.5)
		{
			//2020: I'm adding H since I observed the sign is incorrect.
			vOut.x = atan2f(qOut.y,qOut.w)*+2.0f*H;
			vOut.y = AI_MATH_HALF_PI_F;
			vOut.z = 0;

			return;
		}
		//if(test<-0.499f) //! singularity at south pole
		//if(test<=-0.499995f) //how low is too low? (approaching -0.5)
		if(test<=-0.5f) //how low is too low? (approaching -0.5)
		{
			//2020: I'm adding H since I observed the sign is incorrect.
			vOut.x = atan2f(qOut.y,qOut.w)*-2.0f*H;
			vOut.y = -AI_MATH_HALF_PI_F;
			vOut.z = 0;

			return;
		}

		float sqx = qOut.x*qOut.x;
		float sqy = qOut.y*qOut.y;
		float sqz = qOut.z*qOut.z;

		vOut.x = atan2f(2.0f*qOut.w*qOut.x-2.0f*qOut.y*qOut.z*H,1.0f-2.0f*sqx-2.0f*sqy);
		vOut.y = asinf(2.0f*test);
		vOut.z = atan2f(2.0f*qOut.w*qOut.z-2.0f*qOut.x*qOut.y*H,1.0f-2.0f*sqy-2.0f*sqz);
	} 

	template<int H, int A, int B, int C>
	AI_FORCE_INLINE void EulerAnglesFromQuaternion(float &a, float &b, float &c, const aiQuaternion &qIn)
	{
		aiVector3D vTmp; EulerAnglesFromQuaternion<H,A,B,C>(vTmp,qIn);

		a = vTmp.x; b = vTmp.y; c = vTmp.z;
	}

	template<int H, int A, int B, int C>
	AI_FORCE_INLINE void EulerAnglesFromQuaternion(float *vIn, const aiQuaternion &qIn)
	{
		EulerAnglesFromQuaternion<H,A,B,C>(*(aiVector3D*)vIn,qIn);
	}

}
#endif
