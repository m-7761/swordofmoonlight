													 /*
---------------------------------------------------------------------------
Open Asset Import Library (ASSIMP)
---------------------------------------------------------------------------

Copyright (c) 2006-2010, ASSIMP Development Team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/

/** @file ComplexScene.cpp 
 *Implementation of an alternative scene structure that straight forward 
 *formats may find more handy to work with than the aiScene structure.*/

#include "AssimpPCH.h"
#include "ComplexScene.h"

using namespace Assimp;

namespace Assimp
{

class SimplifyProcess
{
	struct SimplifyMeshHelper;

public:
	
	int mGenConnectivity;

	SimplifyProcess(int sp_gen_connectivity)
	{
		//"SP_GEN_CONNECTIVITY"
		mGenConnectivity = sp_gen_connectivity;
		if(mGenConnectivity<=0) mGenConnectivity = -1;
	}

	int SimplifyMesh(const ComplexMesh *pIn, aiMesh** pOut, int iMaxOut)
	{
		int *pGC = mGenConnectivity<0?0:&mGenConnectivity;

		return SimplifyMeshHelper(pGC,pIn,pOut,iMaxOut);
	}
		   	
	static unsigned int CountMaterials(const ComplexMesh*);

	typedef std::pair<unsigned int,unsigned int> range;
	static void NotifyNodes(aiNode*,const std::vector<range> &rearrange);

private:

	struct SimplifyMeshHelper
	{
		/** The input will be decomposed into separate 
		* materials upto iMaxOut count. Any remaining meshes
		* will not be carried over.
		*/
		SimplifyMeshHelper(int *pGC, const ComplexMesh *pIn, aiMesh** pOut, unsigned int iMaxOut);

		~SimplifyMeshHelper();

		inline operator int(){ return iCompleted; }

	protected: 

		struct Parameters
		{	
			union
			{
				//! omitted indices are presently ~0
				unsigned int mIndices[5];

				struct //! for sake of clarity
				{				
				unsigned int mMaterial;
				unsigned int mVertex;
				unsigned int mNormal;
				unsigned int mColor;
				unsigned int mTextureCoords; //or mTextureCoord?				
				};
			};			

			bool mIsUnique;
			bool mIsAssigned;

			unsigned int mNewIndex;

			Parameters *mMoreByVertexIndex; 

			inline bool operator==(const Parameters &o)
			{
				return memcmp(mIndices,o.mIndices,5*sizeof(int))==0;
			}
			inline bool operator!=(const Parameters &o)
			{
				return memcmp(mIndices,o.mIndices,5*sizeof(int))!=0;
			}

			Parameters()
			{
				mMaterial = 0; 

				for(int i=1;i<5;i++) mIndices[i] = ~(unsigned int)0;

				mIsUnique = mIsAssigned = false;

				mNewIndex = ~(unsigned int)0;
			}

		};

		struct Material
		{
			aiMesh *mAssignedSubMesh;

			unsigned int mMaterialIndex;

			unsigned int mNumFacesApplicable;

			Material *mNextInLoop;

			Material(unsigned int iMatIndex, Material *pNext = NULL)
			{
				mMaterialIndex = iMatIndex;

				mNextInLoop = pNext?pNext:this;

				mNumFacesApplicable = 0;

				mAssignedSubMesh = NULL;
			}
		};

		unsigned int mNumBuffered;

		Parameters* mBuffer;

		unsigned int mNumIndexed;

		Parameters** mIndex;

		Material* mMaterials; 

		Material* GetMaterial(unsigned int iMatIndex)
		{
			if(mMaterials==NULL) return mMaterials = new Material(iMatIndex);

			if(mMaterials->mMaterialIndex==iMatIndex) return mMaterials;

			Material *pOut = mMaterials->mNextInLoop;

			while(pOut!=mMaterials&&pOut->mMaterialIndex!=iMatIndex)
				pOut = pOut->mNextInLoop;

			if(pOut==mMaterials) 
				pOut = pOut->mNextInLoop = new Material(iMatIndex,pOut->mNextInLoop);			

			//order could be optimized for meshes with many materials
			return mMaterials = pOut; 
		}

		Parameters* AddParameters(Parameters *pParams)
		{
			//! do not add to index if position parameter is omitted
			if(pParams->mVertex==~(unsigned int)0) return pParams;

			for(Parameters *pIter=mIndex[pParams->mVertex];
							pIter&&pIter->mIsUnique;pIter++)
			{
				if(pIter->mIsUnique==false) break; //reached duplicate so this is unique

				if(*pParams==*pIter)
				{
					while(pIter->mMoreByVertexIndex&&
						pIter->mMoreByVertexIndex->mIsUnique) 
							pIter = pIter->mMoreByVertexIndex;

					ai_assert(pParams->mIsUnique==false);

					pParams->mMoreByVertexIndex = pIter->mMoreByVertexIndex;

					return pIter->mMoreByVertexIndex = pParams;
				}
			}

			pParams->mIsUnique = true;

			pParams->mMoreByVertexIndex = mIndex[pParams->mVertex];

			return mIndex[pParams->mVertex] = pParams;
		}

		const ComplexMesh* pInput;
		
		aiMesh** pOutput;

		unsigned int iMaxOutput;	   
		unsigned int iCompleted;
	};
};

} // end of namespace Assimp

SimplifyProcess::
SimplifyMeshHelper::SimplifyMeshHelper
(int *pGC, const ComplexMesh *pIn, aiMesh** pOut, unsigned int iMaxOut)
{
	memset(this,0x00,sizeof(SimplifyMeshHelper));

	if(pIn==NULL||pOut==NULL||iMaxOut<=0) return;

	pInput = pIn; pOutput = pOut; iMaxOutput = iMaxOut;
		
	//! Are there no position parameters for this mesh?
	if(pIn->HasPositions()==false)
	{	
		//! Set to NULL or create dummy aiMesh? Setting NULL for now.
		pOut[0] = NULL; iCompleted = 1; return;
	}

	mNumIndexed = pIn->mNumVertices; mNumBuffered = 0;	

	for(unsigned int i=0;i<pIn->mNumFaces;i++) 
		mNumBuffered+=pIn->mFaces2[i].mNumCorners;

	if(pIn->mSharedParameters) 
		mNumIndexed+=pIn->mSharedParameters->mNumVertices;

	mBuffer = new SimplifyMeshHelper::Parameters[mNumBuffered];
	mIndex = new SimplifyMeshHelper::Parameters*[mNumIndexed];

	memset(mIndex,0x00,mNumIndexed*sizeof(void*));

	bool bDoNormals       = pIn->HasNormals();
	bool bDoColors        = pIn->HasVertexColors(0);
	bool bDoTextureCoords = pIn->HasTextureCoords(0);

	unsigned int iCurParameters = 0;

	for(unsigned int i=0;i<pIn->mNumFaces;i++) 
	{	
		SimplifyMeshHelper::Parameters *pParams = mBuffer+iCurParameters;

		const ComplexFace* pFace = pIn->mFaces2+i; //! MATERIAL

		GetMaterial(pFace->mMaterialIndex)->mNumFacesApplicable++;
		
		unsigned int iNumCorners = pFace->mNumCorners;

		for(unsigned int j=0;j<iNumCorners;j++)
			pParams[j].mMaterial = pFace->mMaterialIndex;			

#define _AI_ASSERT_FINDFACE2(Ps)\
		{ pFace = pIn->FindFace2(pFace->m##Ps); ai_assert(pFace&&pFace->mNumCorners==iNumCorners); }

		pFace = pIn->mFaces2+i; //! VERTICES

		if(pFace->mParameterModes&aiParameterType_VERTEX) _AI_ASSERT_FINDFACE2(Vertices) 
		
		if(pFace->mVertices!=0) for(unsigned int j=0;j<iNumCorners;j++)
			pParams[j].mVertex = pFace->mIndices[pFace->mVertices+pFace->mStride*j];				
		
		if(bDoNormals){ pFace = pIn->mFaces2+i; //! NORMALS
		
		if(pFace->mParameterModes&aiParameterType_NORMAL) _AI_ASSERT_FINDFACE2(Normals)
	
		if(pFace->mFaceFeatures&aiFaceFeature_NORMAL)
			for(unsigned int j=0;j<iNumCorners;j++) pParams[j].mNormal = pFace->mIndices[0];			
				else if(pFace->mNormals!=0) for(unsigned int j=0;j<iNumCorners;j++) 
					pParams[j].mNormal = pFace->mIndices[pFace->mNormals+pFace->mStride*j];			 			

		}if(bDoColors){ pFace = pIn->mFaces2+i; //! COLORS

		if(pFace->mParameterModes&aiParameterType_COLOR) _AI_ASSERT_FINDFACE2(Colors) 			
		
		if(pFace->mFaceFeatures&aiFaceFeature_COLOR)
			for(unsigned int j=0;j<iNumCorners;j++) pParams[j].mColor = pFace->mIndices[1];			
				else if(pFace->mColors!=0) for(unsigned int j=0;j<iNumCorners;j++) 
					pParams[j].mColor = pFace->mIndices[pFace->mColors+pFace->mStride*j];			 			

		}if(bDoTextureCoords){ pFace = pIn->mFaces2+i; //! TEXTURECOORDS 
			
		if(pFace->mParameterModes&aiParameterType_TEXTURECOORDS) _AI_ASSERT_FINDFACE2(TextureCoords)
			
		if(pFace->mTextureCoords!=0) for(unsigned int j=0;j<iNumCorners;j++)
				pParams[j].mTextureCoords = pFace->mIndices[pFace->mTextureCoords+pFace->mStride*j];				
		}

#undef _AI_ASSERT_FINDFACE2

		for(unsigned int j=0;j<iNumCorners;j++) AddParameters(pParams+j);

		iCurParameters+=iNumCorners;
	}	
	 
	if(mMaterials==NULL) GetMaterial(pIn->mMaterialIndex); 

	SimplifyMeshHelper::Material *pIter = mMaterials;

	unsigned int iNumUV = pIn->GetNumUVChannels();	
	unsigned int iNumVC = pIn->GetNumColorChannels();		

	//! calling GetMaterial() inside this loop will explode in your face
	for(unsigned int i=0;i<iMaxOut;i++)
	{
		pIter->mAssignedSubMesh = pOut[i] = new aiMesh;		

//		pOut[i]->mPrimitiveTypes = pIn->mPrimitiveTypes;
		
		pOut[i]->mFaces = new aiFace[pIter->mNumFacesApplicable];

		for(unsigned int j=0;j<AI_MAX_NUMBER_OF_TEXTURECOORDS;j++)
			pOut[i]->mNumUVComponents[j] = pIn->mNumUVComponents[j];

		pOut[i]->mMaterialIndex = pIter->mMaterialIndex;

		unsigned int iNumVertices = 0;

		bool bHasVertices = false;
		bool bHasNormals = false;
		bool bHasColors = false;
		bool bHasTextureCoords = false;

		for(unsigned int j=0;j<mNumBuffered;j++)
			if(mBuffer[j].mMaterial==pIter->mMaterialIndex&&
				mBuffer[j].mIsUnique==true) 
			{
				if(mBuffer[j].mVertex!=~(unsigned int)0)
					bHasVertices = true;				
				if(mBuffer[j].mNormal!=~(unsigned int)0)
					bHasNormals = true;
				if(mBuffer[j].mColor!=~(unsigned int)0)
					bHasColors = true;
				if(mBuffer[j].mTextureCoords!=~(unsigned int)0)
					bHasTextureCoords = true;

				iNumVertices++;
			}

		if(bHasVertices&&pIn->HasPositions())
			pOut[i]->mVertices = new aiVector3D[iNumVertices];
		if(bHasNormals&&pIn->HasNormals())
			pOut[i]->mNormals = new aiVector3D[iNumVertices];
		if(bHasNormals&&pIn->HasTangentsAndBitangents())
			{ pOut[i]->mTangents = new aiVector3D[iNumVertices];
			pOut[i]->mBitangents = new aiVector3D[iNumVertices]; }

		if(bHasColors)
		for(unsigned int j=0;j<iNumVC;j++)
			pOut[i]->mColors[j] = new aiColor4D[iNumVertices];

		if(bHasTextureCoords)
		for(unsigned int j=0;j<iNumUV;j++)
			pOut[i]->mTextureCoords[j] = new aiVector3D[iNumVertices];

		if(pGC) if(iNumUV<AI_MAX_NUMBER_OF_TEXTURECOORDS)
		{		
			//if !bHasTextureCoords these are moved to 0
			pOut[i]->mNumUVComponents[iNumUV] = 3;
			aiVector3D *gc = new aiVector3D[iNumVertices];
			pOut[i]->mTextureCoords[iNumUV] = gc;
			float x = (float)*pGC;
			for(unsigned k=iNumVertices;k-->0;) gc[k].x = x;			
		}
		else pGC = 0;
		 					
		if(pIn->mNumAnimMeshes)
		{
			pOut[i]->mAnimMeshes = new aiAnimMesh*[pIn->mNumAnimMeshes];

			for(unsigned int j=0;j<pIn->mNumAnimMeshes;j++)
			{
				aiAnimMesh *pAnim = pOut[i]->mAnimMeshes[j] = new aiAnimMesh;

				if(bHasVertices&&pIn->mAnimMeshes[j]->HasPositions())
					pAnim->mVertices = new aiVector3D[pAnim->mNumVertices=iNumVertices];
				if(bHasNormals&&pIn->mAnimMeshes[j]->HasNormals())
					pAnim->mNormals = new aiVector3D[iNumVertices];
				if(bHasNormals&&pIn->mAnimMeshes[j]->HasTangentsAndBitangents())
					{ pOut[i]->mTangents = new aiVector3D[iNumVertices];
					pAnim->mBitangents = new aiVector3D[iNumVertices]; }

				if(bHasColors)
				for(unsigned int k=0;k<iNumVC;k++)
					if(pIn->mAnimMeshes[j]->HasVertexColors(k))
						pAnim->mColors[k] = new aiColor4D[iNumVertices];

				if(bHasTextureCoords)
				for(unsigned int k=0;k<iNumUV;k++)
					if(pIn->mAnimMeshes[j]->HasTextureCoords(k))
						pAnim->mTextureCoords[k] = new aiVector3D[iNumVertices];	   
			}

			pOut[i]->mNumAnimMeshes = pIn->mNumAnimMeshes;
		}

		if(pIter->mNextInLoop==mMaterials) break;

		pIter = pIter->mNextInLoop;
	}
	
	//! Break out the non-unique vertices
	for(unsigned int j=0;j<mNumBuffered;j++)
		if(mBuffer[j].mIsUnique==true&&
			mBuffer[j].mMoreByVertexIndex!=NULL&&
				mBuffer[j].mMoreByVertexIndex->mIsUnique==false)
					mBuffer[j].mMoreByVertexIndex = NULL;	

	iCurParameters = 0;

	for(unsigned int i=0;i<pIn->mNumFaces;i++) 
	{			
		const ComplexFace* pFace = pIn->mFaces2+i;

		aiMesh *pSubMesh = GetMaterial(pFace->mMaterialIndex)->mAssignedSubMesh;

		SimplifyMeshHelper::Parameters *pParams = mBuffer+iCurParameters;

		iCurParameters+=pFace->mNumCorners;

		if(pSubMesh==NULL) continue; //this material will be lost

		if(pParams->mVertex==~(unsigned int)0) continue; //considering degenerate

		aiFace* pNewFace = pSubMesh->mFaces+pSubMesh->mNumFaces;
		
		pNewFace->mIndices = new unsigned int[pFace->mNumCorners];

		for(unsigned int j=0;j<pFace->mNumCorners;j++)
		{
			Parameters *pCmp = mIndex[pParams[j].mVertex];

			while(pCmp!=NULL&&*pCmp!=pParams[j]) 
				pCmp = pCmp->mMoreByVertexIndex; 
			
			ai_assert(pCmp!=NULL&&pCmp->mIsUnique==true);

			if(pCmp->mIsAssigned==false)
			{
				int iThisVert = pSubMesh->mNumVertices++;

#ifdef ASSIMP_BUILD_DEBUG
#define _AI_ASSERT_COND(cond) ai_assert(cond)
#else
#define _AI_ASSERT_COND(cond) (cond) //MSVC2005 warning C4390 (empty control statement)
#endif
				if(pSubMesh->mVertices)
					if(pCmp->mVertex==~(unsigned int)0) 
							pSubMesh->mVertices[iThisVert] = get_qnan();
								else _AI_ASSERT_COND(pIn->GetPosition(pCmp->mVertex,
														pSubMesh->mVertices+iThisVert));
				if(pSubMesh->mNormals)
					if(pCmp->mNormal==~(unsigned int)0) 
							pSubMesh->mNormals[iThisVert] = get_qnan();
								else _AI_ASSERT_COND(pIn->GetNormal(pCmp->mNormal,
														pSubMesh->mNormals+iThisVert));
				if(pSubMesh->mTangents)
					if(pCmp->mNormal==~(unsigned int)0) 
							pSubMesh->mTangents[iThisVert] = get_qnan();
								else _AI_ASSERT_COND(pIn->GetTangent(pCmp->mNormal,
														pSubMesh->mTangents+iThisVert));
				if(pSubMesh->mBitangents) 
					if(pCmp->mNormal==~(unsigned int)0) 
							pSubMesh->mBitangents[iThisVert] = get_qnan();
								else _AI_ASSERT_COND(pIn->GetBitangent(pCmp->mNormal,
														pSubMesh->mBitangents+iThisVert));
				
				if(iNumVC) 
				if(pCmp->mColor==~(unsigned int)0)
					for(unsigned int k=0;k<iNumVC;k++) 
				{
					if(pSubMesh->mColors[k])
						pSubMesh->mColors[k][iThisVert] = 1.0f; 
				}
				else for(unsigned int k=0;k<iNumVC;k++) 
					if(pSubMesh->mColors[k])
						_AI_ASSERT_COND(pIn->GetVertexColor(k,pCmp->mColor,
											pSubMesh->mColors[k]+iThisVert));

				if(iNumUV) 
				if(pCmp->mTextureCoords==~(unsigned int)0)
					for(unsigned int k=0;k<iNumUV;k++)
				{
					if(pSubMesh->mTextureCoords[k])
						pSubMesh->mTextureCoords[k][iThisVert] = get_qnan();				
				}
				else for(unsigned int k=0;k<iNumUV;k++)
					if(pSubMesh->mTextureCoords[k])
						_AI_ASSERT_COND(pIn->GetTextureCoord(k,pCmp->mTextureCoords,
											pSubMesh->mTextureCoords[k]+iThisVert));
#undef _AI_ASSERT_COND

				if(pGC) 
				pSubMesh->mTextureCoords[iNumUV][iThisVert].z = (float)pCmp->mVertex;

				for(unsigned int k=0;k<pIn->mNumAnimMeshes;k++)
				{
					aiAnimMesh *pSubAnim = pSubMesh->mAnimMeshes[k];

					if(pSubAnim->mVertices)
					if(pCmp->mVertex==~(unsigned int)0) 
							pSubAnim->mVertices[iThisVert] = get_qnan();
								else pSubAnim->mVertices[iThisVert] = 
										pIn->mAnimMeshes[k]->mVertices[pCmp->mVertex];
												
					if(pSubAnim->mNormals)
						if(pCmp->mNormal==~(unsigned int)0) 
								pSubAnim->mNormals[iThisVert] = get_qnan();
									else pSubAnim->mNormals[iThisVert] = 
											pIn->mAnimMeshes[k]->mNormals[pCmp->mNormal];
					if(pSubAnim->mTangents)
						if(pCmp->mNormal==~(unsigned int)0) 
								pSubAnim->mTangents[iThisVert] = get_qnan();
									else pSubAnim->mTangents[iThisVert] = 
												pIn->mAnimMeshes[k]->mTangents[pCmp->mNormal];
					if(pSubAnim->mBitangents) 
						if(pCmp->mNormal==~(unsigned int)0) 
								pSubAnim->mBitangents[iThisVert] = get_qnan();
									else pSubAnim->mBitangents[iThisVert] = 
											pIn->mAnimMeshes[k]->mBitangents[pCmp->mNormal];

					if(iNumVC) 
					if(pCmp->mColor==~(unsigned int)0)
						for(unsigned int l=0;l<iNumVC;l++) 
					{
						if(pSubAnim->mColors[l])
							pSubAnim->mColors[l][iThisVert] = 1.0f; 
					}
					else for(unsigned int l=0;l<iNumVC;l++) 
						if(pSubAnim->mColors[l])
							pSubAnim->mColors[l][iThisVert] = 
								pIn->mAnimMeshes[k]->mColors[l][pCmp->mColor];										

					if(iNumUV) 
					if(pCmp->mTextureCoords==~(unsigned int)0)
						for(unsigned int l=0;l<iNumUV;l++)
					{
						if(pSubAnim->mTextureCoords[l])
							pSubAnim->mTextureCoords[l][iThisVert] = get_qnan();				
					}
					else for(unsigned int l=0;l<iNumUV;l++)
						if(pSubAnim->mTextureCoords[l])
							pSubAnim->mTextureCoords[l][iThisVert] = 
								pIn->mAnimMeshes[k]->mTextureCoords[l][pCmp->mTextureCoords];
				}

				pCmp->mNewIndex = iThisVert;
				pCmp->mIsAssigned = true;
			}

			pNewFace->mIndices[j] = pCmp->mNewIndex;
		}

		pNewFace->mNumIndices = pFace->mNumCorners; 
		pSubMesh->mNumFaces++;
	}
	for(unsigned int i=0;i<iMaxOut;i++)
	{
		// HACK: iNumVertices can be signficantly higher than the 
		// final count. I'm unsure why, provided isUnique is true
		// and all vertices are assigned to faces?

		for(unsigned int j=0;j<pOut[i]->mNumAnimMeshes;j++)
		{
			aiAnimMesh *pAnim = pOut[i]->mAnimMeshes[j];

			ai_assert(pAnim->mNumVertices>=pOut[i]->mNumVertices);

			pAnim->mNumVertices = pOut[i]->mNumVertices;
		}
	}

	if(pGC) 
	{
		*pGC++;
		for(unsigned int i=0;i<iMaxOut;i++) if(!pOut[i]->mTextureCoords[0])
		{	
			std::swap(pOut[i]->mNumUVComponents[0],pOut[i]->mNumUVComponents[iNumUV]);
			std::swap(pOut[i]->mTextureCoords[0],pOut[i]->mTextureCoords[iNumUV]);				
		}
	}

	while(pOut[iCompleted]&&++iCompleted<iMaxOut);

	for(unsigned int i=0;i<iCompleted;i++)
		pOut[i]->mName = pIn->mName;
}

SimplifyProcess::
SimplifyMeshHelper::~SimplifyMeshHelper()
{
	if(mBuffer) delete [] mBuffer; 
	if(mIndex) delete [] mIndex; 

	if(mMaterials==NULL) return;

	SimplifyMeshHelper::Material 
		*pIter = mMaterials->mNextInLoop; 

	while(pIter!=mMaterials)
	{
		SimplifyMeshHelper::Material *pDtor = pIter; 
		
		pIter = pIter->mNextInLoop;	delete pDtor;
	}

	delete mMaterials;
}

aiScene *ComplexScene::SimplifyInto(aiScene *out, int sp_gen_connectivity)
{
	ComplexMesh **m2 = mMeshes2;
	unsigned int n2 = mNumMeshes, n = 0; 

	for(unsigned int i=0;i<n2;i++) if(m2[i]) 
	{
		if(m2[i]->mSharedParameters)
			m2[i]->mSharedParameters->mIsShared = true;
	}

	for(unsigned int i=0,j=1;i<n2;i++) if(m2[i]) 
	{
		if(m2[i]->mIsShared) continue;

		if(m2[i]->mNumMaterials==0)
		m2[i]->mNumMaterials = SimplifyProcess::CountMaterials(m2[i]);

		n+=m2[i]->mNumMaterials;
	}
	
	if(n==0&&out==NULL) return this; //probably unsafe

	std::vector<SimplifyProcess::range> rearrange(n2);

	aiMesh** m = new aiMesh*[n]; memset(m,0x00,sizeof(void*)*n);

	SimplifyProcess sp(sp_gen_connectivity);
	for(unsigned int i=0,j=0;i<n2;i++) 
	if(m2[i]&&!m2[i]->mIsShared&&m2[i]->HasFaces2())
	{
		unsigned int k = sp.SimplifyMesh(m2[i],m+j,m2[i]->mNumMaterials); 
		
		if(k==0) goto failure;

		rearrange[i].first = j;
		rearrange[i].second = j+=k;
	}

	goto success;

failure:
	
	for(unsigned int i=0;i<n;i++) if(m[i]) delete m[i];

	if(m) delete [] m; return NULL; 

success:
	
	SimplifyProcess::NotifyNodes(mRootNode,rearrange);

	for(unsigned int i=0;i<n2;i++) if(m2[i]) delete m2[i];

	delete [] m2; mMeshes2 = NULL; mNumMeshes = 0; 

	if(out==NULL) out = new aiScene;

	mMeshes = m; mNumMeshes = n; //copied into out below

	if(out==this) return this; 

	memcpy(out,this,sizeof(aiScene));
	memset(this,0x00,sizeof(ComplexScene)); 

	delete this; return out;
}		

unsigned int SimplifyProcess::CountMaterials(const ComplexMesh *pIn)
{
	if(!pIn->mFaces2) return 0;

	std::set<unsigned int> count; 
	for(unsigned int i=0;i<pIn->mNumFaces;i++)
	count.insert(pIn->mFaces2[i].mMaterialIndex);

	return count.size();
}

void SimplifyProcess::NotifyNodes(aiNode *p, const std::vector<range> &rearrange)
{
	unsigned int nNewMeshes = 0;
	for(unsigned int i=0;i<p->mNumMeshes;i++)
	nNewMeshes+=rearrange[p->mMeshes[i]].second-rearrange[p->mMeshes[i]].first;
	
	if(p->mNumMeshes)
	{
		unsigned int* pNewMeshes = new unsigned int[nNewMeshes];
	
		unsigned int i, j, k, l, m;
		for(i=0,j=0;i<p->mNumMeshes;i++)
		{
			m = rearrange[p->mMeshes[i]].first;
			k = rearrange[p->mMeshes[i]].second-m;

			for(l=0;l<k;l++) pNewMeshes[j+l] = m+l;

			j+=k;
		}

		delete [] p->mMeshes; p->mMeshes = pNewMeshes;

		p->mNumMeshes = j;
	}

	//cleaning out any NULL children for validator

	unsigned int i, j;
	for(i=0,j=0;i<p->mNumChildren;i++)
	{
		if(p->mChildren[i])
		{
			p->mChildren[j] = p->mChildren[i]; 

			NotifyNodes(p->mChildren[j],rearrange);

			j++;
		}
	}

	p->mNumChildren = j;
}
