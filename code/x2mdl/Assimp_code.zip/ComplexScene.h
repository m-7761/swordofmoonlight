/*
Open Asset Import Library (ASSIMP)
----------------------------------------------------------------------

Copyright (c) 2006-2010, ASSIMP Development Team
All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the 
following conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------
*/

/** @file ComplexScene.h 
 *Declaration of an alternative scene structure that straight forward 
 *formats may find more handy to work with than the aiScene structure.*/

#ifndef AI_COMPLEXSCENE_H_INC
#define AI_COMPLEXSCENE_H_INC

#include "../include/aiScene.h"

namespace Assimp
{

enum aiParameterType
{
	aiParameterType_VERTEX   = 0x1,

	aiParameterType_NORMAL   = 0x2,

	aiParameterType_COLOR    = 0x4,

	// or aiParameterType_TEXTURECOORD?
	aiParameterType_TEXTURECOORDS = 0x8,

	_aiParameterType_Force32Bit = 0x9fffffff
}; //! enum aiParameterType

enum aiFaceFeature
{
	aiFaceFeature_NORMAL = 0x1,

	aiFaceFeature_COLOR  = 0x2,
		
	//requires implementation
	aiFaceFeature_TWOSIDED  = 0x4, 

	_aiFaceFeature_Force32Bit = 0x9fffffff
}; //! enum aiFaceFeature

// ------------------------------------------------------------------------------------------------
/** An alternative face structure. A proposal is to call it aiFace2 alongside aiMesh2 and aiScene2. 
 *  Unlike aiFace it can hold seperate indices for all parameters, indicates its own material, and
 *  can include per face elements, such as a single normal or color per face. In addition parameters
 *  can be shared by referencing other faces within the containing CompleMesh structure. All indices
 *  follow the indexing rules of ComplexMesh::GetPosition() and friends.*/
// ------------------------------------------------------------------------------------------------
struct ComplexFace : public aiFace
{
	/** Bitwise combination of the members of the #aiFaceFeature enum.
	* aiFaceFeature_NORMAL: mIndices[0] is face normal index
	* aiFaceFeature_COLOR:  mIndices[1] is face color index
	*
	* aiFaceFeature_TWOSIDED: face will amount to two once simplified
	*/
	unsigned int mFaceFeatures;

	/** Bitwise combination of the members of the #aiParameterType enum.
	 * This specifies whether the corresponding index looks in the mIndices
	 * array when the bits are not set or into another aiFace2 when set.
	 */
	unsigned int mParameterModes;   

	//! one parameter exists per corner per type
	unsigned int mNumCorners; 

	//! offset between like parameter indices
	unsigned int mStride; 

	/** first vertex index into mIndices.
	* mIndices[0] is reserved for the face normal always.
	* Therefore if mVertices, mNormals, etc, is 0 
	* (and the corresponding mParameterModes bit is unset) 
	* the parameter data is taken not to exist.
	*/
	unsigned int mVertices; 

	//! tangents and bitangents overlap
	unsigned int mNormals; 

	//! color channels overlap
	unsigned int mColors; 

	//! uv channels overlap
	unsigned int mTextureCoords;

	//! overrides mesh mMaterialIndex member
	unsigned int mMaterialIndex; 

	//! Default constructor
	ComplexFace()
	{
		mFaceFeatures = 0x00000000;
		mParameterModes = 0x00000000;		

		mNumCorners = mStride = 0;

		mVertices =	mNormals = mColors = mTextureCoords = 0;	

		mMaterialIndex = 0;
	}
};

// ------------------------------------------------------------------------------------------------
/** An alternative mesh structure. A proposal is to call it aiMesh2 alongside aiFace2 and aiScene2. 
 *  Unlike aiMesh the numbers of the different attributes need not be symmetrical. So you can have 
 *  for instance 8 vertices for each corner of a cube, and 6 normals for each face of the cube, one
 *  color for the cube, and so on. The ComplexFace structure is used for faces. Multiple materials
 *  may be applied. The materials are indexed by the faces. A shared parameter space allows sharing 
 *  one set of common mesh data between multiple ComplexMesh structures. The space is not intended 
 *  to be recursive. The number of tangents and bitangent attributes is assumed to be symmetric with 
 *  the number of normals. As are multi-texture coordinates. As are multi-color channels. */
// ------------------------------------------------------------------------------------------------
struct ComplexMesh : public aiMesh 
{	
	//! tangents and bitangents overlap
	unsigned int mNumNormals;

	//! color channels overlap
	unsigned int mNumColors;

	//! uv channels overlap
	unsigned int mNumTextureCoords;

	ComplexFace* mFaces2; 
	
	/** Number of mFaces2 materials
	* Leave this zero and it will be 
	* calculated by the Simplify step.
	* If non-zero on simplification it
	* will be used as an upper bound
	* for the number of output meshes.
	*/
	unsigned int mNumMaterials;

	/** Parameters shared across meshes
	* If set this should be a mesh in the 
	* scene mMeshes2 member. To see how 
	* it works see GetPosition() below.
	*/
	ComplexMesh* mSharedParameters; 

	/** This mesh is a shared mesh
	* Leave this false and it will be
	* calculated by the Simplify step.
	* Shared meshes are not themselves
	* outputted. If non-zero the mesh 
	* will be skipped by the Simplify
	* step regardless.
	*/
	bool mIsShared; 

#define _COMPLEXSCENE_GETPARAMETER(Ps,Ns)\
\
		if(mSharedParameters)\
		{\
			if(pIndex<mSharedParameters->mNum##Ns)\
			{\
				if(mSharedParameters->m##Ps==NULL) return false;\
\
				*pOut = mSharedParameters->m##Ps[pIndex]; return true;\
			}\
			else pIndex-=mSharedParameters->mNum##Ns;\
		}\
		else if(m##Ps==NULL||pIndex>=mNum##Ns) return false;\
\
		*pOut = m##Ps[pIndex]; return true;
	

	inline bool GetPosition(unsigned int pIndex, aiVector3D* pOut)const 
		{ _COMPLEXSCENE_GETPARAMETER(Vertices,Vertices) }

	inline bool GetNormal(unsigned int pIndex, aiVector3D* pOut)const 
		{ _COMPLEXSCENE_GETPARAMETER(Normals,Normals) }

	inline bool GetTangent(unsigned int pIndex, aiVector3D* pOut)const 
		{ _COMPLEXSCENE_GETPARAMETER(Tangents,Normals) }

	inline bool GetBitangent(unsigned int pIndex, aiVector3D* pOut)const 
		{ _COMPLEXSCENE_GETPARAMETER(Bitangents,Normals)	}

	inline bool GetVertexColor(unsigned int pChannel, unsigned int pIndex, aiColor4D* pOut)const 
	{
		if(pChannel>=AI_MAX_NUMBER_OF_COLOR_SETS) return false;

		_COMPLEXSCENE_GETPARAMETER(Colors[pChannel],Colors)	
	}

	//! GetTextureCoords or GetTextureCoord?
	inline bool GetTextureCoord(unsigned int pChannel, unsigned int pIndex, aiVector3D* pOut)const 
	{
		if(pChannel>=AI_MAX_NUMBER_OF_TEXTURECOORDS) return false;

		_COMPLEXSCENE_GETPARAMETER(TextureCoords[pChannel],TextureCoords)	
	}

#undef _COMPLEXSCENE_GETPARAMETER

	/** Find face for shared parameter indices
	* The shared faces are logically mapped to the parameter space
	* but do not constitute part of the mesh. That is they are for
	* referencing parameters only.
	*/
	ComplexFace *FindFace2(unsigned int pIndex)const 
	{
		if(mSharedParameters)
		{
			if(pIndex<mSharedParameters->mNumFaces)
			{
				if(mSharedParameters->mFaces2==NULL) return NULL;

				return mSharedParameters->mFaces2+pIndex; 
			}
			else pIndex-=mSharedParameters->mNumFaces;
		}
		else if(pIndex>mNumFaces||!mFaces2==NULL) return NULL;

		return mFaces2+pIndex;
	}

	unsigned int FindMaterial(unsigned int pIndex)const 
	{
		if(mSharedParameters)
		{
			if(pIndex<mSharedParameters->mNumFaces)
			{
				if(mSharedParameters->mFaces2==NULL) return 0;

				return mSharedParameters->mFaces2[pIndex].mMaterialIndex; 
			}
			else pIndex-=mSharedParameters->mNumFaces;
		}
		else if(pIndex>mNumFaces||!mFaces2==NULL) return 0;

		return mFaces2[pIndex].mMaterialIndex;
	}

	//! Default constructor. Initializes all members to 0
	ComplexMesh()
	{
		mNumNormals = mNumColors = mNumTextureCoords = 0;

		mFaces2 = NULL; mNumMaterials = 0;

		mSharedParameters = NULL;

		mIsShared = false;
	}

	~ComplexMesh()
	{
		if(mFaces2!=NULL) delete [] mFaces2;
	}

#define _COMPLEXSCENE_HASPARAMETERS(TEST,F)\
\
		if(TEST) return true; if(mSharedParameters==NULL) return false;\
\
		return mSharedParameters->Has##F;

	inline bool HasPositions()const
		{ _COMPLEXSCENE_HASPARAMETERS(mVertices!=NULL&&mNumVertices>0,Positions()) }

	//! instead of this use hasFaces2()
	inline bool HasFaces()const{ return false; } 

	inline bool HasFaces2()const
		{ _COMPLEXSCENE_HASPARAMETERS(mFaces2!=NULL&&mNumFaces>0,Faces2()) }

	inline bool HasNormals()const
		{ _COMPLEXSCENE_HASPARAMETERS(mNormals!=NULL&&mNumNormals>0,Normals()) }

	inline bool HasTangentsAndBitangents()const
		{ _COMPLEXSCENE_HASPARAMETERS(mTangents!=NULL&&mBitangents!=NULL&&mNumNormals>0,TangentsAndBitangents()) }

	inline bool HasVertexColors(unsigned int pIndex)const 
	{
		if(pIndex>=AI_MAX_NUMBER_OF_COLOR_SETS) return false; 

		_COMPLEXSCENE_HASPARAMETERS(mColors[pIndex]!=NULL&&mNumColors>0,VertexColors(pIndex)) 	
	}

	inline bool HasTextureCoords(unsigned int pIndex)const
	{ 
		if(pIndex>=AI_MAX_NUMBER_OF_TEXTURECOORDS) return false; 

		_COMPLEXSCENE_HASPARAMETERS(mTextureCoords[pIndex]!=NULL&&mNumTextureCoords>0,TextureCoords(pIndex)) 	
	}
	
#undef _COMPLEXSCENE_HASPARAMETERS

	unsigned int GetNumColorChannels() const 
	{
		unsigned int n = aiMesh::GetNumColorChannels();

		if(mSharedParameters!=NULL) 
			return std::max(n,mSharedParameters->GetNumColorChannels());
				else return n;
	}

	unsigned int GetNumUVChannels() const 
	{
		unsigned int n = aiMesh::GetNumUVChannels();

		if(mSharedParameters!=NULL) 
			return std::max(n,mSharedParameters->GetNumUVChannels());
				else return n;
	}
};					  

// ------------------------------------------------------------------------------------------------
/** An alternative scene structure. A proposal is to call it aiScene2 alongside aiFace2 and aiMesh2. 
 *  It is the same as aiScene, except it deals with ComplexMesh structures instead. It is also never
 *  validated, therefore it is much more lax than aiScene wherever possible. For instance, NULL pointers
 *  throughtout the scene hierarchy will be passed over when the scene is simplified (converted to aiScene)
 *  Simplification happens when SimplifyInto or SimplifyInplace is successfuly called. Afterward
 *  the entire ComplexScene part of the structure will be deleted and or zeroed out. Already allocated 
 *  memory is used whenever possible. All pointers are assumed to be new allocataed.*/
// ------------------------------------------------------------------------------------------------
struct ComplexScene : public aiScene
{
	unsigned int mFlags2;

	/** The array of meshes. 
	*
	* Use the indices given in the aiNode structure to access 
	* this array. The array is mNumMeshes in size.
	*/
	ComplexMesh** mMeshes2;

	/**Populate aiScene members of out with own data and self delete.
	*  This is a one time operation if successful (non-zero return)
	*  Returns output scene if all goes well. Else NULL.
	*  Be warned: Assuming 'this' is new allocated!
	*
	*  TODO: Provide flag to make verbose while simplifying
	*/ 
	aiScene *SimplifyInto(aiScene *out, int sp_gen_connectivity=0);

	/**Converts self to an aiScene. 
	*  ComplexScene members are deleted and zeroed on success (non-zero return)
	*  Returns true if all goes as expected. Else false.
	*/
	bool SimplifyInplace(int sp_gen_connectivity=0)
	{
		return SimplifyInto(this,sp_gen_connectivity)!=NULL?true:false;
	}

	/** Constructor */
	ComplexScene(aiScene *cp) : aiScene(*cp)
	{
		mFlags2 = 0x00000000; mMeshes2 = NULL;
	}
};

} // end of namespace Assimp

#endif // AI_COMPLEXSCENE_H_INC