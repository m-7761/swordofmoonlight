/*
---------------------------------------------------------------------------
Open Asset Import Library (ASSIMP)
---------------------------------------------------------------------------

Copyright (c) 2006-2008, ASSIMP Development Team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/

/** @file Implementation of the Sword of Moonlight helper routines */

/** TODO LIST
* -Break warning/exception strings up so to be less redundant and take up less space
*/

#include "AssimpPCH.h"	   
#ifndef ASSIMP_BUILD_NO_SWORDOFMOONLIGHT_IMPORTER

#include "ComplexScene.h"

// internal headers

#include "../include/Euler.hpp"

#include "SomLoader.h"
#include "SomHelper.h"
#include "PsxHelper.h" 

using namespace Assimp;

//would prefer if was obsolete
#include "TriangulateProcess.h"
#include "MakeVerboseFormat.h"
typedef struct : public TriangulateProcess
{
friend class SomLoader; //future proofing
}Triangulate;
typedef struct : public MakeVerboseFormatProcess
{
friend class SomLoader; //future proofing
}Verbosify;

// --------------------------------------------------------------------------------------
// Include file/line information in debug builds
#ifdef ASSIMP_BUILD_DEBUG
#define _CHECK_EOF(pos) CheckEof(pos,__FILE__,__LINE__)
#else
#define _CHECK_EOF(pos) CheckEof(pos)
#endif

// ------------------------------------------------------------------------------------------------
// Constructor to be privately used by Importer
SomImporter::SomImporter()
{
	x2msm = 0; sp_gen_connectivity = 0;
}

// ------------------------------------------------------------------------------------------------
// Destructor, private as well 
SomImporter::~SomImporter()
{

}

// ------------------------------------------------------------------------------------------------
// Returns whether the class can handle the format of the given file. 
bool SomImporter::CanRead( const std::string& pFile, IOSystem* pIOHandler, bool checkSig) const
{
	const std::string extension = GetExtension(pFile);

	//NOTE: This seems inadequate but unavoidable as (Assimp) is.

	if(extension == "mdl" )	return true;
	if(extension == "mdo" ) return true;
	if(extension == "msm" ) return true;
	if(extension == "mhm" ) return true;

	return false;
}
// ------------------------------------------------------------------------------------------------
// Setup configuration properties
void SomImporter::SetupProperties(const Importer* pImp)
{														
	x2msm = pImp->GetPropertyInteger("SOM_NOT_POSTPROCESSING",0);
	  
	sp_gen_connectivity = pImp->GetPropertyInteger("SP_GEN_CONNECTIVITY",0);

	//MODES:
	//-1: default to 1 or 2 if file name looks like an obj MDL
	//0: make no changes
	//1: keep first animation frame (bool like)
	//2: object mode (discard first animation frame)
	//3: old x2mdl compatibility mode for Debone processed files
	//4: can be for Node based files but I don't think any exist
	modernizing = pImp->GetPropertyInteger("SOM_MODERN_MDL_MODE",-1);

	if(modernizing==-1) //why doesn't Assimp do this?
	{
		const char *ev = getenv("SOM_MODERN_MDL_MODE");
		if(ev&&isdigit(*ev))
		modernizing = strtol(ev,0,10);
	}
}

// ------------------------------------------------------------------------------------------------
// Get a list of all supported extensions
void SomImporter::GetExtensionList(std::set<std::string>& extensions)
{
	extensions.insert( "mdl" );
	extensions.insert( "mdo" );
	extensions.insert( "msm" );
	extensions.insert( "mhm" );
}

// ------------------------------------------------------------------------------------------------
// Imports the given file into the given scene structure. 
void SomImporter::InternReadFile( const std::string& pFile, 
	aiScene* _pScene, IOSystem* _pIOHandler)
{
	pScene     = _pScene;
	pIOHandler = _pIOHandler;

	boost::scoped_ptr<IOStream> file( pIOHandler->Open( pFile));

	// Check whether we can read from the file
	if( file.get() == NULL) {
		throw DeadlyImportError( "Failed to open Sword of Moonlight MDL file " + pFile + ".");
	}

	iFileSize = (unsigned int)file->FileSize();

	// Allocate storage and copy the contents of the file to a memory buffer
	std::vector<unsigned char> buffer(iFileSize+1);
	mBuffer = &buffer[0];
	file->Read( (void*)mBuffer, 1, iFileSize);

	// Append a binary zero to the end of the buffer.
	// this is just for safety that string parsing routines
	// find the end of the buffer ...
	mBuffer[iFileSize] = '\0';

	// Determine the file type and call the appropriate member function

	const std::string extension = GetExtension(pFile);

	//NOTE: The Detect routines return true more or less. 
	//It's Not clear how Assimp would benefit from deep detection as is or where
	//is the right place to do that (hint: probably not here)

	if(extension == "mdo" && DetectFormat_MDO())
	{
		DefaultLogger::get()->debug("Sword of Moonlight MDO format assumed"); //detected

		InternReadFile_MDO(); 
	}
	else if(extension == "msm" && DetectFormat_MSM())
	{
		DefaultLogger::get()->debug("Sword of Moonlight MSM format assumed"); //detected

		InternReadFile_MSM(); 
	}
	else if(extension == "mhm" && DetectFormat_MHM())
	{
		DefaultLogger::get()->debug("Sword of Moonlight MHM format assumed"); //detected

		InternReadFile_MHM(); 
	}
	else if(extension == "mdl" && DetectFormat_MDL()) 
	{
		DefaultLogger::get()->debug("Sword of Moonlight MDL format assumed"); //detected
		
		InternReadFile_MDL(pFile); 
		
/*		//Comment: the following changes are now baked into the vertex positions.
					 
		if(pScene->mRootNode!=NULL) 
		{
			aiMatrix4x4 o; 
			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationZ(AI_MATH_PI_F,o);
			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationY(AI_MATH_PI_F,o);
		}
*/	}
	else	
	{
		// print the magic word to the log file
		throw DeadlyImportError("Unknown Sword of Moonlight format "+pFile);
	}
	
	//NEW: msm2x says to preserve non-triangle polygons.
	if(!x2msm)
	{
		//7/23/2011 This is still required
		//"aiMesh::mVertices[%i] is referenced twice - second time by aiMesh::mFaces[%i]::mIndices[%i]"
		Triangulate T; T.Execute(pScene);
		Verbosify V; V.Execute(pScene);
	}

	// delete the file buffer and cleanup
	AI_DEBUG_INVALIDATE_PTR(mBuffer);
	AI_DEBUG_INVALIDATE_PTR(pIOHandler);
	AI_DEBUG_INVALIDATE_PTR(pScene);
}

// ------------------------------------------------------------------------------------------------
// Check whether we're still inside the valid file range
void SomImporter::CheckEof(const void* szPos)const
{
	if(!szPos||(const unsigned char*)szPos>mBuffer+iFileSize)
	{
		throw DeadlyImportError("Invalid Sword of Moonlight file. The file is too small or contains invalid data");
	}
}

// ------------------------------------------------------------------------------------------------
// Just for debgging purdiffs
void SomImporter::CheckEof(const void* szPos, const char* szFile, unsigned int iLine)const
{
	return SomHelper::CheckEof(mBuffer+iFileSize,szPos,szFile,iLine);
}

MaterialHelper *SomLoader_new_CPs_material()
{
	auto *pMat = new MaterialHelper;

	const int iMode = (int)aiShadingMode_NoShading; 
	pMat->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);
	const int no_cull = 1;
	pMat->AddProperty(&no_cull,1,AI_MATKEY_TWOSIDED);
	//float alpha = 0.7f; //MHM?
	//pMat->AddProperty(&alpha,1,AI_MATKEY_OPACITY);
	float shine = 0.0f;
	pMat->AddProperty(&shine,1,AI_MATKEY_SHININESS);
	aiString name("CP (Control Points)");
	pMat->AddProperty(&name,AI_MATKEY_NAME);
	aiColor4D one(1,1,1,1);
	pMat->AddProperty(&one,1,AI_MATKEY_COLOR_AMBIENT);
	pMat->AddProperty(&one,1,AI_MATKEY_COLOR_DIFFUSE);

	return pMat;	
}

bool SomImporter::DetectFormat_MDO()
{
	return true; //unimplemented
}
 
void SomImporter::InternReadFile_MDO()
{
	/*	
	Texture Count (32bit)
	Texture Names (Zero Terminated Strings)
	Material Count (32bit Aligned)
	Material Color (8 Floats per Element)
	Control Points (4x3 Floats)
	Object Count (32bit)
	Per Object Indices (20 Bytes per Element)
	{
	 Color based blend mode (8bit bool)
		 unused? (24-bits padding?)
	 Texture Number (16bit)
	 Material Number? (16bit) 
	 Triangle Index Count (16bit)
	 Vertex Count (16bit) 
	 Triangle Index Buffer Byte Zero (32bit)
	 Vertex Buffer Byte Zero (32bit)
	}
	Triangle Index Array (16bit per Element)
	Vertices Array (8 Floats per Element)
	{
	 Position (3 Float Vector)
	 Lighting Normal (3 Float Vector)
	 Texture Coords (2 Float Vector)
	}
	*/

	// current cursor position in the file
	const unsigned char* szCurrent = mBuffer;

	_CHECK_EOF(szCurrent+4); //Texture Count

	uint32_t textures = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4;

	uint32_t j = textures;
	for(uint32_t i=4;j&&i<iFileSize;i++) if(mBuffer[i]==0) j--;

	if(j) throw DeadlyImportError("[Sword of Moonlight MDO] Texture name strings exceed file boundary");

	std::vector<std::string> texnames(textures);

	for(uint32_t i=0;i<textures;i++) 
	{
		texnames[i].assign("./");
		texnames[i].append((char*)szCurrent); 
		szCurrent+=texnames[i].size()+1-2;
	}

	if(textures==0) textures = 1; //default texture

	if((szCurrent-mBuffer)%4) szCurrent+=4-(szCurrent-mBuffer)%4; //align

	_CHECK_EOF(szCurrent+4); //Material Count

	uint32_t materials = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4;

	_CHECK_EOF(szCurrent+materials*32); //Material Values

	std::vector< std::pair<aiColor4D,aiColor4D> > matcolor(materials);

	for(uint32_t i=0;i<materials;i++) 
	{
		float *d = (float*)szCurrent, *e = d+4; szCurrent+=32;

		aiColor4D a(AI_BE(d[0]),AI_BE(d[1]),AI_BE(d[2]),AI_BE(d[3]));
		aiColor4D b(AI_BE(e[0]),AI_BE(e[1]),AI_BE(e[2]),AI_BE(e[3]));

		matcolor[i] = std::pair<aiColor4D,aiColor4D>(a,b); 
	}

	if(materials==0) materials = 1; //default material

	//// THIS STUFF LOOKS VESTIGIAL (AS IN NOT USED) /////

	auto &cpmem = *(float(*)[4][3])szCurrent; //2021

	szCurrent+=12*4; //control points

	//NOTE: these are outputted at the very end/last
	int cps = 0; for(int i=0;i<4;i++)
	{
		if(cpmem[i][0]||cpmem[i][1]||cpmem[i][2])
		{
			cps = i+1;
		}
	}

	//////////////////////////////////////////////////////

	_CHECK_EOF(szCurrent+4); //Object Count

	uint32_t objects = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4;

	_CHECK_EOF(szCurrent+objects*20); //Object Descriptors

	std::vector<Som::Object_MDO> objvec(objects);

	ai_assert(sizeof(Som::Object_MDO)==20);

	for(uint32_t i=0;i<objects;i++) 
	{
		Som::Object_MDO o = *(Som::Object_MDO*)szCurrent; 

		#ifdef AI_BUILD_BIG_ENDIAN
		o.texture       = AI_BE(o.texture);
		o.material      = AI_BE(o.material);
		o.indices       = AI_BE(o.indices);
		o.vertices      = AI_BE(o.vertices);
		o.first_index   = AI_BE(o.first_index);
		o.first_vertex  = AI_BE(o.first_vertex);
		#else
		ai_assert(*(uint32_t*)o.blendmode_etc<=1
			//EXPERIMENTAL (EXTENSION?)
		||o.blendmode_etc[1]&&*(uint16_t*)(o.blendmode_etc+2));
		#endif

		//-1: avoid running over end of file
		_CHECK_EOF(mBuffer+o.first_index+o.indices*2);
		_CHECK_EOF(mBuffer+o.first_vertex+o.vertices*32-1); 
		
		objvec[i] = o; szCurrent+=20;
	}

	//bMerging
	//Sword of Moonlight import tools bust models up into pieces; it is not known why[1].
	//False: create separate submeshes. True: merge pieces together by material likeness.
	//2021: [1] it's chunking for the vbuffer that's only 128 vertices (even though 4096
	//is the vbuffer's size it seems that's a mistake from thinking the size should have
	//been set to bytes instead of vertices.)

	//REMINDER: true is crashing??? (FIXED)
	//bool bMerging = false;
	bool bMerging = true; //2021
	
	unsigned int iMatsNecessary = 0;
	unsigned int iMeshesNecessary = 0;

	for(uint32_t i=0;i<textures;i++)
	for(uint32_t j=0;j<materials;j++)
	for(uint32_t x=0;x<2;x++)
	{
		bool bExists = false;

		for(uint32_t k=0;k<objects;k++)
		if(objvec[k].texture==i&&objvec[k].material==j
		&&(objvec[k].blendmode_etc[0]==1)==x)
		{
			iMeshesNecessary++;

			if(!bExists) iMatsNecessary++; 

			if(bMerging) break;

			bExists = true;
		}
	}

	pScene->mRootNode = new aiNode("<assimp_scene_root>");		
	pScene->mRootNode->mChildren = new aiNode*[iMatsNecessary+cps];

	pScene->mMeshes = new aiMesh*[iMeshesNecessary+(cps!=0)];
	pScene->mMaterials = new aiMaterial*[iMatsNecessary+(cps!=0)];

	aiString name;
	for(uint32_t i=0;i<textures;i++)
	for(uint32_t j=0;j<materials;j++)
	for(uint32_t x=0;x<2;x++)
	{
		bool bExists = false; 

		unsigned int iMatIndex = 0;
		unsigned int iNumMeshes = bMerging; //1 //2021
		unsigned int iNumVertices = 0;
		unsigned int iNumTriangles = 0; 

		for(uint32_t k=0;k<objects;k++)
		if(objvec[k].texture==i&&objvec[k].material==j
		&&(objvec[k].blendmode_etc[0]==1)==x)
		{
			if(!bExists) bExists = true;

			if(bMerging)
			{
				iNumTriangles+=objvec[k].indices/3; iNumVertices+=objvec[k].vertices;
			}
			else iNumMeshes++;
		}	
		
		if(!bExists) continue;

		name.length = 
		sprintf(name.data,"Tex #%d Mat #%d Rop #%d",i,j,x);
		aiNode *p = pScene->mRootNode->mChildren
		[pScene->mRootNode->mNumChildren++] = new aiNode(name.data);
		{
			MaterialHelper *p = new MaterialHelper;

			p->AddProperty(&name,AI_MATKEY_NAME);

			const int iMode = (int)aiShadingMode_Gouraud;
			p->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);		

			if(j<matcolor.size()) //???
			{
				p->AddProperty(&matcolor[j].first,1,AI_MATKEY_COLOR_DIFFUSE);
				p->AddProperty(&matcolor[j].second,1,AI_MATKEY_COLOR_EMISSIVE);
				//less dark in assimpview? I guess?
				//const aiColor4D ambient(1,1,1,1);
				//p->AddProperty(&ambient,1,AI_MATKEY_COLOR_AMBIENT);
				p->AddProperty(&matcolor[j].first,1,AI_MATKEY_COLOR_AMBIENT);

				//REFERENCE?
				//I think this was a hack for assimpview... that may not
				//understand alpha on the material color
				//p->AddProperty(&matcolor[j].first.a,1,AI_MATKEY_OPACITY);
			}

			/*2021: additive mode is independent of alpha
			if(matcolor[j].first.a!=1.0f)*/if(x)
			{
				const int iBlend = aiBlendMode_Additive;
				p->AddProperty(&iBlend,1,AI_MATKEY_BLEND_FUNC);
			}

			if(i<texnames.size()) //DESTRUCTIVE (name)
			{
				name = texnames[i];
				p->AddProperty(&name,AI_MATKEY_TEXTURE_DIFFUSE(0));
			}

			ai_assert(pScene->mNumMaterials<iMatsNecessary); //paranoia

			pScene->mMaterials[iMatIndex=pScene->mNumMaterials++] = p;
		}

		p->mParent = pScene->mRootNode; p->mMeshes = new unsigned int[iNumMeshes]; 

		for(unsigned int l=0;l<iNumMeshes;l++)
		pScene->mMeshes[p->mMeshes[p->mNumMeshes++]=pScene->mNumMeshes++] = new aiMesh;		
				
		if(bMerging)
		{
			aiMesh *q = pScene->mMeshes[p->mMeshes[0]];

			q->mFaces = new aiFace[iNumTriangles];

			q->mVertices = new aiVector3D[iNumVertices];
			q->mNormals = new aiVector3D[iNumVertices];

			q->mTextureCoords[0] = new aiVector3D[iNumVertices];
			q->mNumUVComponents[0] = 2;	
		}
		
		unsigned int l = 0;
		for(uint32_t k=0;k<objects;k++)
		if(objvec[k].texture==i&&objvec[k].material==j
		&&(objvec[k].blendmode_etc[0]==1)==x)
		{
			aiMesh *q = pScene->mMeshes[p->mMeshes[l]];

			if(!bMerging)
			{			
				q->mFaces = new aiFace[objvec[k].indices/3];

				q->mVertices = new aiVector3D[objvec[k].vertices];
				q->mNormals = new aiVector3D[objvec[k].vertices];

				q->mTextureCoords[0] = new aiVector3D[objvec[k].vertices];
				q->mNumUVComponents[0] = 2;	
			}
						
			uint16_t *w = (uint16_t*)mBuffer+objvec[k].first_index/2;
			auto iMerged = q->mNumVertices; //2021
			for(uint32_t m=q->mNumFaces,n=0;n<objvec[k].indices;m++,n+=3)
			{
				aiFace *f = q->mFaces+m;

				f->mIndices = new unsigned int[f->mNumIndices=3];

				f->mIndices[1] = iMerged+AI_BE(w[n+0]);
				f->mIndices[0] = iMerged+AI_BE(w[n+1]);
				f->mIndices[2] = iMerged+AI_BE(w[n+2]);
			}
		
			float *v = (float*)mBuffer+objvec[k].first_vertex/4;	
			for(uint32_t m=q->mNumVertices,n=0;n<8UL*objvec[k].vertices;m++,n+=8)
			{					
				q->mVertices[m].x = +AI_BE(v[n+0]);
				q->mVertices[m].y = +AI_BE(v[n+1]);
				q->mVertices[m].z = -AI_BE(v[n+2]);

				q->mNormals[m].x = +AI_BE(v[n+3]);
				q->mNormals[m].y = +AI_BE(v[n+4]);
				q->mNormals[m].z = -AI_BE(v[n+5]);

				q->mTextureCoords[0][m].x = AI_BE(v[n+6]);
				q->mTextureCoords[0][m].y = 1-AI_BE(v[n+7]);
			}

			q->mNumVertices+=objvec[k].vertices;
			q->mNumFaces+=objvec[k].indices/3;
			q->mMaterialIndex = iMatIndex;

			if(!bMerging) l++;
		}
	}

	if(cps) //2021
	{
		auto rn = pScene->mRootNode;

		int mi = pScene->mNumMaterials++;
		pScene->mMaterials[mi] = SomLoader_new_CPs_material();
		auto *rm = new aiMesh;
		rm->mMaterialIndex = mi;
		mi = pScene->mNumMeshes++; //!		
		pScene->mMeshes[mi] = rm;
				
		rm->mFaces = new aiFace[rm->mNumFaces=1];
		rm->mVertices = new aiVector3D[rm->mNumVertices=1];

		rm->mPrimitiveTypes = aiPrimitiveType_POINT;

		auto &f = rm->mFaces[0];
		f.mNumIndices = 1;
		f.mIndices = new unsigned int[1]();

		for(int i=0;i<cps;i++)
		{
			auto *n = new aiNode;
			rn->mChildren[rn->mNumChildren++] = n;
			n->mParent = rn;

			n->mMeshes = new unsigned int[1];
			n->mMeshes[n->mNumMeshes++] = mi;
			
			n->mName.length = sprintf(n->mName.data,"(R%d)",i);

			n->mTransformation.a4 = cpmem[i][0];
			n->mTransformation.b4 = cpmem[i][1];
			n->mTransformation.c4 = -cpmem[i][2];
		}
	}
}

bool SomImporter::DetectFormat_MSM()
{
	return true; //unimplemented
}

void SomImporter::InternReadFile_MSM()
{
	/*	
	Texture Count (16bit)
	Texture Names (Zero Terminated Strings)	
	Vertex Count (16bit)
	Vertices Array (8 Floats per Element)
	{
	 Position (3 Float Vector)
	 Lighting Normal (3 Float Vector)
	 Texture Coords (2 Float Vector)
	}
	SubD Polygon Array (variable length)
	{
		SubD Tree (16bit)
		Texture Index (16bit)
		Vertex Count (16bit)
		Vertex Indices per Count (16bit ea.)
	}
	*/

	// current cursor position in the file
	const unsigned char* szCurrent = mBuffer;

	_CHECK_EOF(szCurrent+2); //Texture Count

	uint32_t textures = AI_BE(*(uint16_t*)szCurrent); szCurrent+=2;

	uint32_t j = textures;
	for(uint32_t i=4;j&&i<iFileSize;i++) if(mBuffer[i]==0) j--;

	if(j) throw DeadlyImportError("[Sword of Moonlight MDO] Texture name strings exceed file boundary");

	//WARNING: this is meant to trim degenerate textures off the end
	//of the list, however if they appear in the middle it fails to
	//maintain a slot there and will come out incorrect/corrupted
	std::vector<std::string> texnames; 
	texnames.reserve(textures);
	while(textures-->0) if(szCurrent[0]) //2022: padding/realignment?
	{
		texnames.push_back("./");
		szCurrent+=texnames.back().append((char*)szCurrent).size()+1-2; 
	}
	else szCurrent++; textures = texnames.size(); //2022: padding/realignment?

	if(textures==0) textures = 1; //default texture
  
	//REMINDER: unlike MDO, MSM is neither 32bit, nor 16bit aligned
	//if((szCurrent-mBuffer)%4) szCurrent+=4-(szCurrent-mBuffer)%4; //align
		
	_CHECK_EOF(szCurrent+2); //Vertex Count

	uint32_t vertices = AI_BE(*(uint16_t*)szCurrent); szCurrent+=2;

	struct vertex{ float pos[3],lit[3],uv[2]; }PACK_STRUCT;

	_CHECK_EOF(szCurrent+vertices*sizeof(vertex)); //Vertices
	
	ComplexScene *pScene2 = new ComplexScene(pScene);  
	{
		ComplexScene *pScene = pScene2; //shadowing

		pScene->mRootNode = new aiNode("<assimp_scene_root>");
		
		pScene->mMaterials = new aiMaterial*[textures];
		for(size_t i=0;i<textures;i++)
		{
			MaterialHelper *p = new MaterialHelper;

			const aiColor4D white(1,1,1,1);
			const int iMode = (int)aiShadingMode_Gouraud; 
			p->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);		
			p->AddProperty(&white,1,AI_MATKEY_COLOR_DIFFUSE);
		
			if(i<texnames.size())
			{
				aiString texname(/*"bmp/"+*/texnames[i]);
				p->AddProperty(&texname,AI_MATKEY_TEXTURE_DIFFUSE(0));
			}

			pScene->mMaterials[pScene->mNumMaterials++] = p;			
		}

		pScene2->mNumMeshes = 1;
		pScene2->mMeshes2 = new ComplexMesh*[1];
		ComplexMesh *pMesh = 
		pScene2->mMeshes2[0] = new ComplexMesh;				
		pMesh->mNumVertices = vertices;
		pMesh->mVertices = new aiVector3D[vertices];
		pMesh->mNumNormals = vertices;
		pMesh->mNormals = new aiVector3D[vertices];
		pMesh->mNumTextureCoords = vertices;		
		pMesh->mNumUVComponents[0] = 2;
		pMesh->mTextureCoords[0] = new aiVector3D[vertices];
		for(size_t i=0;i<vertices;i++)
		{
			const vertex &v = ((vertex*)szCurrent)[i];
			
			pMesh->mVertices[i].x = +AI_BE(v.pos[0]);
			pMesh->mVertices[i].y = +AI_BE(v.pos[1]);
			pMesh->mVertices[i].z = -AI_BE(v.pos[2]);

			pMesh->mNormals[i].x = +AI_BE(v.pos[3]);
			pMesh->mNormals[i].y = +AI_BE(v.pos[4]);
			pMesh->mNormals[i].z = -AI_BE(v.pos[5]);

			pMesh->mTextureCoords[0][i].x = AI_BE(v.uv[0]);
			pMesh->mTextureCoords[0][i].y = 1-AI_BE(v.uv[1]);
		}			
		szCurrent+=vertices*sizeof(vertex);

		struct polygon
		{
			uint16_t subdivs, texID, corners, indices[1];

			const polygon *next()const{ return (polygon*)(indices+corners); }

		}PACK_STRUCT; 
		
		const polygon *p = (polygon*)szCurrent;

		_CHECK_EOF(&p->subdivs+1);
		if(p->subdivs) _CHECK_EOF(&p->corners+1);

		uint16_t *pEnd = (uint16_t*)(mBuffer+iFileSize);
		size_t indices = (iFileSize-(szCurrent-mBuffer))/2;

		const char *ev = getenv("SOM_MSM_DEPTH_MAX");
		unsigned int evm = ev?strtol(ev,0,10):0;

		ComplexFace *pFace;
		if(p->subdivs) for(int pass=1;pass<=2;pass++)
		{
			struct //polystack //swordofmoonlight.h
			{
				#ifndef SWORDOFMOONLIGHT_POLYSTACK
				#define SWORDOFMOONLIGHT_POLYSTACK 2
				#endif
				/*max: 0 for no tessellation, -1UL for full*/
				unsigned int max:SWORDOFMOONLIGHT_POLYSTACK; 
				unsigned int top:SWORDOFMOONLIGHT_POLYSTACK; 
					
				int n[1<<SWORDOFMOONLIGHT_POLYSTACK];

				/*these can now be used in a streaming setup*/
				const polygon *restart; bool tessellate;

				bool operator<<(const polygon *p)
				{	
					if(top==0&&n[0]) return false; //overflow;

					if(restart!=p&&(restart=p)) /*allow restart*/
					{	
					uint16_t next_polygons_subdivs = p->indices[p->corners];

					if(p->subdivs>1) /*ascending subD tree*/
					{				
						n[++top] = p->subdivs; /*can result in overflow*/			

						if(!next_polygons_subdivs) n[top]--; /*leaf-closure*/

						tessellate = next_polygons_subdivs?top-1==max:top-1<=max;
					}
					else if(!next_polygons_subdivs) /*descending subD tree*/
					{
						tessellate = top-1<=max;

						if(top==0||n[top]<=0) /*<=: should never be less than*/
						{
							n[top=0] = 1; /*signal "underflow" overflow*/
						}
						else if(--n[top]==0) /*gather up leaves until..*/
						{
							while(--top&&--n[top]==0); /*closure*/
						}
					}
					else tessellate = top-1==max; 

					}return tessellate; /*assuming nonzero p*/
				}

				inline operator bool() /*return final status and reset*/
				{ 	
					bool ok = top==0&&n[0]==0; top = n[0] = 0; restart = 0; 
					return ok;
				}

			}polystack = {evm,0,0}; //0

			for(p=(polygon*)szCurrent;p->indices<pEnd;p=p->next())
			{
				if(pass==1) _CHECK_EOF(p->indices+p->corners+1);

				if(polystack<<p) if(pass==2)
				{					
					pFace->mStride = 1;
					pFace->mVertices = pFace->mNormals = pFace->mTextureCoords = 1;
					pFace->mNumCorners = p->corners;
					pFace->mNumIndices = 1+p->corners;
					pFace->mIndices = new unsigned int[1+p->corners];
					pFace->mIndices[0] = 0; //face normal?
					for(unsigned int i=1;i<=p->corners;i++) 
					{
						pFace->mIndices[i] = p->indices[p->corners-i];
					}
					pFace->mMaterialIndex = p->texID;
					pFace++;					
				}
				else pMesh->mNumFaces++; //assuming Assimp compatible
			}
			if(pass==1) pFace = 
			pMesh->mFaces2 = new ComplexFace[pMesh->mNumFaces];			

			if(!polystack)
			{
				throw DeadlyImportError("[Sword of Moonlight MSM] Importer failure.");
			}
		}

		pScene->mRootNode->mNumChildren = 1;
		pScene->mRootNode->mChildren = new aiNode*[1];
		aiNode *pOnlyNode = 
		pScene->mRootNode->mChildren[0] = new aiNode;
		pOnlyNode->mParent = pScene->mRootNode;
		pOnlyNode->mNumMeshes = 1;
		pOnlyNode->mMeshes = new unsigned int[1];
		pOnlyNode->mMeshes[0] = 0;
	}

	if(pScene2->SimplifyInto(pScene,sp_gen_connectivity)==NULL) 
	{
		throw DeadlyImportError("[Sword of Moonlight MSM] Importer failure.");
	}	
}

bool SomImporter::DetectFormat_MHM()
{
	return true; //unimplemented
}

void SomImporter::InternReadFile_MHM()
{
	/*	
	int32_t vertcount; 
	int32_t normcount; 
	int32_t facecount;
	int32_t	sidecount;
	int32_t flatcount;
	int32_t cantcount; 
	Vertices Array (3 Floats per Element)
	Normals Array (3 Floats per Element)
	Faces Array 
	{
		int32_t clipmode; 
		float32 box[3][2];	
		int32_t normal;
		int32_t ndexcount;
	}
	Index Array (variable length...)
	*/

	// current cursor position in the file
	const unsigned char* szCurrent = mBuffer;

	_CHECK_EOF(szCurrent+24); //header
	size_t vertcount = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4;
	size_t normcount = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4; 
	size_t facecount = AI_BE(*(uint32_t*)szCurrent); szCurrent+=4; 
	szCurrent+=4*3; //not important

	aiVector3D *vertices = (aiVector3D*)szCurrent; szCurrent+=12*vertcount;
	aiVector3D *normals = vertices+vertcount; szCurrent+=12*normcount;

	uint32_t *face = (uint32_t*)(szCurrent+28);
	uint32_t *index = (uint32_t*)(szCurrent+36*facecount);

	_CHECK_EOF(index+3*facecount); //assuming triangles

	ComplexScene *pScene2 = new ComplexScene(pScene);  
	{
		ComplexScene *pScene = pScene2; //shadowing

		pScene->mRootNode = new aiNode("<assimp_scene_root>");
	
		pScene2->mNumMaterials = 1;
		pScene2->mMaterials = new aiMaterial*[1];		
		{
			//2022: prevent ScenePreprocessor.cpp from adding
			//a bogus "$texture.png" property

			auto *pMat = new MaterialHelper;
			const int iMode = (int)aiShadingMode_Gouraud; 
			pMat->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);
		//	const int no_cull = 1;
		//	pMat->AddProperty(&no_cull,1,AI_MATKEY_TWOSIDED);
		//	float alpha = 0.7f; //MHM?
		//	pMat->AddProperty(&alpha,1,AI_MATKEY_OPACITY);
		//	float shine = 0.0f;
		//	pMat->AddProperty(&shine,1,AI_MATKEY_SHININESS);
			aiString name("MHM polygons");
			pMat->AddProperty(&name,AI_MATKEY_NAME);
			aiColor4D one(0.6f,0.6f,0.6f,0.8f);
			pMat->AddProperty(&one,1,AI_MATKEY_COLOR_AMBIENT);
			pMat->AddProperty(&one,1,AI_MATKEY_COLOR_DIFFUSE);

			pScene2->mMaterials[0] = pMat;
		}

		pScene2->mNumMeshes = 1;
		pScene2->mMeshes2 = new ComplexMesh*[1];
		ComplexMesh *pMesh = 
		pScene2->mMeshes2[0] = new ComplexMesh;				
		pMesh->mNumVertices = vertcount;
		pMesh->mVertices = new aiVector3D[vertcount];
		pMesh->mNumNormals = normcount;
		pMesh->mNormals = new aiVector3D[normcount];
		for(size_t i=0;i<vertcount;i++)
		{
			pMesh->mVertices[i].x = +AI_BE(vertices[i].x);
			pMesh->mVertices[i].y = +AI_BE(vertices[i].y);
			pMesh->mVertices[i].z = -AI_BE(vertices[i].z);
		}
		for(size_t i=0;i<normcount;i++)
		{
			pMesh->mNormals[i].x = +AI_BE(normals[i].x);
			pMesh->mNormals[i].y = +AI_BE(normals[i].y);
			pMesh->mNormals[i].z = -AI_BE(normals[i].z);
		}

		pMesh->mNumFaces = facecount;
		pMesh->mFaces2 = new ComplexFace[facecount];			
		for(size_t i=0;i<facecount;i++,face+=9)
		{
			_CHECK_EOF(index+face[1]);

			ComplexFace f;
			f.mStride = 1;
			f.mVertices = 1;
			f.mFaceFeatures = aiFaceFeature_NORMAL;
			f.mNumCorners = face[1];
			f.mNumIndices = 1+f.mNumCorners;
			f.mIndices = new unsigned int[f.mNumIndices];
			f.mIndices[0] = face[0]; //face normal?
			for(unsigned int j=face[1];j>0;j--) 			
			f.mIndices[j] = *index++;
			pMesh->mFaces2[i] = f;	 
		}

		pScene->mRootNode->mNumChildren = 1;
		pScene->mRootNode->mChildren = new aiNode*[1];
		aiNode *pOnlyNode = 
		pScene->mRootNode->mChildren[0] = new aiNode;
		pOnlyNode->mParent = pScene->mRootNode;
		pOnlyNode->mNumMeshes = 1;
		pOnlyNode->mMeshes = new unsigned int[1];
		pOnlyNode->mMeshes[0] = 0;
	}

	if(pScene2->SimplifyInto(pScene,sp_gen_connectivity)==NULL) 
	{
		throw DeadlyImportError("[Sword of Moonlight MSM] Importer failure.");
	}	
}

bool SomImporter::DetectFormat_MDL()
{
	SomHelper Som(mBuffer+iFileSize); //dry run

	auto pcHeader= (const Som::Header_MDL*)mBuffer; 

	if(!Som.header(pcHeader)) return false;

	//NOTE: Should keep going here...
	//But it's not clear doing so would benefit Assimp as is.

	return true;
}

void SomImporter::InternReadFile_MDL(const std::string &pFile)
{
	ai_assert(pScene!=NULL);

	auto pcHeader = (const Som::Header_MDL*)mBuffer; 

	SomHelper Som(mBuffer+iFileSize,pScene,pIOHandler);
	Som.sp_gen_connectivity = sp_gen_connectivity;
	Som.modernizing = modernizing;
		
	Som.header(pcHeader); ai_assert(pcHeader->num_parts>=1);

	const void* szCurrent = mBuffer;

	_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::tile));

	while(Som.packet(pcHeader,&szCurrent,Som::tile));
	
	for(int i=0;i<pcHeader->num_parts;i++)
	{
		_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::prim,i));

		while(Som.packet(pcHeader,&szCurrent,Som::prim,i));

		_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::vert,i));

		while(Som.packet(pcHeader,&szCurrent,Som::vert,i));
		
		_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::norm,i));

		while(Som.packet(pcHeader,&szCurrent,Som::norm,i));
	}
	if(pcHeader->add_prims) 
	{
		szCurrent =  pcHeader+16+4*pcHeader->add_prims;
	}
	char *save = (char*)szCurrent;

	_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::anim));

	if(1)
	if(pcHeader->add_anims&&pcHeader->num_anims) 
	if(Som.motion(pcHeader,szCurrent,Som::anim))
	{
		//SOM_MODERN_MDL_MODE can control this behavior but it's not 
		//easy for users to deal with
		/*pFile is "$$$___magic___$$$..mdl" when reading from memory
		if(-1==modernizing&&!Som.modern)
		{
			//HACK: many objects (obj) definitely have an extra frame
			//whereas other models appear to use that frame, so files
			//starting with O skip it by default
			auto pos = pFile.rfind('\\');
			if(!++pos) 
			{	
				pos = pFile.rfind('/');
				if(!++pos) pos = 0;
			}
			//NOTE: 1 (true) preserves the frames by default since it
			//is more common and doesn't destroy information.
			Som.modernizing = 1;
			if('o'==::tolower(pFile[pos])) //going further...
			{
				for(int i=1;isdigit(pFile[++pos]);i++)
				{
					if(i==3&&'.'==pFile[1+pos])
					{
						//TODO: known cases
						//switch(strtol(pFile[p-3]))
						{
						//case 245: //spear trap
						//case ?: //almost all doors
						//

						Som.modernizing = 2;
						}
					}
				}
			}
		}*/
		if(-1==modernizing&&!Som.modern)
		{
			Som.modernizing = 1;
		}

		szCurrent = &((const Som::Motion_MDL*)szCurrent)->anims;

	 	while(Som.stream(pcHeader,&szCurrent,Som::anim));
	}		
	if(pcHeader->add_anims) 
	{
		szCurrent = save+4*pcHeader->add_anims;
	}
	save = (char*)szCurrent;

	_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::diff));

	if(pcHeader->add_diffs&&pcHeader->num_diffs) 
	if(Som.frames(pcHeader,szCurrent,Som::diff))
	{
		szCurrent = &((const Som::Frames_MDL*)szCurrent)->anims;

		while(Som.string(pcHeader,&szCurrent,Som::diff));
	}
	if(pcHeader->add_diffs) 
	{
		szCurrent = save+4*pcHeader->add_diffs;
	}

	_CHECK_EOF(Som.offset(pcHeader,&szCurrent,Som::vram));

	while(Som.psxtim(pcHeader,&szCurrent));
}

namespace Assimp{ namespace Som
{
	static void SubmeshNameMDL(unsigned ch, aiString &set);
	static void ChannelNameMDL(unsigned ch, aiString &set);
	static void AnimationIdMDL(unsigned id, aiString &set, int anims = 0); //hint
}}


const float SomHelper::xinvert = +1.0f;
const float SomHelper::yinvert = -1.0f;
const float SomHelper::zinvert = -1.0f;

const double SomHelper::tminus = 0; //-1; 

#if defined(SOMIMP)//&&defined(WIN32)
extern "C" __declspec(dllimport) 
char* __stdcall GetCommandLineA(void);
#endif

SomHelper::SomHelper(const void *eof, aiScene *out, Assimp::IOSystem *io)
{	
	assert_suppress = false;

	sp_gen_connectivity = modernizing = 0;

	modern = root2 = false; root = 0xFF; spillover = 0; //unknown?

	fused_root = false; //0080

	pIo = io;

	pcEof = eof; pScene = out; 
	
	pScene2 = NULL; if(pScene==NULL) return;

	pScene2 = new ComplexScene(out);
	
	*mUCache = *mVCache = 0; pTmpUVs = 0; nTmpUVs = 0; 

	mNumJntMIMeChannels = mNumVnMIMeChannels = 0;

	mJntMIMeChannels = NULL; mVnMIMeChannels = NULL;

	//NOTE: mFramebuffer seems needed to track textures
	memset(mFramebuffer,0x00,sizeof(mFramebuffer));
	memset(&mMaterialMatrix,0x00,sizeof(mMaterialMatrix));

	pOverlay = NULL;

#if defined(SOMIMP)&&defined(WIN32)

	char *sz = GetCommandLineA();

	if(sz)
	for(char *p=sz;*p;p++)
	if(p[0]=='-'&&p[1]=='-')
	if(!strncmp(p,"--somimp-overlay=",17))
	{
		char *q = p+=17; 

		if(*q=='"')
		{
			for(p++,q++;*q&&*q!='"';q++);

			if(*q!='"') break;
		}
		else while(*q&&*q!=' ') q++;
		
		pOverlay = new aiString;		
		memcpy(pOverlay->data,p,q-p);
		pOverlay->data[q-p] = '\0';
		pOverlay->length = q-p;

		break;	
	}

#endif

	mCPs = 1; //assume cyan
}

static void Somimp_overlay(aiScene*,Assimp::IOStream*,int);

static void SomLoader_merge_spillover(aiMatrix4x4 &mat, aiMatrix4x4 &inv, aiNodeAnim *p, aiNodeAnim *q, int d)
{
	//this is an alternative using matrices. ideally it
	//is better to use SomLoader_merge_spillover but I'm
	//more confident this is correct for isolating other
	//variables

	std::vector<std::pair<aiMatrix4x4,aiMatrix4x4>> m(d);
	for(int i=d;i-->0;) 
	m[i].first.d4 = m[i].second.d4 = 0;
	for(int i=p->mNumRotationKeys;i-->0;)
	m[(int)p->mRotationKeys[i].mTime].first = aiMatrix4x4(p->mRotationKeys[i].mValue.GetMatrix());
	for(int i=q->mNumRotationKeys;i-->0;)
	m[(int)q->mRotationKeys[i].mTime].second = aiMatrix4x4(q->mRotationKeys[i].mValue.GetMatrix());	
	for(int pass=1;pass<=2;pass++)
	{
		aiNodeAnim *pq = pass==1?p:q;
		aiMatrix4x4 *ff = pass==1?&m[0].first:&m[0].second;
		for(int j=d-1,i=pq->mNumPositionKeys;i-->0;j++)
		{
			int t = (int)pq->mPositionKeys[i].mTime;
			auto v = pq->mPositionKeys[i].mValue;

			auto *f = ff+t*2; if(!f->d4)
			{
				f->d4 = 1;

				for(int t2=t*2;(t2-=2)>=0;) if(ff[t2].d4)
				{
					*f = ff[t2]; break;
				}
			}
			for(f+=(j-t)*2;j-->=t;f-=2) if(f->d4)
			{
				f->a4 = v.x; f->b4 = v.y; f->c4 = v.z;
			}
		}
		for(int j=d-1,i=pq->mNumScalingKeys;i-->0;j++)
		{
			int t = (int)pq->mScalingKeys[i].mTime;
			auto v = pq->mScalingKeys[i].mValue;

			auto *f = ff+t*2; if(!f->d4)
			{
				f->d4 = 1;

				for(int t2=t*2;(t2-=2)>=0;) if(ff[t2].d4)
				{
					*f = ff[t2]; break;
				}
			}
			for(f+=(j-t)*2;j-->=t;f-=2) if(f->d4)
			{
				for(int i=3;i-->0;) 
				for(int j=3;j-->0;) (*f)[i][j]*=v[i];
			}
		}
	}
	
	p->mNumPositionKeys = 0;
	p->mNumRotationKeys = 0;
	bool scaling = p->mNumScalingKeys||q->mNumScalingKeys;
	p->mNumScalingKeys = 0;
	aiMatrix4x4 x;
	int f = -1, s = -1;
	for(int t=0;t<d;t++) 
	{
		if(m[t].first.d4)
		{
			f = t;

			if(m[t].second.d4)
			{
				s = t;
			}
		}
		else if(m[t].second.d4)
		{
			s = t;
		}
		else continue;

		if(f==-1)
		{
			//ai_assert(0); //match me up //???
			x = inv*(m[t].second*mat);
		}
		else if(s==-1)
		{
			//ai_assert(0);
			x = m[t].first;
		}
		else x = m[f].first*(inv*(m[s].second*mat));

		auto &vab = p->mPositionKeys[p->mNumPositionKeys++];
		auto &qab = p->mRotationKeys[p->mNumRotationKeys++];
		auto &sab = p->mScalingKeys[p->mNumScalingKeys]; //!
		if(scaling) p->mNumScalingKeys++;
		vab.mTime = qab.mTime = sab.mTime = (double)t;
		x.Decompose(sab.mValue,qab.mValue,vab.mValue);
	}	
}

SomHelper::~SomHelper()
{
	if(pScene==NULL) 
	{
		ai_assert(pScene2==NULL); return;
	}
	else if(pScene2==NULL) return;

	if(pTmpUVs) delete [] pTmpUVs;

	if(pOverlay) //add purple triangle mesh
	{
		ComplexMesh *p = 
		pScene2->mMeshes2[pScene2->mNumMeshes++] = new ComplexMesh;

		p->mName = "somimp-overlay";
		
		p->mVertices = new aiVector3D[p->mNumVertices=3];

		const float mmsize = 60; 

		p->mVertices[0] = aiVector3D(-mmsize/1024.0f,mmsize/1024.0f,0);
		p->mVertices[1] = aiVector3D(0,-mmsize/1024.0f,0);
		p->mVertices[2] = aiVector3D(mmsize/1024.0f,mmsize/1024.0f,0);		
		
		p->mColors[0] = new aiColor4D[p->mNumColors=1];

		p->mColors[0][0] = aiColor4D(1.0,0,1.0,1.0); //purple

		p->mNormals = new aiVector3D[p->mNumNormals=1];

		p->mNormals[0] = aiVector3D(0,0,1.0); //forward??

		p->mFaces2 = new ComplexFace[p->mNumFaces=1];

		p->mFaces2[0].mFaceFeatures = 
		aiFaceFeature_NORMAL|aiFaceFeature_COLOR;

		p->mFaces2[0].mIndices = 
		new unsigned int[p->mFaces2[0].mNumIndices=5];

		p->mFaces2[0].mNumCorners = 3;
		
		p->mFaces2[0].mIndices[0] = 0;
		p->mFaces2[0].mIndices[1] = 0;
		p->mFaces2[0].mIndices[2] = 0;
		p->mFaces2[0].mIndices[3] = 1;
		p->mFaces2[0].mIndices[4] = 2;

		p->mFaces2[0].mVertices = 2;
		p->mFaces2[0].mStride = 1;
	}

	aiNode *pRoot = pScene2->mRootNode;

	bool rooted = root!=0xFF; //root?
	unsigned int iMeshes = pScene2->mNumMeshes-1-(pOverlay?1:0);
	int iNodes = iMeshes+rooted+root2+fused_root; //modern?
	assert(iNodes<=iMeshes+1+e113_mdl); //E113.MDL hits it?
	if(modern)
	iNodes = std::max<uint8_t>(iMeshes,mNumJntMIMeChannels);

	pRoot->mChildren = new aiNode*[iNodes+(pOverlay?1:0)];

	memset(pRoot->mChildren,0x00,sizeof(void*)*iNodes);

	for(unsigned int i=0;i<iMeshes;i++)
	{			
		aiNode *pNode = 
		pRoot->mChildren[pRoot->mNumChildren] = new aiNode;

		pNode->mParent = pRoot;

		if(mNumJntMIMeChannels)
		{	
			JntMIMeDiffData &ch = CH(pRoot->mNumChildren);

			if(ch.children)
			pNode->mChildren = new aiNode*[ch.children];			
		}			  
		
		pNode->mMeshes = new unsigned int; 
		
		*pNode->mMeshes = i; pNode->mNumMeshes = 1;

		Som::ChannelNameMDL(pRoot->mNumChildren,pNode->mName);

		pRoot->mNumChildren++;
	}
		
	if(mNumJntMIMeChannels) 
	{
		for(int i=0;pRoot->mNumChildren<iNodes;i++)
		{
			aiNode *pNode = 
			pRoot->mChildren[pRoot->mNumChildren] = new aiNode;

			if(rooted)
			{
				ai_assert(iNodes==iMeshes+1+root2);

				if(root2&&!i) //E113.MDL
				{
					pNode->mChildren = new aiNode*[CH(root).children];

					//YUCK: THIS IS FOR THE FOLLOWING else BLOCK TO CONSUME
					//ASSUMING IT'S NO LONGER NEEDED 
					root = iMeshes;
				}
				else
				{
					pNode->mChildren = new aiNode*[pNode->mNumChildren=1];

					pNode->mChildren[0] = pRoot->mChildren[root];

					pRoot->mChildren[root]->mParent = pNode;
				}
			}
			else
			{
				JntMIMeDiffData &ch = CH(pRoot->mNumChildren);

				pNode->mChildren = new aiNode*[ch.children];
			}

			Som::ChannelNameMDL(pRoot->mNumChildren,pNode->mName);

			pNode->mParent = pRoot;

			pRoot->mNumChildren++;
		}

		unsigned int iN = modern?iNodes:iMeshes; //root?

		for(unsigned int i=0;i<iN;i++)
		{
			int ii = CH(i).parent; 

			if(ii==0xFF) continue; //root

			if(!modern)
			{
				//NOTE: while IS FOR O334.MDL
				//
				// WARNING: what if transform only nodes are deeply nested?
				//
				// This produces a rootless hierarchy; I guess it's left to
				// consumers to sort it out. All that matters is it follows
				// Assimp convention
				//
				while(ii>=iMeshes&&ii!=0xFF)
				{
					if(CH(ii).root)
					{
						ii = iMeshes; break; //E113.MDL
					}
					else
					{
						int cmp = CH(ii).parent;
						
						if(cmp!=0xFF||!fused_root)
						{
							ii = cmp;
						}
						else //fused_root?
						{
							break; //breakpoint
						}
					}
				}
				if(ii==0xFF) continue; //root?
			}

			aiNode *pNode = pRoot->mChildren[i];
			aiNode *qNode = pRoot->mChildren[ii];
			if(CH(i).fused==0xFF) 
			qNode->mChildren[qNode->mNumChildren++] = pNode;
			pNode->mParent = qNode;			
		}
		
		//2020: move to 0,0,0 so there's a logical skeleton
		//
		// NOTE: MDL stores lower nodes in higher positions
		// usually but not always
		//
		std::vector<std::pair<int,int>> chanmap; if(!modern)
		{
			//sort the nodes upstream first so the children
			//have access to parent data in the block below 

			chanmap.resize(iN+1);
			for(int j=iN;j-->0;)
			{
				chanmap[j].second = j;
			}
			chanmap.back() = {-1,-1}; //sentinel

			for(bool stop=false;!stop;)
			{
				stop = true;
				for(int j=iN;j-->0;)
				{
					int pj = CH(j).parent; if(pj>iN)
					{
						if(pj<0xFF) pj = CH(pj).parent;
						if(pj>iN) pj = iN;
					}
					if(chanmap[j].first<=chanmap[pj].first)
					{
						stop = false; chanmap[j].first++;
					}
				}
			}
			chanmap.pop_back();

			std::sort(chanmap.begin(),chanmap.end());

			/*don't need a reverse map in this case
			for(int j=iN;j-->0;) 
			{
				chanmap[chanmap[j].second].first = j;
			}*/	
		}
		if(!modern) for(unsigned int ii=0;ii<iN;ii++)
		{			
			int i = chanmap[ii].second;

			JntMIMeDiffData &ch = CH(i);

			aiNode *pNode = pRoot->mChildren[i];

			//NOTE: this would depend on sorting if
			//not for "joint"
			memcpy(ch.data,ch.pose,sizeof(ch.data));

			//IMPLEMENT ME?
			//0000.mdl and 0001.mdl SFX has 1,1,1
			//which would make their bind frame go
			//down to nearly zero. they don't look
			//like legit SFX models, but I'm unsure
			/*
			 * this is now ignored when reading the
			 * file so that it doesn't interfere in
			 * the animation logic
			 * 
			for(int l=9;l-->6;) if(128!=ch.data[l])
			{
				if(!assert_suppress)
				{
					assert_suppress = true;
					ai_assert(128==ch.data[l]);
				}
				break;
			}*/

			const aiVector3D skel3 = -aiVector3D(ch);

			aiVector3D skel2 = skel3;
			
			for(int l=3;l-->0;) if(ch.data[l]) //E111.MDL?
			{
				//NOTE: I THINK relative rotations ARE SAFE HERE SINCE THIS
				//DEALS WITH THE INVERSE TRANSFORM OF THE GEOMETRY TO 0,0,0
				//I.E. WHAT IF BOTH THE PARENT AND A GRANDCHILD ARE ROTATED
				
				aiQuaternion q = ch;

				for(int j=pScene2->mNumAnimations;j-->0;)				
				if(aiNodeAnim*pChan=pScene2->mAnimations[j]->mChannels[i])
				{
					for(int k=pChan->mNumRotationKeys;k-->0;)
					pChan->mRotationKeys[k].mValue = pChan->mRotationKeys[k].mValue*q;
				}

				skel2 = q.Rotate(skel2); break;
			}		
			aiVector3D skel = skel2;

			if(ch.parent!=0xff)
			{
				JntMIMeDiffData *ch2 = &CH(ch.parent);

				if(ch2->parent!=0xff)
				{
					if(ch2>=&CH(iMeshes)) //root?
					{
						ch2 = &CH(ch2->parent);
					}
					else //maybe want SOM_MODERN_MDL_MODE 3 or 4?
					{
						//maybe unavoidable?
						//o004.mdl (o005 and o006) twisting chests
						//
						// the base part absorbs an initial twist 
						// from the pivot/joint that it shouldn't
						// I'm thinking maybe just fix it by hand
						//
						/*I haven't fixed this, I just had to fix
						//these models by hand
						#ifdef NDEBUG
						#error o004.mdl o005.mdl o006.mdl
						#endif*/
						ai_assert(0);
					}
			
					if(0) //TESTING (OBSOLETE)
					{
						//note: this depends on chanmap since
						//the ch.pose memcpy is the same loop
						skel-=aiVector3D(*ch2);
					}
					else //better but requires sorting
					{
						//in theory this factors in rotations
						skel-=ch2->joint;

						ch.joint = ch2->joint;
					}
				}
			}
			ch.joint+=skel;
			
			pNode->mTransformation.a4 = skel.x;
			pNode->mTransformation.b4 = skel.y;
			pNode->mTransformation.c4 = skel.z;			

			skel-=skel2;
			for(int j=pScene2->mNumAnimations;j-->0;)			
			if(aiNodeAnim*pChan=pScene2->mAnimations[j]->mChannels[i])
			{
				for(int k=pChan->mNumPositionKeys;k-->0;)
				{
					pChan->mPositionKeys[k].mValue+=skel;
				}
			}
		}
		else if(modernizing) //modern?
		{
			for(unsigned int i=0;i<iN;i++)
			{
				JntMIMeDiffData &ch = CH(i);

				aiNode *pNode = pRoot->mChildren[i];

				memcpy(ch.data,ch.pose,sizeof(ch.data));

				//IMPLEMENT ME
				for(int i=9;i-->6;) if(128!=ch.data[i])
				{
					ai_assert(128==ch.data[i]); break;
				}

				const aiVector3D skel = aiVector3D(ch);

				aiQuaternion q = ch;

				pNode->mTransformation = aiMatrix4x4(q.GetMatrix());
				pNode->mTransformation.a4 = skel.x;
				pNode->mTransformation.b4 = skel.y;
				pNode->mTransformation.c4 = skel.z;
			}
		}

		if(modernizing) for(unsigned int i=0;i<iN;i++)
		{
			aiNode *pNode = pRoot->mChildren[i];

			aiMatrix4x4 m = pNode->mTransformation;
			while(pNode=pNode->mParent)
			{
				if(pNode!=pRoot) //TESTING				
				m = pNode->mTransformation*m;
			}

			//E111.MDL animation #15 (attack #3)
			int so = CH(i).spillover; if(0xFF!=so)
			{
				aiMatrix4x4 mm = m; m.Inverse();
				for(int j=pScene2->mNumAnimations;j-->0;)
				if(aiNodeAnim*pChan=pScene2->mAnimations[j]->mChannels[i])
				{
					if(auto&pChan2=pScene2->mAnimations[j]->mChannels[so])
					{
						SomLoader_merge_spillover(mm,m,pChan,pChan2,(int)pScene2->mAnimations[j]->mDuration);
						delete pChan2; pChan2 = nullptr;
					}
				}
				else ai_assert(pChan); //fused?
			}
			else m.Inverse(); //self operating!?

			if(modernizing!=3) //old x2mdl files can use 3
			{
				if(i<iMeshes)
				if(auto*pMesh=pScene2->mMeshes2[i])
				for(int j=pMesh->mNumVertices;j-->0;)
				{
					pMesh->mVertices[j]*=m;
				}
			}
		}

		if(rooted) 
		{
			for(int k=pScene2->mNumAnimations;k-->0;)
			{
				aiAnimation *pAnim = pScene2->mAnimations[k];

				auto &a = pAnim->mChannels[root];
				auto &b = pAnim->mChannels[iMeshes];

				//CORRECT? THE E051.MDL IDLE ANIMATION BREAKS
				//HERE. IT HAS 0 FOR b. I GUESS a HAS GEOMETRY
				//SO IT TAKES PRIORITY.
				if(!b) continue;

				if(a) Som::ChannelNameMDL(iMeshes,a->mNodeName);
				if(b) Som::ChannelNameMDL(root,b->mNodeName);

				std::swap(a,b); //Unnecessary (strictly speaking)
			}
		}

		if(!modern) //fuse?
		{	
			for(unsigned int i=0;i<iN;i++)
			{
				int j = CH(i).fused; if(j!=0xFF)
				{
					ai_assert(j!=root); //HEADS UP?

					auto &ci = pRoot->mChildren[i];

					if(ci->mNumChildren)
					{
						ai_assert(0); //FINISH ME?
					}
					else
					{
						delete ci; ci = NULL;
					}

					auto *cj = pRoot->mChildren[j];
					unsigned int &nm = cj->mNumMeshes;
					auto *swap = cj->mMeshes;
					cj->mMeshes = new unsigned int[nm+1];
					memcpy(cj->mMeshes,swap,nm*sizeof(void*));
					delete swap;
					cj->mMeshes[nm++] = i;
				}
			}
		}

		//NOTE: I think maybe this needs to happen before FindNode below
		//(FindNode crashed)
		pRoot->mNumChildren = 0;
		for(unsigned int i=0;i<iNodes;i++)
		if(pRoot->mChildren[i])
		if(pRoot->mChildren[i]->mParent==pRoot)
		{
			pRoot->mChildren[pRoot->mNumChildren++] = pRoot->mChildren[i];
		}
		for(int k=pScene2->mNumAnimations;k-->0;)
		{
			unsigned int j,&nc = pScene2->mAnimations[k]->mNumChannels;
			for(int i=j=0;i<nc;i++)			
			if(aiNodeAnim*pChan=pScene2->mAnimations[k]->mChannels[i])
			{
				if(!pRoot->FindNode(pChan->mNodeName)) //BLACK MAGIC
				{
					//NEW: a few models are coming out with references
					//to nonexistent nodes (presumably some processing
					//in this file removes them) (assuming this is ok)
					delete pChan; continue;
				}
				pScene2->mAnimations[k]->mChannels[j++] = pChan;
			}
			nc = j;
		}
		
		//FINALLY
		//Removing bind frame... for doors this is
		//definitely a bind frame... it's harder to
		//say for other models, but som_db.exe skips
		//the first two frames unless modified.
		//
		//ARM.MDL's first animation definitely seems
		//to use the first frame in a fluid animation.
		//
		// NOTE: for "modern" models the bind frame is
		// equivalent to the Assimp skeleton. Original
		// models only use their translations to 0,0,0.
		//
		if(modernizing==2||modern&&modernizing)
		{
			aiVector3D dv,ds; aiQuaternion dq;

			auto pAnim = pScene2->mAnimations[0];
			pAnim->mDuration--;
			for(int l=pAnim->mNumChannels;l-->0;)
			{
				auto pChan = pAnim->mChannels[l];

				//YUCK: zeroing the keys isn't working 
				//either (November)
				/*FAILS WITH FindNode REORDERING ABOVE 
				aiNode *pn = pRoot->mChildren[l];
				assert(pn->mName==pChan->mNodeName);
				*/
				
				//I think this is rightly a problem
				//for the client to solve
				//auto &pm = pn->mTransformation;				
				//aiVector3D *pv=0,*ps=0; aiQuaternion *pq=0;

				int nc = pChan->mNumPositionKeys;
				auto p = pChan->mPositionKeys;
				/*/*REMOVE ME? aiAnimBehaviour_CONSTANT?
				if(nc>1&&p[1].mTime>1) //2021
				{
					//seems these are retaining the 
					//unbound transforms?
					//p->mValue.Set(0,0,0); //May
					pv = &p->mValue;

					p->mTime = 1; //...
				}*/
				if(nc&&!p->mTime)
				memmove(p,p+1,--nc*sizeof(*p));
				while(nc-->0) p[nc].mTime--;

				nc = pChan->mNumRotationKeys;
				auto r = pChan->mRotationKeys;
				/*/*REMOVE ME?
				if(nc>1&&r[1].mTime>1) //2021
				{
					//r->mValue = aiQuaternion(); //May
					pq = &r->mValue;

					r->mTime = 1; //...
				}*/
				if(nc&&!r->mTime)
				memmove(r,r+1,--nc*sizeof(*r));
				while(nc-->0) r[nc].mTime--;

				nc = pChan->mNumScalingKeys;
				auto s = pChan->mScalingKeys;
				/*REMOVE ME?
				if(nc>1&&s[1].mTime>1) //2021				
				{
					//s->mValue.Set(1,1,1); //May
					ps = &s->mValue;

					s->mTime = 1; //...
				}*/
				if(nc&&!s->mTime)
				memmove(s,s+1,--nc*sizeof(*s));
				while(nc-->0) s[nc].mTime--;

				/*REMOVE ME?
				if(pv||pq||ps)
				{
					pm.Decompose(ds,dq,dv);
					if(pv) *pv = dv;
					if(pq) *pq = dq;
					if(ps) *ps = ds;
				}*/
			}
		}

		//2022: It seems som_db.exe is ignoring the last frame. This is
		//probably both for looping, but also because it's very tricky
		//to round-trip step frames if the last frame is stripped out
		//of the input data from the editor (NOTE: this doesn't apply
		//to soft animations... their frames aren't step and variable.
		//in their case som_db.exe seems to add a dummy frame to their
		//length so that the ignoring pattern works out.)
		for(int k=pScene2->mNumAnimations;k-->0;)
		{
			//NOTICE: it's important to not do this to soft animations
			auto *anim = pScene2->mAnimations[k];
			assert(!anim->mMeshChannels);
			anim->mDuration--;
		}
	}

	if(0) //pull out presentation only root node
	{
		ai_assert(pScene2->mRootNode->mNumChildren==1);

		aiNode *pull = pScene2->mRootNode;

		pScene2->mRootNode = pull->mChildren[0];

		pScene2->mRootNode->mParent = 0;

		*pull = aiNode();

		delete pull;
	}
		
	if(mJntMIMeChannels!=NULL) delete [] mJntMIMeChannels;

	if(mVnMIMeChannels!=NULL) delete [] mVnMIMeChannels;
	 	
	if(pOverlay) 
	{
		aiNode *p = 			
		pScene2->mRootNode->mChildren[pScene2->mRootNode->mNumChildren++] 
			= new aiNode("<somimp_overlay>");

		p->mParent = pScene2->mRootNode;
	}
		
	
	//UNNECESSARY clear bogus TSB fields from mMaterialIndex
	if(ComplexMesh*pShared=pScene2->mMeshes2[pScene2->mNumMeshes-1]) //shared mesh
	{
		ComplexFace *pFaces = pShared->mFaces2;
		
		for(int i=pShared->mNumFaces;i-->0;) pFaces[i].mMaterialIndex = 0;
	}	
	//FIX ME: CAN'T throw INSIDE DESTRUCTOR
	if(pScene2->SimplifyInto(pScene,sp_gen_connectivity)==NULL) 
	{
		throw DeadlyImportError("[Sword of Moonlight MDL] Importer failure.");
	}
	
	aiColor4D one(1,1,1,1), _one(-1,-1,-1,1);

	MaterialHelper *pMat = 0; //PsxLoader.cpp

	if(!pScene->mNumMaterials) pScene->mNumMaterials = 1; //PARANOIA

	pScene->mMaterials = new aiMaterial*[pScene->mNumMaterials];

	//assert(pScene->mNumMaterials>=1);
	{	
		pScene->mMaterials[0] = SomLoader_new_CPs_material();	
	}

	for(int i=0;i<33;i++) for(int j=0;j<5;j++) for(int k=2;k<3;k++) //0
	{
		unsigned int n = mMaterialMatrix.tpn[i].abr[j].lgt[k]; if(!n--) continue;

		pScene->mMaterials[n] = pMat = new MaterialHelper;
		
		/*TODO: might want to restore this? (and k above)
		//technically MDL does have modes like this (I think) but I don't
		//they're stored in its modeflags (but maybe so?)
		int iMode = aiShadingMode_Flat;
		if(k) iMode = k==1?aiShadingMode_Gouraud:aiShadingMode_NoShading;*/
		int iMode = aiShadingMode_Gouraud;
		pMat->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);

		int iBlend = 
		j==0||j==4?aiBlendMode_Default:aiBlendMode_Additive;
		if(j==0||j==3)
		{
			float alpha = j?0.25f:0.5f; 
			pMat->AddProperty(&alpha,1,AI_MATKEY_OPACITY);
		}
		pMat->AddProperty(&iBlend,1,AI_MATKEY_BLEND_FUNC);
		pMat->AddProperty(j==2?&_one:&one,1,AI_MATKEY_COLOR_AMBIENT);
		pMat->AddProperty(j==2?&_one:&one,1,AI_MATKEY_COLOR_DIFFUSE);
		
		char tpn[33]; _itoa(i,tpn,10);
		std::string strname = i==32?"Tex-less":"Tex Pg #";

		if(i<32)
		{
			strname+=tpn;

			int tim = mFramebuffer[1+i]-1;

			if(tim==-1) tim = 0; //???

			if(pScene->mNumTextures==0) //default texture?
			{		
				ai_assert(pScene->mTextures==NULL);
				pScene->mTextures = new aiTexture*[1];
				aiTexture *pTex = pScene->mTextures[0] = new aiTexture;
				pTex->mWidth = pTex->mHeight = 16;
				pTex->pcData = new aiTexel[16*16];
				memset(pTex->pcData,0xFF,16*16*4);
				pScene->mNumTextures++; 
			}
			assert(tim<pScene->mNumTextures);

			char embeddedtexname[34];
			sprintf(embeddedtexname,"*%d",tim);
			aiString texname(embeddedtexname);
			pMat->AddProperty(&texname,AI_MATKEY_TEXTURE_DIFFUSE(0));
		}

		switch(j)
		{
		case 0: strname+=" 50+50"; break;
		case 1: strname+=" 100+100"; break;

		/*Subtractive?
		*+  DestColor*1 - SourceColor*1
		*/
		case 2: strname+=" 100-100"; break;

		/*aiBlendMode_Additive
		*+  SourceColor*SourceAlpha + DestColor*1
		*/
		case 3: strname+=" 100+25"; break;
		}

		/*TODO: restore this and above?
		switch(k)
		{
		case 0: strname+=" Flat"; break;
		case 1: strname+=" Gouraud"; break;
		case 2: strname+=" Unlit"; break;
		}*/

		strname+=" Mat";

		aiString name(strname);
		pMat->AddProperty(&name,AI_MATKEY_NAME);	
	}	
	for(unsigned int i=0;i<pScene->mNumMeshes;i++)
	{
		aiMesh *pMesh = pScene->mMeshes[i];

		if(pMesh->mMaterialIndex==0) continue; //default material

		if(pMesh->mTextureCoords[0])
		{
			auto pMat = pScene->mMaterials[pMesh->mMaterialIndex];

			aiString path;
			if(!pMat->GetTexture(aiTextureType_DIFFUSE,0,&path)&&path.data[0]=='*')
			{
				int tim = strtol(path.data+1,0,10);

	 			aiTexture *pTex = pScene->mTextures[tim];

				float x = 1.0f/pTex->mWidth;
				float y = -1.0f/pTex->mHeight;

				for(unsigned int j=0;j<pMesh->mNumVertices;j++)
				{
					pMesh->mTextureCoords[0][j].x*=x;
					pMesh->mTextureCoords[0][j].y*=y;

					//2018: I think this helps with Blender for editing after
					pMesh->mTextureCoords[0][j].y+=1.0f;
				}
			}
			else
			{
				float qNaN = get_qnan();
				for(unsigned int j=0;j<pMesh->mNumVertices;j++)
				{
					pMesh->mTextureCoords[0][j].x = qNaN;
					pMesh->mTextureCoords[0][j].y = qNaN;
				}
			}
		}
	}

	if(pOverlay) 
	{
		Assimp::IOStream *cp = pIo->Open(pOverlay->data,"rb");

		if(cp) Somimp_overlay(pScene,cp,mCPs);
		if(cp) pIo->Close(cp);			

		delete pOverlay;
	}
}									   

static void Somimp_overlay(aiScene *p, Assimp::IOStream *f, int cps)
{
	if(cps<=0||!p->HasAnimations()) return;

	aiNode *pNode = 
	p->mRootNode->FindNode("<somimp_overlay>");

	if(!pNode) return;

	f->Seek(0,aiOrigin_END); size_t sz = f->Tell();
	f->Seek(0,aiOrigin_SET);
	
#ifdef AI_BUILD_BIG_ENDIAN
#define _(read,N) if(f->Read(read,4,N)!=N) goto incompatible;\
	for(int i=0;i<N;i++) read[i] = AI_BE(read[i])
#else 
#define _(read,N) if(f->Read(read,4,N)!=N) goto incompatible
#endif

	uint32_t head[34], lead[24]; float read[3];

	_(head,34); if(head[0]!=p->mNumAnimations) goto incompatible;

	if(p->mNumAnimations>24) goto incompatible;

	_(lead,p->mNumAnimations);

	size_t sumtimeofanis = 0;
	for(unsigned int i=0;i<p->mNumAnimations;i++)
	{
		if(sumtimeofanis*12!=lead[i]) goto incompatible;

		sumtimeofanis+=size_t(p->mAnimations[i]->mDuration+1);
	}

	//warning! assuming same for all animations
	unsigned int cyanchan = p->mAnimations[0]->mNumChannels; 

	pNode->mChildren = new aiNode*[cps];

	for(int i=1;i<34&&i<=cps;i++)
	{
		if(head[i]==0xFFFFFFFF) continue; //a hole

		aiNode *qNode = new aiNode;

		if(_itoa(i,qNode->mName.data,10))
		qNode->mName.length = strlen(qNode->mName.data);
		
		qNode->mMeshes = new unsigned int[qNode->mNumMeshes=1];

		//warning! assuming the purple triangle
		qNode->mMeshes[0] = p->mNumMeshes-1; 

		pNode->mChildren[pNode->mNumChildren++] = qNode;

		qNode->mParent = pNode;

		f->Seek(head[i],aiOrigin_SET);

		for(unsigned int j=0;j<p->mNumAnimations;j++)
		{
			aiAnimation *pAnim = p->mAnimations[j];
			
			aiNodeAnim *pChan =
			pAnim->mChannels[pAnim->mNumChannels++] = new aiNodeAnim;

			pChan->mInterpolate = aiAnimInterpolate_NONE;

			aiNodeAnim *pCyan =	pAnim->mChannels[cyanchan];

			pChan->mNodeName = qNode->mName;

			pChan->mPositionKeys = 
			new aiVectorKey[pChan->mNumPositionKeys=size_t(pAnim->mDuration+1)];

			for(unsigned int k=0;k<pChan->mNumPositionKeys;k++)
			{
				_(read,3); 
				pChan->mPositionKeys[k].mValue.x = read[0]*+1.0f; 
				pChan->mPositionKeys[k].mValue.y = read[1]*+1.0f; 
				pChan->mPositionKeys[k].mValue.z = read[2]*-1.0f; 
				pChan->mPositionKeys[k].mTime = double(k)-1;

				if(pChan!=pCyan)
				pChan->mPositionKeys[k].mValue+=
				pCyan->mPositionKeys[k].mValue;
			}
		}
	}

#undef _

	goto close;

incompatible:

	//quiet warning message goes here

close: 
	
	if(pNode->mChildren)
	if(!pNode->mNumChildren)
	{
		delete [] pNode->mChildren;

		pNode->mChildren = 0;
	}
}

// ------------------------------------------------------------------------------------------------
// Check whether we're still inside the valid file range
void SomHelper::CheckEof(const void *eof, const void* szPos) //static
{
	if(!szPos||(const unsigned char*)szPos>eof)
	{
		throw DeadlyImportError("Invalid Sword of Moonlight file. The file is too small or contains invalid data");
	}
}

// ------------------------------------------------------------------------------------------------
// Just for debgging purdiffs
void SomHelper::CheckEof(const void *eof, const void* szPos, const char* szFile, unsigned int iLine) //static
{
	ai_assert(eof!=NULL);

	if(!szPos||(const unsigned char*)szPos>eof)
	{
		// remove a directory if there is one
		const char* szFilePtr = ::strrchr(szFile,'\\');
		if (!szFilePtr)	{
			if(!(szFilePtr = ::strrchr(szFile,'/')))
				szFilePtr = szFile;
		}
		if (szFilePtr)++szFilePtr;
						  
		char szBuffer[1024];
		::sprintf(szBuffer,"Invalid Sword of Moonlight file. The file is too small "
			"or contains invalid data (File: %s Line: %i)",szFilePtr,iLine);

		throw DeadlyImportError(szBuffer);
	}
}

bool SomHelper::header(const Som::Header_MDL *in)const
{
	ai_assert(pcEof!=NULL);

	if(!AI_BE(in->num_parts))
	{	
		if(pScene) throw DeadlyImportError("[Sword of Moonlight MDL] A MDL must contain at least one model");

		return false;
	}

	if(!pScene) return true;

	pScene2->mNumMaterials = 1;

	ai_assert(pScene2->mNumMeshes==0);

	pScene2->mNumMeshes = AI_BE(in->num_parts)+1; //1: shared mesh

	pScene2->mMeshes2 = new ComplexMesh*[pScene2->mNumMeshes+(pOverlay?1:0)]; 

	memset(pScene2->mMeshes2,0x00,sizeof(void*)*pScene2->mNumMeshes);
		
	//temporary: scheduled obsolete
	pScene2->mRootNode = new aiNode("<assimp_scene_root>");

	return true;
}

const int32_t *SomHelper::offset(const Som::Header_MDL *in, int cc, int pt)const
{		
	return (const int32_t*)(in?(const char*)in+in->offset(cc,pt)*4:NULL);
}

unsigned int SomHelper::UV(uint16_t in)const
{
	//Need short for UV_ext
	short u = in&0xFF, v = 0xFF&(in>>8); //int8_t
	 	
	//2020: this stretches the texture out to the edge
	if(UV_ext&0xc00)
	{
		if(UV_ext&0x400) u++;
		if(UV_ext&0x800) v++;
		UV_ext>>=2;
	}

	int i;

	for(i=*mVCache!=0?255:*mUCache;i!=0;i--) 
	if(mUCache[i]==u&&mVCache[i]==v) 
	if(i<=*mUCache)
	{
		//return 255UL**mVCache+i-1;
		i = 255UL**mVCache+i-1;
		goto ret;
	}
	else
	{
		//return 255UL**mVCache-255+i-1;
		i = 255UL**mVCache-255+i-1;
		goto ret;
	}

	if(mUCache[0]++==255) 
	{
		*mVCache+=1; *mUCache = 1; 
	}

	mUCache[*mUCache] = u; mVCache[*mUCache] = v;

	//return 255UL**mVCache+*mUCache-1;
	i = 255UL**mVCache+*mUCache-1;

ret: //2020: must now do here for UV_ext

	pTmpUVs[i] = aiVector3D(u,v,0.0f); return i;
}

unsigned int SomHelper::UVs()const
{ 
	unsigned int iOut = 255UL**mVCache+*mUCache;

	*mUCache = *mVCache = 0; return iOut;
}

bool SomHelper::packet(const Som::Header_MDL *in, 
					   const Psx::Packet_TMD **inout, int cc, int pt)const
{
	ai_assert(pScene&&pcEof);

	const Psx::Packet_TMD *p = *inout;
		
	pScene2->mFlags2|=AI_SCENE_FLAGS_INCOMPLETE; 

	ai_assert(pScene2!=NULL&&pScene2->mNumMeshes>=pt);

	ComplexMesh *pPart = pScene2->mMeshes2[pt];

	if(pPart==NULL) switch(cc)
	{
	case Som::prim: case Som::vert: case Som::norm:	 		

		pPart = pScene2->mMeshes2[pt] = new ComplexMesh;

		Som::SubmeshNameMDL(pt,pPart->mName);

		pPart->mSharedParameters = pScene2->mMeshes2[in->num_parts];		

		pPart->mNumUVComponents[0] = 2;
	}

	switch(cc)
	{
	case Som::tile: //! shared parameters block (uv components more or less)
	{
		if(!in->num_tiles) return false; //NEW

		assert(in->num_tiles==1); //"EneEdit (403A66) loops over these"

		//unsigned int iShared = AI_BE(p->lo);
		unsigned int iShared = AI_BE((int)*p); 
		
		if(iShared==0) return false; //block is empty

		_CHECK_EOF((const char*)p+4+iShared*12); //! expected end of block

		ai_assert(pScene2->mMeshes2!=NULL&&pScene2->mMeshes2[in->num_parts]==NULL);
				
		unsigned int iCurTextureCoords = 0;
				 	
		ComplexMesh *pShared 
			= pScene2->mMeshes2[in->num_parts] = new ComplexMesh; //shared mesh
		
		pShared->mNumUVComponents[0] = 2;
									 
		if(iShared*4>nTmpUVs)
		{
			if(pTmpUVs) delete [] pTmpUVs;

			pTmpUVs = new aiVector3D[nTmpUVs=iShared*4];
		}

		ComplexFace *pFace = 
		pShared->mFaces2 = new ComplexFace[pShared->mNumFaces=iShared];
	
		p++;

		for(unsigned int i=0;i<iShared;i++) 
		{	
			//0092.MDL (SFX) has 0x7ec0 here... it's possibly junk?
			//where is the drawing code? EneEdit (403A66) maybe?
			//if(p->hi!=0)
			//return Warning("Sword of Moonlight MDL shared UVs block not as expected. Block left incomplete");

			pFace->mStride = 1;
			pFace->mIndices = new unsigned int[pFace->mNumIndices=1+4];			

			pFace->mTextureCoords = 1; 	
			UV_ext = p[1].hi;
			pFace->mIndices[1+Q(0)] = UV(p->lo); p++; 

			/*2020: suspect this is wrong/untested...
			if((p->hi&0x0080)==0) //MSB unset
			pFace->mMaterialIndex = (p->hi&0x70)>>4; //could be less than 3bits
			pFace->mMaterialIndex++;
			*/
			/*Transparency is undetermined... N may generate
			//unused material indices
			pFace->mMaterialIndex = 1+(p->hi&0x1F); //the others do this?*/
			pFace->mMaterialIndex = p->hi; //just store TSB (not using later)

			//! Note that the hi 16bits here house potentially meaningful flags

			pFace->mIndices[1+Q(1)] = UV(p->lo); p++;  
			pFace->mIndices[1+Q(2)] = UV(p->lo);				
			pFace->mIndices[1+Q(3)] = UV(p->hi); p++;

			pFace->mNumCorners = 4; pFace++;

			iCurTextureCoords+=4;
		}
		
		ai_assert(256UL**mVCache+*mUCache<=iCurTextureCoords);

		pShared->mNumTextureCoords = UVs();
		 		
		if(pShared->mNumTextureCoords)
		{
			pShared->mTextureCoords[0] = new aiVector3D[pShared->mNumTextureCoords];

			memcpy(pShared->mTextureCoords[0],pTmpUVs,sizeof(aiVector3D)*pShared->mNumTextureCoords);
		}

		break;
	}
	case Som::prim: //! prim packets block
	{	
		unsigned int iFaces = AI_BE(in->parts[pt].num_prims);

		if(iFaces==0) return false; //faces absent
		
		pPart->mFaces2 = new ComplexFace[iFaces];

		unsigned int iCoords = 0;

		for(unsigned int i=0;i<iFaces;i++)
		{
			int iHi = AI_BE(p->hi), iLo = AI_BE(p->lo); p++;

			if(iHi==0) continue; //assuming empty set
						
			switch(iLo)
			{
			default: 
			{
				char szLo[33]; _itoa(iLo,szLo,16);

				return Warning("Sword of Moonlight MDL unrecognized prim packet code "+std::string(szLo)+". Block left incomplete");
			}
			case 0x0000: //flat coloured triangle

				pPart->mNumColors+=iHi; 
								
				_CHECK_EOF(p+=iHi*3); break;

			case 0x0001: //flat shaded triangle
			
				iCoords+=iHi*3; 
			
				_CHECK_EOF(p+=iHi*5); break;

			case 0x0003: //smooth coloured triangle

				pPart->mNumColors+=iHi; 
								
				_CHECK_EOF(p+=iHi*4); break;

			case 0x0004: //smooth shaded triangle
	
				iCoords+=iHi*3; 
				
				_CHECK_EOF(p+=iHi*6); break;

			case 0x0006: //flat coloured quadrangle

				pPart->mNumColors+=iHi;

				_CHECK_EOF(p+=iHi*4); break;

			case 0x0007: //flat shaded quadrangle

				_CHECK_EOF(p+=iHi*4); break;

			case 0x000A: //smooth shaded quadrangle

				_CHECK_EOF(p+=iHi*5); break;

			case 0x000D: //unlit triangle

				iCoords+=iHi*3;

				pPart->mNumColors+=iHi;

				_CHECK_EOF(p+=iHi*6); break;

			case 0x0011: //unlit quadrangle

				pPart->mNumColors+=iHi;

				_CHECK_EOF(p+=iHi*4); break;
			
			} //end switch			 

			i+=iHi-1;
		}

		if(iCoords>nTmpUVs)
		{
			if(pTmpUVs) delete [] pTmpUVs;

			pTmpUVs = new aiVector3D[nTmpUVs=iCoords];
		}

		if(pPart->mNumColors)
		pPart->mColors[0] = new aiColor4D[pPart->mNumColors];

		p = *inout; //roll back for second pass
			
		unsigned int iSharedTextureCoords = pPart->mSharedParameters?
											pPart->mSharedParameters->mNumTextureCoords:0;
		unsigned int iCurTextureCoords = 0;
		unsigned int iCurColors = 0;

		ComplexFace *pFace = pPart->mFaces2;

		for(unsigned int i=0;i<iFaces;i++)
		{				
			unsigned int iHi = AI_BE(p->hi), iLo = AI_BE(p->lo); p++;

			for(unsigned int j=0;j<iHi;j++) switch(iLo)
			{
			default: 
			{
				char szLo[] = "        "; _itoa(iLo,szLo,16);

				return Warning("Sword of Moonlight MDL unrecognized prim packet code "+std::string(szLo)+". Block left incomplete");
			}
			case 0x00: //flat colored triangle
			{
				if(iCurColors+1>pPart->mNumColors)
				return Warning("Sword of Moonlight MDL appears the number of actual colors exceeded expectation. Block left incomplete");
			
				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=2+3];
				
				pPart->mColors[0][iCurColors] = aiColor4D(p->r,p->g,p->b,255)/255.0f; 
															   
				if(!pScene2->mAnimations) //paranoia
				if(p->r||p->g!=255||p->b!=255) mCPs++; //skip cyan

				pFace->mFaceFeatures|=aiFaceFeature_COLOR; 
				
				pFace->mIndices[1] = iCurColors; p++; //face color

				pFace->mFaceFeatures|=aiFaceFeature_NORMAL; 

				pFace->mIndices[0] = AI_BE(p->lo); //face normal

				pFace->mVertices = 2;

				//SOM uses this for CPs. The 0 index tends to be 
				//most pleasant for building a coordinate system
				//around except it changes whenever the vertices
				//are reversed owing to winding conventions. the
				//1 index survives reversal. Note, 0 is just the
				//way the original MDL files were modeled/stored

				pFace->mIndices[T(/*0*/1)+2] = AI_BE(p->hi); p++;
				pFace->mIndices[T(/*1*/2)+2] = AI_BE(p->lo); 
				pFace->mIndices[T(/*2*/0)+2] = AI_BE(p->hi); p++;

				pFace->mNumCorners = 3; pFace++;

				iCurColors++;

			}break;
			case 0x01: //flat triangle
			{
				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x0001) did not kick off as expected. Block left incomplete");
				
				if(iCurTextureCoords+3>iCoords)
				return Warning("Sword of Moonlight MDL appears the number of actual texture coords exceeded expectation. Block left incomplete");

				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+3+3];

				pFace->mTextureCoords = 1;
				UV_ext = p[1].hi;
				pFace->mIndices[1+T(0)] = UV(p->lo); p++;

				//pFace->mMaterialIndex = 1+(p->hi&0x1F); 
				pFace->mMaterialIndex = N(p[1].hi,p->hi);

				/**there are some more flags in p->hi here which are not well understood
				* 00A0: msb set
				* 0080: most common (msb set)
				* 0108:	fairly common
				* 0008: less common
				*/

				pFace->mIndices[1+T(1)] = UV(p->lo); p++;

				/** there are some flags in p->hi here which are not well understood
				* 2400: most common
				* 3400:	less common
				*/

				pFace->mIndices[1+T(2)] = UV(p->lo); p++;
				
				if(iSharedTextureCoords!=0)
				for(int k=0;k<3;k++) pFace->mIndices[1+k]+=iSharedTextureCoords;
				
				pFace->mFaceFeatures|=aiFaceFeature_NORMAL; 

				pFace->mIndices[0] = AI_BE(p->lo); //face normal

				pFace->mVertices = 4;
				pFace->mIndices[T(0)+4] = AI_BE(p->hi); p++;
				pFace->mIndices[T(1)+4] = AI_BE(p->lo);
				pFace->mIndices[T(2)+4] = AI_BE(p->hi); p++;

				pFace->mNumCorners = 3; pFace++; 

				iCurTextureCoords+=3;

			}break;
			case 0x03: //smooth colored triangle
			{
				if(iCurColors+1>pPart->mNumColors)
				return Warning("Sword of Moonlight MDL appears the number of actual colors exceeded expectation. Block left incomplete");

				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=2+3+3];
				
				pPart->mColors[0][iCurColors] = aiColor4D(p->r,p->g,p->b,255)/255.0f; 
				
				if(!pScene2->mAnimations) //paranoia
				if(p->r||p->g!=255||p->b!=255) mCPs++; //skip cyan

				pFace->mFaceFeatures|=aiFaceFeature_COLOR; 
				
				pFace->mIndices[1] = iCurColors; p++; //face color

				pFace->mNormals = 2; pFace->mVertices = 5;
				pFace->mIndices[T(0)+2] = AI_BE(p->lo);
				pFace->mIndices[T(0)+5] = AI_BE(p->hi); p++;
				pFace->mIndices[T(1)+2] = AI_BE(p->lo);
				pFace->mIndices[T(1)+5] = AI_BE(p->hi); p++;
				pFace->mIndices[T(2)+2] = AI_BE(p->lo);
				pFace->mIndices[T(2)+5] = AI_BE(p->hi); p++;

				pFace->mNumCorners = 3; pFace++;

				iCurColors++;

			}break;
			case 0x04: //smooth shaded triangle
			{
				//NOTE: 0001.MDL (SFX) has 0x7da0 in p->hi. It's possibly
				//junk... where is the drawing code? EneEdit (403A66) maybe?
				//if(p->hi!=0)				
				//return Warning("Sword of Moonlight MDL prim packet (0x0004) did not kick off as expected. Block left incomplete");				

				if(iCurTextureCoords+3>iCoords)
				return Warning("Sword of Moonlight MDL appears the number of actual texture coords exceeded expectation. Block left incomplete");

				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+3+3+3];

				pFace->mTextureCoords = 1;
				UV_ext = p[1].hi;
				pFace->mIndices[1+T(0)] = UV(p->lo); p++;

				//if(modern) //fix old version x2mdl files?
				{
					if(~p[1].hi&0x400)
					if(8&in->unknown00||modernizing==3)
					{
						const_cast<uint16_t&>(p[1].hi)|=0x400;
					}
					else assert(0); //really shouldn't happen
				}
				//pFace->mMaterialIndex = 1+(p->hi&0x1F); 
				pFace->mMaterialIndex = N(p[1].hi,p->hi);

				/**there are some more flags in p->hi here which are not well understood
				* 0080: most common
				* 0108:	fairly common
				* 0008: less common
				* 0018: less common
				*/				

				pFace->mIndices[1+T(1)] = UV(p->lo); p++;

				/** there are some flags in p->hi here which are not well understood
				* 2400: most common
				* 3400:	less common
				*/

				pFace->mIndices[1+T(2)] = UV(p->lo); p++;
				
				if(iSharedTextureCoords!=0)
				for(int k=0;k<3;k++) pFace->mIndices[1+k]+=iSharedTextureCoords;

				pFace->mNormals = 4; pFace->mVertices = 7;
				pFace->mIndices[T(0)+4] = AI_BE(p->lo);
				pFace->mIndices[T(0)+7] = AI_BE(p->hi); p++;
				pFace->mIndices[T(1)+4] = AI_BE(p->lo);
				pFace->mIndices[T(1)+7] = AI_BE(p->hi); p++;
				pFace->mIndices[T(2)+4] = AI_BE(p->lo);
				pFace->mIndices[T(2)+7] = AI_BE(p->hi); p++;

				pFace->mNumCorners = 3; pFace++; 

				iCurTextureCoords+=3;

			}break;
			case 0x06: //flat colored quadrangle
			{
				//NOTE: I think maybe 0001.MDL (SFX) is the only file that has
				//this packet

				if(iCurColors+1>pPart->mNumColors)
				return Warning("Sword of Moonlight MDL appears the number of actual colors exceeded expectation. Block left incomplete");

				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=2+4];

				pPart->mColors[0][iCurColors] = 1.0f/255.0f*aiColor4D(p->r,p->g,p->b,1.0f); 

				pFace->mFaceFeatures|=aiFaceFeature_COLOR; 
				
				pFace->mIndices[1] = iCurColors; p++; //face color

				pFace->mFaceFeatures|=aiFaceFeature_NORMAL; 

				pFace->mIndices[0] = AI_BE(p->lo); //face normal

				pFace->mVertices = 2;
				pFace->mIndices[Q(0)+2] = AI_BE(p->hi);	p++;
				pFace->mIndices[Q(1)+2] = AI_BE(p->lo); 
				pFace->mIndices[Q(2)+2] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(3)+2] = AI_BE(p->lo); 

				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x0006) did not end as expected. Block left incomplete");

				p++;

				pFace->mNumCorners = 4; pFace++;

				iCurColors++;

			}break;
			case 0x07: //flat shaded quadrangle (indexed UVs)
			{
				pFace->mStride = 1;
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+4];

				/** there are some flags in p->hi here which are not well understood
				* 2c00: most common
				* 3c00:	less common
				*/

				pFace->mTextureCoords = AI_BE(p->lo); //shared uv components
				
				//assuming shared uv/material block was previoiusly unpacked
				//pFace->mMaterialIndex = pPart->FindMaterial(p->lo);
				pFace->mMaterialIndex = N(p->hi,pPart->FindMaterial(p->lo));

				pFace->mParameterModes|=aiParameterType_TEXTURECOORDS; 

				p++;

				pFace->mFaceFeatures|=aiFaceFeature_NORMAL;

				pFace->mIndices[0] = AI_BE(p->lo); //face normal

				pFace->mVertices = 1;
				pFace->mIndices[Q(0)+1] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(1)+1] = AI_BE(p->lo);
				pFace->mIndices[Q(2)+1] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(3)+1] = AI_BE(p->lo); 

				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x0007) did not end as expected. Block left incomplete");

				p++;

				pFace->mNumCorners = 4; pFace++;

			}break;
			case 0x0A: //smooth shaded quadrangle (indexed UVs)
			{
				pFace->mStride = 1;
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+4+4];

				/** there are some flags in p->hi here which are not well understood				
				* 3c00:	most common
				*/

				pFace->mParameterModes|=aiParameterType_TEXTURECOORDS; 

				pFace->mTextureCoords = AI_BE(p->lo);

				//assuming shared uv/material block was previoiusly unpacked
				//pFace->mMaterialIndex = pPart->FindMaterial(p->lo);
				pFace->mMaterialIndex = N(p->hi,pPart->FindMaterial(p->lo));

				p++; //shared uv components

				pFace->mNormals = 1; pFace->mVertices = 5;
				pFace->mIndices[Q(0)+1] = AI_BE(p->lo);
				pFace->mIndices[Q(0)+5] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(1)+1] = AI_BE(p->lo);
				pFace->mIndices[Q(1)+5] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(2)+1] = AI_BE(p->lo); 
				pFace->mIndices[Q(2)+5] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(3)+1] = AI_BE(p->lo); 
				pFace->mIndices[Q(3)+5] = AI_BE(p->hi); p++;

				pFace->mNumCorners = 4; pFace++; 

			}break;
			case 0x0D: //unlit triangle
			{
				//NOTE: I think maybe 0174.MDL (SFX) is the only file that has
				//this packet

				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x000D) did not kick off as expected. Block left incomplete");

				if(iCurTextureCoords+3>iCoords)
				return Warning("Sword of Moonlight MDL appears the number of actual texture coords exceeded expectation. Block left incomplete");

				pFace->mStride = 1;				
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+1+3+3];

				pFace->mTextureCoords = 2;
				UV_ext = p[1].hi;
				pFace->mIndices[2+T(0)] = UV(p->lo);

				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x000D) did not kick off as expected. Block left incomplete");

				p++;

				/**there are some more flags in p->hi here which are not well understood
				* 00A0: msb set
				* 0080: most common (msb set)
				* 0108:	fairly common
				* 0008: less common
				*/		

				pFace->mIndices[2+T(1)] = UV(p->lo);

				//pFace->mMaterialIndex = 1+(p->hi&0x1F);
				pFace->mMaterialIndex = N(p[2].hi,p->hi);

				p++;

				pFace->mIndices[2+T(2)] = UV(p->lo);
				
				if(iSharedTextureCoords!=0)
				for(int k=0;k<3;k++) pFace->mIndices[2+k]+=iSharedTextureCoords;
	
				(char*&)p+=2; //p++;

				//HELPFUL? //0174.MDL colors are 128,128,128
				{
					pPart->mColors[0][iCurColors] = 1.0f/255.0f*aiColor4D(p->r,p->g,p->b,1.0f); 

					pFace->mFaceFeatures|=aiFaceFeature_COLOR; 
				
					pFace->mIndices[1] = iCurColors; //face color
				}

				(char*&)p+=6; //p++; //double flags packet (?)

				pFace->mVertices = 5;
				pFace->mIndices[T(0)+5] = AI_BE(p->lo); 
				pFace->mIndices[T(1)+5] = AI_BE(p->hi);	p++;
				
				if(p->hi!=0)
				return Warning("Sword of Moonlight MDL prim packet (0x000D) did not kick off as expected. Block left incomplete");

				pFace->mIndices[T(2)+5] = AI_BE(p->lo); p++;

				pFace->mNumCorners = 3; pFace++; 

				iCurTextureCoords+=3;

					iCurColors++;
				
			}break;
			case 0x11: //unlit quadrangle (indexed UVs) (kage.mdl)
			{
				//NOTE: I think maybe 0174.MDL (SFX) is the only file that has
				//this packet

				pFace->mStride = 1;
				pFace->mIndices = new unsigned int[pFace->mNumIndices=1+1+4];
				
				pFace->mParameterModes|=aiParameterType_TEXTURECOORDS; 

				pFace->mTextureCoords = AI_BE(p->lo); //shared uv components
				
				//assuming shared uv/material block was previoiusly unpacked
				//pFace->mMaterialIndex = pPart->FindMaterial(p->lo);
				pFace->mMaterialIndex = N(p[1].hi,pPart->FindMaterial(p->lo));
		
				(char*&)p+=2; //p++;

				//HELPFUL? //0174.MDL colors are 128,128,128
				{
					pPart->mColors[0][iCurColors] = 1.0f/255.0f*aiColor4D(p->r,p->g,p->b,1.0f); 

					pFace->mFaceFeatures|=aiFaceFeature_COLOR; 
				
					pFace->mIndices[1] = iCurColors; //face color
				}
				(char*&)p+=6; //p++; //double flags packet (?)

				pFace->mVertices = 2;
				pFace->mIndices[Q(0)+2] = AI_BE(p->lo); 
				pFace->mIndices[Q(1)+2] = AI_BE(p->hi); p++;
				pFace->mIndices[Q(2)+2] = AI_BE(p->lo);
				pFace->mIndices[Q(3)+2] = AI_BE(p->hi); p++;				

				pFace->mNumCorners = 4; pFace++; 

					iCurColors++;
				
			}break;
			} //end switch			 

			i+=iHi-1;
		}

		pPart->mNumTextureCoords = UVs();

		if(pPart->mNumTextureCoords)
		{
			pPart->mTextureCoords[0] = new aiVector3D[pPart->mNumTextureCoords];

			memcpy(pPart->mTextureCoords[0],pTmpUVs,sizeof(aiVector3D)*pPart->mNumTextureCoords);
		}

		pPart->mNumFaces = iFaces;

		break;		
	}
	case Som::vert: //! vertex packets block
	{	
		int iVerts = AI_BE(in->parts[pt].num_verts);

		if(iVerts==0) return false; //vertices absent

		_CHECK_EOF((const char*)p+iVerts*8); //expected end of block

		pPart->mVertices = new aiVector3D[pPart->mNumVertices=iVerts];

		for(int i=0;i<iVerts;i++) 
		{
			ai_assert(p[1].hi==0);

			pPart->mVertices[i].x = xinvert*int16_t(AI_BE(p->lo))/1024.0f;
			pPart->mVertices[i].y = yinvert*int16_t(AI_BE(p->hi))/1024.0f; p++;
			pPart->mVertices[i].z = zinvert*int16_t(AI_BE(p->lo))/1024.0f; p++;
		}

		break;
	}
	case Som::norm: //! normal packets block
	{	
		int iNorms = AI_BE(in->parts[pt].num_norms);

		if(iNorms==0) return false; //normals absent

		_CHECK_EOF((const char*)p+iNorms*8); //expected end of block

		pPart->mNormals = new aiVector3D[pPart->mNumNormals=iNorms];

		for(int i=0;i<iNorms;i++) 
		{
			ai_assert(p[1].hi==0);

			pPart->mNormals[i].x = xinvert*int16_t(AI_BE(p->lo));
			pPart->mNormals[i].y = yinvert*int16_t(AI_BE(p->hi)); p++;			
			pPart->mNormals[i].z = zinvert*int16_t(AI_BE(p->lo)); p++;

			pPart->mNormals[i]/=4096.0f; //.Normalize();
		}

		break;
	}
	default: return false;
	} 

	pScene2->mFlags2&=~AI_SCENE_FLAGS_INCOMPLETE; 

	*inout = p; return false;
}

SomHelper::JntMIMeDiffData &SomHelper::CH(unsigned char ch)const
{
	//static JntMIMeDiffData compile; //???

	ai_assert(ch<mNumJntMIMeChannels);
	ai_assert(mJntMIMeChannels);

	return mJntMIMeChannels[ch];	
}

SomHelper::JntMIMeDiffData::operator aiQuaternion()
{
	const float f2RadsX = xinvert*AI_MATH_PI_F/2048.0f;
	const float f2RadsY = yinvert*AI_MATH_PI_F/2048.0f;
	const float f2RadsZ = zinvert*AI_MATH_PI_F/2048.0f;

	/*if(0)
	{
		aiMatrix4x4 mTmp, mOut; 
		if(dvx!=0) mOut*=aiMatrix4x4::RotationX(f2RadsX*dvx,mTmp);
		if(dvy!=0) mOut*=aiMatrix4x4::RotationY(f2RadsY*dvy,mTmp);
		if(dvz!=0) mOut*=aiMatrix4x4::RotationZ(f2RadsZ*dvz,mTmp);
		return aiQuaternion(aiMatrix3x3(mOut)); 
	}*/

	aiQuaternion qOut; 

	Assimp::EulerAnglesToQuaternion<+1,1,2,3>(f2RadsX*dvx,f2RadsY*dvy,f2RadsZ*dvz,qOut);

	return qOut; 
}
SomHelper::JntMIMeDiffData::operator aiVector3D()
{
	return aiVector3D(xinvert*dtx,yinvert*dty,zinvert*dtz)/1024.0f;
}
void SomHelper::JntMIMeDiffData::make_keys(aiNodeAnim *pChan, int diffmask, double time)
{
	aiQuatKey *q = nullptr;
	if(diffmask&0x07||pChan->mNumRotationKeys==0)
	{
		aiQuatKey *pKey = 
		pChan->mRotationKeys+pChan->mNumRotationKeys++;

		aiQuaternion qCurRotation = operator aiQuaternion();

		pKey->mTime = time;
		pKey->mValue = qCurRotation;

		//if(modern&&modernizing)
		if(joint2.cur2.w)
		{
			modern.src2 = &pKey->mValue;
			modern.cur2 = *modern.src2;
		}
	}

	if(diffmask&0x38||pChan->mNumPositionKeys==0)
	{
		aiVectorKey *pKey = 
		pChan->mPositionKeys+pChan->mNumPositionKeys++;

		aiVector3D vCurPosition = operator aiVector3D();

		pKey->mTime = time;
		pKey->mValue = vCurPosition;						

		//if(modern&&modernizing)
		if(joint2.cur2.w)
		{
			modern.src = &pKey->mValue;
			modern.cur = *modern.src;
		}
	}

	if(diffmask&0x1c0) //bitsmask&0x40
	{
		aiVectorKey *pKey = 
		pChan->mScalingKeys+pChan->mNumScalingKeys++;

		aiVector3D vCurScaling = aiVector3D(dsx,dsy,dsz);

		pKey->mTime = time;
		pKey->mValue = vCurScaling.SymMul(0.0078125f);
	}
}

bool SomHelper::motion(const Som::Header_MDL* in,
						const Som::Motion_MDL* in2, int cc)const
{
	ai_assert(pScene&&pcEof);

	switch(cc)
	{
	default: ai_assert(0); return false; //misuse

	case Som::anim: 
		
		if(in->num_anims==0||in->add_anims==0) return false; //animation absent

		ai_assert(pScene2->mAnimations==NULL);

		int nc = AI_BE(in2->num_chans);
		int wth = AI_BE(in2->unknown01); assert(wth==1);
		int na = AI_BE(in->num_anims);
		
		//modern standard?
		//http://www.swordofmoonlight.net/bbs2/index.php?topic=312.0
		//note: Some of the treasure box objects already meet
		//this requirement without modifications, even though
		//possibly they could do without their root nodes.
		//modern = !modernizing||nc<pScene2->mNumMeshes*2-2;
		//
		// NOTE: models made with x2mdl prior to 2020/2021
		// are not really either of these and would require
		// special fixes enabled by an environment option
		//
		modern = 8&in->unknown00||!modernizing||modernizing>=3;

		pScene2->mAnimations = new aiAnimation*[na];

		memset(pScene2->mAnimations,0x00,sizeof(void*)*na);
		
		mJntMIMeChannels = new JntMIMeDiffData[nc];

		mNumJntMIMeChannels = 0xFF&nc; break;
	}

	return true;
}			

bool SomHelper::stream(const Som::Header_MDL* in,
						const Som::Stream_MDL** inout, int cc)const
{	
	ai_assert(pScene&&pcEof);

	const Som::Stream_MDL *p = *inout;

	pScene2->mFlags2|=AI_SCENE_FLAGS_INCOMPLETE; 

	int iNum = 0, iRemaining = 0;

	switch(cc)
	{
	case Som::anim: 
		
		if(in->num_anims==0||in->add_anims==0) return false; //animation absent

		if(pScene2->mAnimations==NULL) return false;

		iNum = iRemaining = AI_BE(in->num_anims);

		break;

	default: ai_assert(0); return false; //misuse
	}

	for(int i=0;i<iNum;i++)
	{
		const Som::Stream_MDL::Buff *q = &p->buffs;

		ai_assert(pScene2->mNumAnimations<AI_BE(in->num_anims));

		bool bHasExtraInfo = false; //! annoying special pass

		switch(cc)
		{
		case Som::anim: bHasExtraInfo = pScene2->mNumAnimations==0; 
		{				
			ai_assert(pScene2->mAnimations!=NULL);
			ai_assert(pScene2->mNumAnimations<AI_BE(in->num_anims));

			aiAnimation* pAnim = 
				pScene2->mAnimations[pScene2->mNumAnimations++] = 
					new aiAnimation;

			pAnim->mDuration = tminus; //-1.0f

			int nc = modernizing?in->num_parts:CHs();

			pAnim->mNumChannels = nc; 
			
			//+1 is for root
			//CHs is for spillover
			//pAnim->mChannels = new aiNodeAnim*[nc+1+(pOverlay?mCPs:0)];
			//*2 is in case of fused_root in the extreme
			int ub = (CHs()+1)*2;
			pAnim->mChannels = new aiNodeAnim*[ub+(pOverlay?mCPs:0)];
			memset(pAnim->mChannels,0x00,sizeof(void*)*ub);
			
			pAnim->mTicksPerSecond = 30; //15

			Som::AnimationIdMDL(AI_BE(p->id),pAnim->mName,AI_BE(in->num_anims));

			//! reset accumulation state
			for(int j=0;j<mNumJntMIMeChannels;j++)
			{
				mJntMIMeChannels[j].reset();
				mJntMIMeChannels[j].modern.reset();
			}
		}break;
		default: return false;
		}

		enum{ zero_root=1 }; //REMOVE ME

		int iNumBuffs = AI_BE(p->num_buffs);

		if(bHasExtraInfo&&iNumBuffs>=1) //modern?
		{
			//need parent data to implement modern next pass

			int iCurSize = q->size();

			if(iCurSize==0) return false;

			_CHECK_EOF((const char*)q+iCurSize);

			switch(cc)
			{
			case Som::anim: //! Joint MIMe animation
			{		 
				aiAnimation* pAnim = pScene2->mAnimations[0]; 
				
				for(int l=0,m=4;l<q->hi;l++)
				{
					unsigned int channel = q->bytes[m];
					unsigned int mapping = q->bytes[m+3];

					auto &ch = CH(channel); //2020

					if(mapping!=0xFF&&mapping>=CHs())
					return Warning("Sword of Moonlight MDL animation channel reference appears to be out of range. Ignoring further animation data");
							
					unsigned int diffmask = q->bytes[m+1];
					unsigned int bitsmask = q->bytes[m+2]; m+=3;
					
					//if(bHasExtraInfo)				
					{
						ch.parent = mapping; m++;

						if(mapping!=0xFF) 
						{
							//do this in next pass...
							//CH(mapping).children++;
							//CH(mapping).leaf = false;
							CH(mapping).branch++;

							//NOTE: O334.MDL requires this test 
							if(channel<in->num_parts)
							{
								auto &pivot = CH(mapping).pivot;

								if(pivot!=0xFF)
								{
									if(!modern)
									if(modernizing) //NEW
									{
										if(0xFF==CH(mapping).parent) //0080.MDL (SFX)
										{
											fused_root = true; 

											CH(mapping).pivot = in->num_parts;
										}
										else ch.fused = pivot;
									}
								}
								else pivot = channel; //modern
							}
							else if(mapping>=in->num_parts) //E113.MDL
							{
								//this is a root without associated geometry
								//i.e. the candle knight (Death Fighter)

								if(!modern&&modernizing)
								{
									root = channel; //interrogated below

									e113_mdl = 1; //silenting assertion :(
								}
							}
						}
					}
				
					short *data = ch.pose;

#define _ACCUMULATE_DIFFERENCE(n)\
					if(diffmask&1<<n) if(!(bitsmask&1<<n))\
					{\
						data[n]+=AI_BE(*(int16_t*)(q->bytes+m)); m+=2;\
					}\
					else data[n]+=int8_t(q->bytes[m++]);

					_ACCUMULATE_DIFFERENCE(0) //X rotation
					_ACCUMULATE_DIFFERENCE(1) //Y rotation
					_ACCUMULATE_DIFFERENCE(2) //Z rotation
					_ACCUMULATE_DIFFERENCE(3) //X translation
					_ACCUMULATE_DIFFERENCE(4) //Y translation
					_ACCUMULATE_DIFFERENCE(5) //Z translation
					/*this isn't implemented in terms of building the
					//inverse transforms and only SFX 0000 and 0001.mdl
					//have it, and it is set to 1,1,1 (assert_suppress)
					if(diffmask&1<<6) data[6] = q->bytes[m++]; //X scale
					if(diffmask&1<<7) data[7] = q->bytes[m++]; //Y scale
					if(bitsmask&1<<6) data[8] = q->bytes[m++]; //Z scale
					if(bitsmask&1<<6) diffmask|=0x100; //make_keys*/
					if(diffmask&1<<6) m++; //X scale
					if(diffmask&1<<7) m++; //Y scale
					if(bitsmask&1<<6) m++; //Z scale

//#undef _ACCUMULATE_DIFFERENCE
				}	
			
				/*2020: O244.MDL (arrow trap) doesn't meet this requirement
				unsigned int iNumRoots = 0;
				for(unsigned int l=0;l<CHs();l++) 
				iNumRoots+=CH(l).parent==0xFF; 
				if(iNumRoots!=1)
				{						
					Warning("Sword of Moonlight MDL animation channel hierarchy appears incomplete. Ignoring further animation data");

					throw DeadlyImportError("Failed to open Sword of Moonlight MDL file: Multiple root nodes present.");

					//satisfy validator
					delete pScene2->mAnimations[--pScene2->mNumAnimations];

					return false;
				}*/

				if(0xFF!=root) //E113.MDL
				{
					assert(modernizing);
					assert(!fused_root);

					auto &ch = CH(root);
					auto &ch2 = CH(ch.parent);

					if(0xFF==ch2.pivot) //O115.MDL
					if(0xFF==ch2.parent)
					if(0xFF==ch.pivot||ch.branch>1) //O345.MDL
					{
						root2 = true; //HACK: double, false root?
						
						ch2.pivot = in->num_parts+1; 

						ch.pivot = in->num_parts;

						//late 2021: I think E113.MDL is spilling
						//over into its floating root???
						spillover = in->num_parts+1;

						//this is identical to the next block's root
						//detection logic
						ch.root = true;

						if(zero_root) memset(ch.pose,0x00,sizeof(ch.pose));
						if(zero_root) for(int i=9;i-->6;) ch.pose[i] = 128;
					}
					
					if(!root2) root = 0xFF;
				}
				
				//these are for removing the bind pose stack
				if(modern&&modernizing&&modernizing!=3)
				{
					for(int i=CHs();i-->0;)
					{
						JntMIMeDiffData &ch = CH(i);
						//HACK: use operators
						memcpy(ch.data,ch.pose,sizeof(ch.data));					
						ch.joint2.cur = ch;
						ch.joint2.cur2 = ch;
						ch.reset();
						if(ch.parent!=0xFF)
						ch.joint3 = &CH(ch.parent);
						ch.joint2.build_mat(&ch);
					}					
				}
				
			}break;
			default: return false;
			}
		}

		for(int j=0;j<iNumBuffs;j++)	
		{
			int iCurSize = q->size();

			if(iCurSize==0) return false;

			_CHECK_EOF((const char*)q+iCurSize);

			switch(cc)
			{
			case Som::anim: //! Joint MIMe animation
			{		 
				aiAnimation* pAnim = 
				pScene2->mAnimations[pScene2->mNumAnimations-1]; 
				
				for(int l=0,m=4;l<q->hi;l++)
				{
					unsigned int channel = q->bytes[m];
					unsigned int diffmask = q->bytes[m+1];
					unsigned int bitsmask = q->bytes[m+2];
										
					auto &ch = CH(channel); //2020

					//if(channel>=pAnim->mNumChannels||
					//	bHasExtraInfo&&mapping!=0xFF&&mapping>=pAnim->mNumChannels)
					if(channel>=CHs())
					return Warning("Sword of Moonlight MDL animation channel reference appears to be out of range. Ignoring further animation data");
							
					m+=3; if(bHasExtraInfo)
					{
						m++;

						unsigned int mapping = q->bytes[m-1]; //m+3
						
						if(!modern&&channel<in->num_parts)
						{
							//just putting some feelers out
							//(surprised this one hasn't failed?)
							//ai_assert(mapping>=in->num_parts); //fails older x2mdl files

							if(mapping!=0xFF&&mapping>=in->num_parts)
							{
								int cmp = CH(mapping).parent;

								if(0xFF!=cmp||!fused_root)
								{
									mapping = CH(mapping).parent;
								}
							}
						}
						if(mapping!=0xFF) CH(mapping).children++;
					}
					
					short *data = ch.data;

					aiNodeAnim *pChan = NULL;

					int channel2 = channel;
					
					if(!modern) //goto root_or_spillover?
					{
						//NEW: this path is for old xm2dl
						//files
						if(channel<in->num_parts
						&&ch.parent<in->num_parts)
						{
							goto root_or_spillover;
						}

						//KLUDGE
						//for some reason the mesh nodes around the pelvis tend to
						//be used to transform the entire model independent of the
						//cyan control point. hopefully this is the only exception

						//E001.MDL has its pelvis model gradually translating along
						//Y in its idle animation
						//
						//falling rotation is missing from death animations???
						//
						//ai_assert(!j||channel>=in->num_parts);
						//ai_assert(!j||channel>=in->num_parts||!(7&diffmask));
						if(j!=0&&channel<in->num_parts)
						{
							if(!ch.root)											
							if(0xFF!=ch.parent&&0xFF==CH(ch.parent).parent
							&&!fused_root) //0080.MDL
							{
								ai_assert(root==0xFF);

								ch.root = true;
								ch.pivot = in->num_parts; 

								/*saving in "pose"
								//HACK: save bind-pose, etc.
								root = ch;*/
								root = channel;
								/*almost works, but artists will have to
								//deal with teasing apart these channels
								//
								//It looks like this isn't really a bind
								//pose, but it can't be at 0,0,0									
								short y = SHRT_MAX;
								for(int k=in->num_parts;k-->0;)
								{
									int l = CH(k).parent;
									if(l!=0xFF) l = CH(l).parent;
									if(l==channel)
									y = std::min(y,CH(k).dty);
								}
								ch.pose[4] = y==SHRT_MAX?100:y; //dty*/ 
							//	ch.pose[4] = 0; //dty
								if(zero_root) memset(ch.pose,0x00,sizeof(ch.pose)); //I guess?
								if(zero_root) for(int i=9;i-->6;) ch.pose[i] = 128;
							}
							else //E105.MDL? //E101.MDL?
							{
								ai_assert(ch.fused==0xFF);

								if(ch.spillover==0xFF)
								{
									ch.spillover = std::max(in->num_parts+1,spillover+1);

									spillover = ch.spillover; 
								}
								channel2 = ch.spillover; 

								goto root_or_spillover;
							}
							if(ch.root) 
							{
								channel2 = in->num_parts;
								
								goto root_or_spillover;
							}
						}
					}
					if(modern||channel>=in->num_parts)
					{
						if(!modern) 
						{
							channel2 = ch.pivot;

							//WARNING: this can mean that there's a transform only node
							//that's not associated with any geometry and could be part
							//of a chain of transforms that affects downstream geometry
							//
							// E001.MDL has channel #26 as a leaf node without geometry
							//
							// E113.MDL hits 0xFF here? (on my to-do list) channel 14
							//
					//		ai_assert(channel2!=0xFF||!ch.branch); //O345.MDL?

							//E113.MDL
							if(channel2!=0xFF) 
							if(channel2>=in->num_parts) goto root_or_spillover; 
						}
					
						if(modern||channel2<in->num_parts) root_or_spillover:
						{
							pChan = pAnim->mChannels[channel2];

							if(pChan==NULL)
							{
								pChan = pAnim->mChannels[channel2] = new aiNodeAnim;

								pChan->mRotationKeys = new aiQuatKey[std::max(2,iNumBuffs)];
								pChan->mPositionKeys = new aiVectorKey[std::max(2,iNumBuffs)];
								pChan->mScalingKeys = new aiVectorKey[std::max(2,iNumBuffs)];

								pChan->mInterpolate = aiAnimInterpolate_NONE;

								if(j!=0) 
								{
									if(!ch.root||!zero_root)
									ch.reset();
									ch.make_keys(pChan,0,tminus);
								}

								if(pAnim->mNumChannels<channel2+1) //spillover?
								{
									pAnim->mNumChannels = channel2+1;
								}
							}
						}
						else if(0xFF!=channel2)
						{
							ai_assert(0);

							throw DeadlyImportError("[Sword of Moonlight MDL] Unexpected Double dummy animation channel.");
						}
					}
					
/*#define _ACCUMULATE_DIFFERENCE(n)\
					if(diffmask&1<<n) if(!(bitsmask&1<<n))\
					{\
						data[n]+=AI_BE(*(int16_t*)(q->bytes+m)); m+=2;\
					}\
					else data[n]+=int8_t(q->bytes[m++]); 
*/
					_ACCUMULATE_DIFFERENCE(0) //X rotation
					_ACCUMULATE_DIFFERENCE(1) //Y rotation
					_ACCUMULATE_DIFFERENCE(2) //Z rotation
					_ACCUMULATE_DIFFERENCE(3) //X translation
					_ACCUMULATE_DIFFERENCE(4) //Y translation
					_ACCUMULATE_DIFFERENCE(5) //Z translation
					if(diffmask&1<<6) data[6] = q->bytes[m++]; //X scale
					if(diffmask&1<<7) data[7] = q->bytes[m++]; //Y scale
					if(bitsmask&1<<6) data[8] = q->bytes[m++]; //Z scale
					if(bitsmask&1<<6) diffmask|=0x100; //make_keys

#undef _ACCUMULATE_DIFFERENCE
										
					/*I've tested this with every original model and 
					  I'm just tired of hitting it :(
					//TODO: HOW TO MOVE THIS TO NEXT BLOCK SOMEHOW???
					if(j==0&&channel<in->num_parts&&!ch.root&&!modern)
					{
						//EO26.MDL hits this. it might be critical if
						//spillover is in play. It isn't in this case.
						//The animation is #1 (Walking)
						//channel 12 (looks like root?)
						//data: {0, 0, 0, 0, 20, 0, 16}
						//pose: {0, 0, 0, 0, 0,  0,  0}
						//root is assigned on frame #9?
						//Same for E051.MDL... E082.MDL (EO26 double)
						//(all of these are cleared as having a root)
						//N001.MDL N002 N008 N032 N052 N053 N055 N068 N076 N078 (all NPC models)
						ai_assert(!memcmp(ch.pose,data,sizeof(ch.pose)));
					}*/
										
					if(pChan) ch.make_keys(pChan,diffmask,pAnim->mDuration);
				}

				//these are for removing the bind pose stack
				if(modern&&modernizing&&modernizing!=3)
				{
					//I gave up on trying to do this with quaternions
					//and vectors even though it should be possible
					//I wish there were a simpler way to do this
					//than to build the global matrix, etc, for
					//every animation frame. x2mdl does this

					aiQuaternion dq,*q; aiVector3D dp,*p;

					for(int i=CHs();i-->0;)
					{
						JntMIMeDiffData &ch = CH(i);

						ch.modern.build_mat(&ch);
					}
					for(int i=CHs();i-->0;)
					{	
						JntMIMeDiffData &ch = CH(i);

						ch.modern.build_inv(&ch);

						q = ch.modern.src2; p = ch.modern.src;

						if(!q&&!p) continue;

						if(ch.joint3)
						ch.modern.mat = ch.joint3->modern.inv*ch.modern.mat;
						ch.modern.mat.DecomposeNoScaling(q?*q:dq,p?*p:dp);
					}
				}

				pAnim->mDuration++;

				bHasExtraInfo = false;
				
			}break;
			default: return false;
			}
			
			*(const char**)&q+=iCurSize;
		}

		switch(cc)
		{
		case Som::anim: 
		{
			aiAnimation* pAnim = 
			pScene2->mAnimations[pScene2->mNumAnimations-1]; 

			for(unsigned int j=0;j<pAnim->mNumChannels;j++)
			{
				aiNodeAnim* pChan = pAnim->mChannels[j];

				if(pChan==NULL)
				{
					if(CH(j).fused!=0xff) continue;

					pChan = pAnim->mChannels[j] = new aiNodeAnim;
					pChan->mInterpolate = aiAnimInterpolate_NONE;

					//these must be able to merge with SomLoader_merge_spillover
					pChan->mRotationKeys = new aiQuatKey[std::max(2,iNumBuffs)]; //2
					pChan->mPositionKeys = new aiVectorKey[std::max(2,iNumBuffs)]; //2
					pChan->mScalingKeys = new aiVectorKey[std::max(2,iNumBuffs)];
				}

				//RFC
				//WHY WAS THIS? ScenePreprocesor.cpp does something like this?
				/*I think was a short term fix for handling on the post Assimp
				//side?
				if(pChan->mNumRotationKeys==0) 
				{
					pChan->mRotationKeys[0].mTime = tminus; //-1?
					pChan->mRotationKeys[0].mValue = aiQuaternion(1.0f,0.0f,0.0f,0.0f);
					pChan->mNumRotationKeys = 1;
				}
				if(pChan->mNumRotationKeys==1)
				{
					pChan->mRotationKeys[1].mTime = pAnim->mDuration-1; //0???
					pChan->mRotationKeys[1].mValue = pChan->mRotationKeys[0].mValue;					
					pChan->mNumRotationKeys = 2;
				}
				if(pChan->mNumPositionKeys==0) 
				{
					pChan->mPositionKeys[0].mTime = tminus; //-1?
					pChan->mNumPositionKeys = 1;					
				}				
				if(pChan->mNumPositionKeys==1) 
				{
					pChan->mPositionKeys[1].mTime = pAnim->mDuration-1; //0???
					pChan->mPositionKeys[1].mValue = pChan->mPositionKeys[0].mValue;					
					pChan->mNumPositionKeys = 2;
				}*/

				/*UNNCESSARY
				* 
				* NOTE: SomLoader_merge_spillover depends on mNumScalingKeys
				* being nullptrr when not scaling
				* 
				pChan->mScalingKeys = new aiVectorKey[2];
				pChan->mScalingKeys[0] = aiVectorKey(tminus,1.0f);
				pChan->mScalingKeys[1] = aiVectorKey(0.0,1.0f);
				pChan->mNumScalingKeys = 2;*/
				
				pChan->mPreState = 
				pChan->mPostState = aiAnimBehaviour_CONSTANT;

				Som::ChannelNameMDL(j,pChan->mNodeName);
			}

			//merge_spillover seems to need to wait before subtracting
			//the final frame (it's hitting std::vector's OOB check)
			//pAnim->mDuration--;

		}break;
		}

		p = (const Som::Stream_MDL*)q;

		iRemaining--;
	}

	pScene2->mFlags2&=~AI_SCENE_FLAGS_INCOMPLETE; 

	*inout = p; return false;
}

SomHelper::VnMIMeDiffData &SomHelper::VN(unsigned char vn)const
{
	static VnMIMeDiffData compile;

	ai_assert(vn<mNumVnMIMeChannels);
	ai_assert(mVnMIMeChannels);

	return mVnMIMeChannels[vn];	
}

void SomHelper::VnMIMeDiffData::reset()
{	
	ai_assert(ostart!=NULL);

	vstart = NULL; changed = 0x0000;

	DiffSect = NULL; 
	VertSect = NULL; 
}

void SomHelper::VnMIMeDiffData::restart(aiAnimMesh *in)
{
	ai_assert(ostart!=NULL);

	if(vstart!=NULL&&vstart->mVertices!=NULL&&ostart->mNumVertices)
	{
		in->mVertices = new aiVector3D[in->mNumVertices=ostart->mNumVertices];

		memcpy(in->mVertices,vstart->mVertices,sizeof(aiVector3D)*ostart->mNumVertices);	
	}

	vstart = in;

	//the rest here is probably not really necessary 

	DiffSect = NULL; changed = 0x0000;
	VertSect = NULL; 
}

int SomHelper::VnMIMeDiffData::difference(int steps, int vnum)
{
	ai_assert(ostart!=NULL&&vstart!=NULL&&DiffSect!=NULL&&VertSect!=NULL);

	if(vnum==0&&dstart!=0) 
	{
		ai_assert(0); //todo: solve for vnum
	}

	unsigned int bytes = (AI_BE(*(uint16_t*)(DiffSect-3))-4)/3; //YUCK

	const uint8_t *xyz[3] = {DiffSect,DiffSect+bytes,DiffSect+bytes*2};

	int B = dstart/8, b = dstart%8; //bits & Bytes

	int bits = std::min(bytes*8,ostart->mNumVertices); //SHOULD BE EQUAL?

	float inv[3] = {xinvert/1024,yinvert/1024,zinvert/1024};

	for(int v=0,i=0;i<bits;i++)
	{		
		for(int j=0;j<3;j++) if(xyz[j][B]&1<<b)
		{
			if(vstart->mVertices==NULL) //become animated
			{
				vstart->mVertices = new aiVector3D[vstart->mNumVertices=ostart->mNumVertices];
				memcpy(vstart->mVertices,ostart->mVertices,sizeof(aiVector3D)*ostart->mNumVertices);	
			}

			const Som::Frames_MDL::Code &code = 
			*(const Som::Frames_MDL::Code*)(VertSect+vnum);

			vstart->mVertices[i][j]+=inv[j]*code.magnitude()*steps;

			vnum+=code.footprint(); changed = 1;
		}

		if(b==7){ b = 0; B++; }else b++; //bits & Bytes
	}

	return vnum;
}

bool SomHelper::frames(const Som::Header_MDL* in,
						const Som::Frames_MDL* in2, int cc)const
{
	ai_assert(pScene&&pcEof);

	switch(cc)
	{
	case Som::diff: 
	{
		if(in->num_diffs==0||in->add_diffs==0) return false; //animation absent

		ai_assert(in->num_diffs==in2->num_anims); //working assumption for now

		ai_assert(pScene2->mAnimations==NULL);

		const Som::String_MDL *p = &in2->anims;

		unsigned int iNumDiffs = AI_BE(in->num_diffs), iNumFrames = 0;

		for(unsigned int i=0;i<iNumDiffs;i++)
		{
			long long iLen = p->len(pcEof); p = p->end(pcEof);

			if(iLen<=0||p==NULL) 
			return Warning("Sword of Moonlight MDL difference animation frames appear incomprehensible. Ignoring further difference data");

			iNumFrames+=unsigned int(iLen&0xFFFFFFFF);
		}

		pScene2->mAnimations = new aiAnimation*[iNumDiffs];

		memset(pScene2->mAnimations,0x00,sizeof(void*)*iNumDiffs);
		
		mNumVnMIMeChannels = AI_BE(in->num_parts);

		mVnMIMeChannels = new VnMIMeDiffData[mNumVnMIMeChannels];		
		
		unsigned int nverts = 0;

		for(unsigned int i=0;i<mNumVnMIMeChannels;i++)
		{
			if(i>=pScene2->mNumMeshes)
			return Warning("Sword of Moonlight MDL not including difference animations because affected geometry does not exist or failed to load. Ignoring further difference data");			

			ComplexMesh *pMesh = pScene2->mMeshes2[i];
			
			pMesh->mAnimMeshes = new aiAnimMesh*[iNumFrames];

			memset(pMesh->mAnimMeshes,0x00,sizeof(void*)*iNumFrames);

			VnMIMeDiffData &vn = mVnMIMeChannels[i];

			vn.dstart = nverts*3; vn.ostart = pMesh;

			nverts+=vn.ostart->mNumVertices;
		}

	}break;
	default: ai_assert(0); return false; //misuse
	}

	return true;
}			

bool SomHelper::string(const Som::Header_MDL* in,
						const Som::String_MDL** inout, int cc)const
{	
	ai_assert(pScene&&pcEof);

	const Som::String_MDL *p = *inout;

	pScene2->mFlags2|=AI_SCENE_FLAGS_INCOMPLETE; 

	int iNum = 0, iRemaining = 0;

	switch(cc)
	{
	case Som::diff: 

		if(in->num_diffs==0||in->add_diffs==0) return false; //animation absent

		iNum = iRemaining = AI_BE(in->num_diffs); break;

	default: ai_assert(0); return false; //misuse
	}

	for(int i=0;i<iNum;i++)
	{
		_CHECK_EOF((const char*)p->end(pcEof));
		
		switch(cc)
		{
		case Som::diff: //! Vertex/normal MIMe animation
		{		
			ai_assert(pScene2->mAnimations!=NULL);
			ai_assert(pScene2->mNumAnimations<AI_BE(in->num_diffs));

			aiAnimation* pAnim = 
				pScene2->mAnimations[pScene2->mNumAnimations++] = 
					new aiAnimation;

			pAnim->mMeshChannels = new aiMeshAnim*[pAnim->mNumMeshChannels=VNs()];

			memset(pAnim->mMeshChannels,0x00,sizeof(void*)*pAnim->mNumMeshChannels);
			
			pAnim->mTicksPerSecond = 30; //15

			Som::AnimationIdMDL(AI_BE(p->id),pAnim->mName,AI_BE(in->num_diffs));

			//! reset accumulation state
			for(int j=0;j<mNumVnMIMeChannels;j++)
				mVnMIMeChannels[j].reset();

			const Som::Frames_MDL* frames = 
				offset<Som::Frames_MDL>(in,0,Som::diff);
		
			unsigned int iNumDiffs = unsigned int(p->len(pcEof)&0xFFFFFFFF);

			for(unsigned int j=0;j<pAnim->mNumMeshChannels;j++)
			{
				const aiMesh *o = VN(j).ostart; ai_assert(o!=NULL);

				aiMeshAnim *pChan = pAnim->mMeshChannels[j] = new aiMeshAnim;

				pChan->mKeys = new aiMeshKey[iNumDiffs];

				pChan->mName = o->mName; 
			}

			int t = -1; //pAnim->mDuration = tminus;

			for(unsigned int j=0;j<iNumDiffs;j++)	
			{
				Som::String_MDL::Diff diff = p->diffs[j];
								
				//int steps = diff.lo<0?-int(diff.hi):diff.hi;
				int steps = diff.lo<0?-1:1;

				const Som::Frames_MDL::Step *step = 
					frames->step(diff.lo,pcEof); _CHECK_EOF(step);

				int vnum = 0; //optimization: see difference()
				
				t+=diff.hi; //pAnim->mDuration+=diff.hi;

				for(unsigned int k=0;k<pAnim->mNumMeshChannels;k++)
				{
					aiAnimMesh *pNext = new aiAnimMesh;

					aiMesh *pMesh = pScene2->mMeshes2[k];					

					pMesh->mAnimMeshes[pMesh->mNumAnimMeshes] = pNext;
					
					VnMIMeDiffData &vn = VN(k);

					vn.restart(pNext); 
					
					vn.changed = 0x0000;

					vn.DiffSect = step->flags;					
					vn.VertSect = step->codes(Som::vert);
										
					vnum = vn.difference(steps,vnum); 
					 
					if(vn.changed==0x0000)
					{
						//todo: possible optimization
					}

					aiMeshAnim *pChan = pAnim->mMeshChannels[k];
										
					if(!pNext->mVertices) //what to do? 
					{
						//I don't guess any classic models do this behavior
						//x2mdl had inserted dummy frames at the beginning
						//however in theory if a model freezes mid animation
						//it will require a no-difference frame

						//assert(pNext->mVertices); //indicates no difference

						//throw DeadlyImportError( "Soft MDL frame makes no difference");

						if(pNext==vn.vstart) vn.vstart = NULL; //YUCK

						delete pNext; 

						pChan->mKeys[pChan->mNumKeys].mValue = -1;
					}
					else pChan->mKeys[pChan->mNumKeys].mValue = pMesh->mNumAnimMeshes++; 

					pChan->mKeys[pChan->mNumKeys].mTime = t; //pAnim->mDuration;

					pChan->mNumKeys++;					
				}
			}			

			pAnim->mDuration = t<0?0:t;

		}break;
		}

		p = p->end(pcEof); 
		
		iRemaining--;
	}

	pScene2->mFlags2&=~AI_SCENE_FLAGS_INCOMPLETE; 

	*inout = p; return false;
}

bool SomHelper::psxtim(const Som::Header_MDL *in, 
					   const Psx::Header_TIM **inout)const
{
	ai_assert(pScene&&pcEof);

	if(AI_BE(in->num_skins)==0) return false;

	const Psx::Header_TIM *p = *inout; 
	
	if(p->id!=0x10)
	return Warning("Sword of Moonlight MDL texture appears not to be TIM bitmap format. Ignoring further texture data");

	const Psx::Header_TIM::Clut *clut = p->clut_block();
	const Psx::Header_TIM::Data *data = p->data_block();
	
	if(p->pmode<0x02&&clut==NULL)
	return Warning("Sword of Moonlight MDL texture appears to contain paletted data but is missing a color lookup table. Ignoring further texture data");

	_CHECK_EOF((const char*)data+AI_BE(data->bnum));
	_CHECK_EOF((const char*)data+2*AI_BE(data->w)*AI_BE(data->h)+12);

	if(clut) _CHECK_EOF((const char*)clut+AI_BE(clut->bnum));
	if(clut) _CHECK_EOF((const char*)clut+2*AI_BE(clut->w)*AI_BE(clut->h)+12);

	int h = AI_BE(data->h), w = AI_BE(data->w);	_CHECK_EOF(data->data+h*w);

	if(pScene2->mNumTextures>=AI_BE(in->num_skins))
	return Warning("Sword of Moonlight MDL texture appears to have exceeded the ammount indicated by the header. Ignoring further texture data");

	if(pScene2->mNumTextures==0) pScene2->mTextures = new aiTexture*[AI_BE(in->num_skins)];	

	aiTexture *q =
	pScene2->mTextures[pScene2->mNumTextures] = PsxTexture(p); //PsxHelper.h	

	if(!q) return Warning("Sword of Moonlight MDL texture appears corrupted. Ignoring further texture data");

	unsigned int iTex = 1+pScene2->mNumTextures;

	int tpn = data->dy>=256?16:0; //texture page number 

	tpn+=std::min(data->dx/64,15); //0 thru 31

	//will be used to match faces to their materials
	if(0||!mFramebuffer[1+tpn])
	{
		mFramebuffer[1+tpn] = iTex; 

		//trying to figure out how many models use
		//this feature. I'm not sure the UV map is
		//correct
		//alternative pmode sfx models: 92 110 128
		//142 145 146 173 159 166 196 174 175 176 
		//178 184 185 186 187 198 199 206
		//assert(p->pmode==2);
	}
	else //sfx/82 and sfx/86? (also 0 and 1)
	{
		//0001.mdl and (SFX)
		//0000.mdl has a mode 1 and mode 0 texture 
		//sharing TPN 28
		//0082.mdl and (SFX)
		//0086.mdl run into this too
		assert(!mFramebuffer[1+tpn]);

		//this simulates what SOM's code does
		//(just replace the texture)
		std::swap(iTex,mFramebuffer[1+tpn]);

		//aiProcess_RemoveRedundantMaterials?
		//these textures aren't actually offset
		//into the TPN region. Thankfully. SOM 
		//shows the last texture like above.
		//
		// this code just exposes the rest for 
		// the --keep-materials command-line 
		// option. but these are really junk
		// textures. (I developed this before
		// I realized this.)
		//
		while(tpn<31&&mFramebuffer[1+tpn])
		tpn++;
		mFramebuffer[1+tpn] = iTex;

		//HACK: this reserves an extra material
		N(0x400,tpn);
	}

	pScene2->mNumTextures++;

	int next = sizeof(Psx::Header_TIM)+data->bnum;

	if(clut) next+=clut->bnum;
				 
	*(char**)inout+=next;

	if(pScene2->mNumTextures>=AI_BE(in->num_skins)) return false;

	return true; 
}

static void Som::ChannelNameMDL(unsigned ch, aiString &set)
{
	char sz[sizeof("<Ani ch00000>")]; 
	
	sprintf(sz,"<Ani ch%d>",ch+1); set = sz;
}

static void Som::SubmeshNameMDL(unsigned pc, aiString &set)
{
	char sz[sizeof("<Set pc00000>")]; 
	
	sprintf(sz,"<Set pc%d>",pc+1); set = sz;
}

static void Som::AnimationIdMDL(unsigned id, aiString &set, int anims) //hint
{
	char sz[sizeof("#00000")]; 
	
	sprintf(sz,"#%d",id); set = sz; //default animation name

	if(id<2)
	{
		switch(id)
		{
		case 0: set = "Idle (default)"; break;
		case 1: set = "Walking (#1)"; break;
		}
	}
	else if(anims<5) //! guessing object
	{
		switch(id)
		{
		case 4: set = "Opening (#4)"; break;
		case 5: set = "Closing (#5)"; break;
		}
	}
	else if(anims<12) //! guessing enemy
	{
		switch(id)
		{
		case 4:  set = "Dying (#4)";      break;				
		case 6:  set = "Defending (#6)";    break;
		case 7:  set = "Evading (#7)";    break;
		case 9:  set = "Trigger (#9)";    break;
		case 10: set = "Attack A (#10)";  break;
		case 11: set = "Attack B (#11)";  break;
		case 12: set = "Attack C (#12)";  break;
		case 15: set = "Attack D (#15)";  break;
		case 16: set = "Attack E (#16)";  break;
		case 17: set = "Attack F (#17)"; break;
		case 20: set = "Hitting (#20)";   break;
		}			
	}
	else switch(id) //! guessing npc
	{
	case 2:  set = "Hitting (#2)";          break;
	case 3:  set = "Dying (#3)";            break;
	case 4:  set = "To Left (#4)";          break;
	case 5:  set = "To Right (#5)";         break;
	case 6:  set = "To Face (#6)";          break;
	case 16: set = "Seated (#16)";          break;
	case 17: set = "Standing (#17)";        break;
	case 18: set = "Hitting Seated (#18)";  break;
	case 19: set = "Dying Seated (#19)";    break;
	case 20: set = "To Left Seated (#20)";  break;
	case 21: set = "To Right Seated (#21)"; break;
	case 22: set = "To Face Seated (#22)";  break;			
	}			
}

#endif //ASSIMP_BUILD_NO_SWORDOFMOONLIGHT_IMPORTER