/*
---------------------------------------------------------------------------
Open Asset Import Library (ASSIMP)
---------------------------------------------------------------------------

Copyright (c) 2006-2008, ASSIMP Development Team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/

/** @file Implementation of the Playstation helper routines */

#include "AssimpPCH.h"	   
#ifndef ASSIMP_BUILD_NO_MM3D_IMPORTER

// internal headers

#include "../include/Euler.hpp"

#include "Mm3dLoader.h" 

using namespace Assimp;

// ------------------------------------------------------------------------------------------------
// Constructor to be privately used by Importer
Mm3dImporter::Mm3dImporter()
{
	sp_gen_connectivity = 0;
}

// ------------------------------------------------------------------------------------------------
// Destructor, private as well 
Mm3dImporter::~Mm3dImporter()
{

}

// ------------------------------------------------------------------------------------------------
// Returns whether the class can handle the format of the given file. 
bool Mm3dImporter::CanRead( const std::string& pFile, IOSystem* pIOHandler, bool checkSig) const
{
	const std::string extension = GetExtension(pFile);

	if (extension == "mm3d" ) return true; //unacceptable

	return false;
}
// ------------------------------------------------------------------------------------------------
// Setup configuration properties
void Mm3dImporter::SetupProperties(const Importer* pImp)
{
	sp_gen_connectivity = pImp->GetPropertyInteger("SP_GEN_CONNECTIVITY",0);
}

// ------------------------------------------------------------------------------------------------
// Get a list of all supported extensions
void Mm3dImporter::GetExtensionList(std::set<std::string>& extensions)
{
	extensions.insert( "mm3d" );
}

// ------------------------------------------------------------------------------------------------
// Imports the given file into the given scene structure. 
void Mm3dImporter::InternReadFile( const std::string& pFile, 
	aiScene* _pScene, IOSystem* _pIOHandler)
{
	pScene     = _pScene;
	pIOHandler = _pIOHandler;
	boost::scoped_ptr<IOStream> file( pIOHandler->Open( pFile));

	// Check whether we can read from the file
	if( file.get() == NULL) {
		throw DeadlyImportError( "Failed to open MM3D file " + pFile + ".");
	}

	iFileSize = (unsigned int)file->FileSize();

	// Allocate storage and copy the contents of the file to a memory buffer
	std::vector<unsigned char> buffer(iFileSize+1);
	mBuffer = &buffer[0];
	file->Read( (void*)mBuffer, 1, iFileSize);

	// Append a binary zero to the end of the buffer.
	// this is just for safety that string parsing routines
	// find the end of the buffer ...
	mBuffer[iFileSize] = '\0';

	// Determine the file type and call the appropriate member function

	if(DetectFormat_MM3D()) 
	{
		DefaultLogger::get()->debug("MM3D format detected");
		
		InternReadFile_MM3D(); 
		
		if(0)
		if(pScene->mRootNode!=NULL) 
		{
//			aiMatrix4x4 o; //From MM3D
//			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationZ(AI_MATH_PI,o);
//			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationY(AI_MATH_PI,o);
		}
	}
	else	
	{
		// print the magic word to the log file
		throw DeadlyImportError("Unknown MM3D format "+pFile);
	}

	// delete the file buffer and cleanup
	AI_DEBUG_INVALIDATE_PTR(mBuffer);
	AI_DEBUG_INVALIDATE_PTR(pIOHandler);
	AI_DEBUG_INVALIDATE_PTR(pScene);
}

namespace 
{
	typedef float float32_t; //I guess?

	#include "./../include/Compiler/pushpack1.h"

	// Misfit MM3D format:
	//
	// File Header
	//
	// MAGIC_NUMBER	 8 bytes  "MISFIT3D"
	// MAJOR_VERSION	uint8	 0x01
	// MINOR_VERSION	uint8	 0x05
	// MODEL_FLAGS	  uint8	 0x00 (reserved)
	// OFFSET_COUNT	 uint8	 [offc]
	//
	//	 [OFFSET_COUNT] instances of:
	//	 Offset header list
	//	 OFFSET_HEADER	6 bytes *[offc]
	//
	//	 Offset Header
	//	 OFFSET_TYPE	  uint16 (highest bit 0 = Data type A,1 = data type B)
	//	 OFFSET_VALUE	 uint32 
	//
	// Data header A (Variable data size)
	// DATA_FLAGS		uint16 
	// DATA_COUNT		uint32 
	//
	// Data block A
	//
	// [DATA_COUNT] instances of:
	// DATA_SIZE		 uint32 bytes
	// DATA_BLOCK_A	 [DATA_SIZE] bytes
	//
	// Data header B (Uniform data size)
	// DATA_FLAGS		uint16 
	// DATA_COUNT		uint32 
	// DATA_SIZE		 uint32 
	//
	// Data block B
	//
	// [DATA_COUNT] instances of:
	// DATA_BLOCK_B	[DATA_SIZE] bytes
	//
	//
	// Offset A types:
	//	0x1001			 Meta information
	//	0x1002			 Unknown type information
	//	0x0101			 Groups
	//	0x0141			 Embedded textures
	//	0x0142			 External textures
	//	0x0161			 Materials
	//	0x016c			 Texture Projection Triangles
	//	0x0191			 Canvas background images
	//
	//	0x0301			 Skeletal Animations
	//	0x0321			 Frame Animations
	//	0x0326			 Frame Animation Points
	//	0x0341			 Frame Relative Animations
	//
	// Offset B types:
	//	0x0001			 Vertices
	//	0x0021			 Triangles
	//	0x0026			 Triangle Normals
	//	0x0041			 Joints
	//	0x0046			 Joint Vertices
	//	0x0061			 Points
	//	0x0106			 Smooth Angles
	//	0x0168			 Texture Projections
	//	0x0121			 Texture Coordinates
	//
	//
	// 
	// Meta information data
	//	KEY				 ASCIIZ <=1024 (may not be empty)
	//	VALUE			  ASCIIZ <=1024 (may be empty)
	//
	// Unknown type information
	//	OFFSET_TYPE	  uint16
	//	INFO_STRING	  ASCIIZ<=256 (inform user how to support this data)
	//
	//
	// Vertex data
	//	FLAGS			  uint16
	//	X_COORD			float32
	//	Y_COORD			float32
	//	Z_COORD			float32
	//
	//
	// Triangle data
	//	FLAGS			  uint16
	//	VERTEX1_INDEX	uint32
	//	VERTEX2_INDEX	uint32
	//	VERTEX3_INDEX	uint32
	//
	// Group data
	//	FLAGS			  uint16
	//	NAME				ASCIIZ<=inf
	//	TRI_COUNT		 uint32
	//	TRI_INDICES	  uint32 *[TRI_COUNT]
	//	SMOOTHNESS		uint8
	//	MATERIAL_INDEX  uint32
	//	
	// Smooth Angles (maximum angle between smoothed normals for a group)
	//	GROUP_INDEX	  uint32
	//	SMOOTHNESS		uint8
	//	
	// Weighted Influences
	//	POS_TYPE		  uint8
	//	POS_INDEX		 uint32
	//	INF_INDEX		 uint32
	//	INF_TYPE		  uint8
	//	INF_WEIGHT		uint8
	//	
	// External texture data
	//	FLAGS			  uint16
	//	FILENAME		  ASCIIZ
	//
	// Embedded texture data
	//	FLAGS			  uint16
	//	FORMAT			 char8 *4  ('JPEG','PNG ','TGA ',etc...)
	//	TEXTURE_SIZE	 uint32
	//	DATA				uint8 *[TEXTURE_SIZE]
	//
	// Material
	//	FLAGS			  uint16
	//	TEXTURE_INDEX	uint32
	//	NAME				ASCIIZ
	//	AMBIENT			float32 *4
	//	DIFFUSE			float32 *4
	//	SPECULAR		  float32 *4
	//	EMISSIVE		  float32 *4
	//	SHININESS		 float32
	//	
	// Projection Triangles
	//	PROJECTION_INDEX  uint32
	//	TRI_COUNT			uint32
	//	TRI_INDICES		 uint32 *[TRI_COUNT]
	//	
	// Canvas background image
	//	FLAGS			  uint16
	//	VIEW_INDEX		uint8
	//	SCALE			  float32
	//	CENTER_X		  float32
	//	CENTER_X		  float32
	//	CENTER_X		  float32
	//	FILENAME		  ASCIIZ
	//
	// Texture coordinates
	//	FLAGS			  uint16
	//	TRI_INDEX		 uint32
	//	COORD_S			float32 *3
	//	COORD_T			float32 *3
	//
	// Joint data
	//	FLAGS			  uint16
	//	NAME				char8 *40
	//	PARENT_INDEX	 int32
	//	LOCAL_ROT		 float32 *3
	//	LOCAL_TRANS	  float32 *3
	//
	// Joint Vertices
	//	VERTEX_INDEX	 uint32
	//	JOINT_INDEX	  int32
	//
	// Point data
	//	FLAGS			  uint16
	//	NAME				char8 *40
	//	TYPE				int32
	//	BONE_INDEX		int32
	//	ROTATION		  float32 *3
	//	TRANSLATION	  float32 *3
	//
	// Texture Projection 
	//	FLAGS			  uint16
	//	NAME				char8 *40
	//	TYPE				int32
	//	POSITION		  float32 *3
	//	UP VECTOR		 float32 *3
	//	SEAM VECTOR	  float32 *3
	//	U MIN			  float32
	//	V MIN			  float32
	//	U MAX			  float32
	//	V MAX			  float32
	//
	// Skeletal animation
	//	FLAGS			  uint16
	//	NAME				ASCIIZ
	//	FPS				 float32
	//	FRAME_COUNT	  uint32
	//
	//		[FRAME_COUNT] instances of:
	//		KEYFRAME_COUNT  uint32
	//
	//		  [KEYFRAME_COUNT] instances of:
	//		  JOINT_INDEX	  uint32
	//		  KEYFRAME_TYPE	uint8  (0 = rotation,1 = translation)
	//		  PARAM			  float32 *3
	//
	// Frame animation
	//	FLAGS			  uint16
	//	NAME				ASCIIZ<=64
	//	FPS				 float32
	//	FRAME_COUNT	  uint32
	//
	//		[FRAME_COUNT] instances of:
	//		
	//			[VERTEX_COUNT] instances of:
	//			COORD_X			float32
	//			COORD_Y			float32
	//			COORD_Z			float32
	// 
	// Frame animation points
	//	FLAGS				 uint16
	//	FRAME_ANIM_INDEX  uint32
	//	FRAME_COUNT		 uint32
	//
	//		[FRAME_COUNT] instances of:
	//		
	//			[POINT_COUNT] instances of:
	//			ROT_X			float32
	//			ROT_Y			float32
	//			ROT_Z			float32
	//			TRANS_X		 float32
	//			TRANS_Y		 float32
	//			TRANS_Z		 float32
	// 
	// Frame relative animation
	//	FLAGS			  uint16
	//	NAME				ASCIIZ<=64
	//	FPS				 float32
	//	FRAME_COUNT	  uint32
	//
	//		[FRAME_COUNT] instances of:
	//		FVERT_COUNT	  uint32
	//		
	//			[FVERT_COUNT] instances of:
	//			VERTEX_INDEX
	//			COORD_X_OFFSET  float32
	//			COORD_Y_OFFSET  float32
	//			COORD_Z_OFFSET  float32
	// 

	struct Mm3d_OffsetT
	{
		uint16_t offsetType;
		uint32_t offsetValue;
	}PACK_STRUCT;
	typedef std::vector<Mm3d_OffsetT>  Mm3d_OffsetList;

	enum Mm3d_DataTypesE
	{
		// A Types
		MDT_Meta,
		MDT_TypeInfo,
		MDT_Groups,
	//	MDT_EmbTextures, //UNIMPLEMENTED //BINARY PLACEHOLDER?
		MDT_ExtTextures,
		MDT_Materials,
		MDT_ProjectionTriangles,
		MDT_CanvasBackgrounds,
		MDT_SkelAnims,
		MDT_FrameAnims,
		MDT_FrameAnimPoints,
	//	MDT_RelativeAnims, //UNIMPLEMENTED //BINARY PLACEHOLDER?

		MDT_Animations, //2021

		// B Types
		MDT_Vertices,
		MDT_Triangles,
		MDT_TriangleNormals, //IGNORED
		MDT_Joints,
		MDT_JointVertices,
		MDT_Points,
		MDT_SmoothAngles, //???
		MDT_WeightedInfluences,
		MDT_TexProjections,
		MDT_TexCoords,

		MDT_ScaleFactors, //2021

		MDT_Utilities, //2022
		MDT_UvAnimations, //2022

		// End of list
		MDT_EndOfFile,
		MDT_MAX
	};

	enum Mm3d_FlagsE
	{
		MF_HIDDEN	 = 1, // powers of 2
		MF_SELECTED  = 2,
		MF_VERTFREE  = 4, // vertex does not have to be conntected to a face

		// Type-specific flags
		MF_MAT_CLAMP_S = 16,
		MF_MAT_CLAMP_T = 32,
		MF_MAT_ACCUMULATE = 256, //2021 (mm3d2021)

		MF_POS_SCALE_2020 = 16,
	};

	enum Mm3d_FrameAnimFlagsE
	{
		MFAF_ANIM_WRAP = 0x0001,
	};

	enum Mm3d_SkelAnimFlagsE
	{
		MSAF_ANIM_WRAP = 0x0001,
	};

	enum Mm3d_AnimationFlagsE //2021
	{
		MAF_ANIM_TYPE = 0x0007,
		MAF_ANIM_WRAP = 0x0008,
	};

	static const uint16_t Mm3d_OffsetTypes[MDT_MAX] = 
	{
		// Offset A types
		0x1001,		  // Meta information
		0x1002,		  // Unknown type information
		0x0101,		  // Groups
	//	0x0141,		  // Embedded textures
		0x0142,		  // External textures
		0x0161,		  // Materials
		0x016c,		  // Texture Projection Triangles
		0x0191,		  // Canvas background images
		0x0301,		  // Skeletal Animations
		0x0321,		  // Frame Animations
		0x0326,		  // Frame Animation Points
	//	0x0341,		  // Frame Relative Animations

		0x0342, //2021 Animations

		// Offset B types:
		0x0001,		  // Vertices
		0x0021,		  // Triangles
		0x0026,		  // Triangle Normals
		0x0041,		  // Joints
		0x0046,		  // Joint Vertices
		0x0061,		  // Points
		0x0106,		  // Smooth Angles
		0x0146,		  // Weighted Influences
		0x0168,		  // Texture Projections
		0x0121,		  // Texture Coordinates

		0x0180, //2021 Scale Factors

		0x0352, //2022 Utilities
		0x0354, //2022 UV Animations

		0x3fff,		  // End of file
	};

	// File header
	struct MM3DFILE_HeaderT
	{
		char magic[8];
		uint8_t versionMajor;
		uint8_t versionMinor;
		uint8_t modelFlags; //UNUSED
		uint8_t offsetCount;
	}PACK_STRUCT;

	// Data header A (Variable data size)
	struct MM3DFILE_DataHeaderAT
	{
		uint16_t flags;
		uint32_t count;
	}PACK_STRUCT;

	// Data header B (Uniform data size)
	struct MM3DFILE_DataHeaderBT
	{
		uint16_t flags;
		uint32_t count;
		uint32_t size;
	}PACK_STRUCT;

	struct MM3DFILE_VertexT
	{
		uint16_t  flags;
		float32_t coord[3];
	}PACK_STRUCT;

	const size_t FILE_VERTEX_SIZE = 14;

	struct MM3DFILE_TriangleT
	{
		uint16_t  flags;
		uint32_t  vertex[3];
	}PACK_STRUCT;

	const size_t FILE_TRIANGLE_SIZE = 14;

	struct MM3DFILE_TriangleNormalsT
	{
		uint16_t	flags;
		uint32_t	index;
		float32_t  normal[3][3];
	}PACK_STRUCT;

	const size_t FILE_TRIANGLE_NORMAL_SIZE = 42;

	struct MM3DFILE_JointT
	{
		uint16_t  flags;
		char		name[40];
		int32_t	parentIndex;
		float32_t localRot[3];
		float32_t localTrans[3];
	//	float32_t localScale[3];
	}PACK_STRUCT;

	const size_t FILE_JOINT_SIZE = 70; //70+12;

	struct MM3DFILE_JointVertexT
	{
		uint32_t  vertexIndex;
		int32_t	jointIndex;
	}PACK_STRUCT;

	const size_t FILE_JOINT_VERTEX_SIZE = 8;

	struct MM3DFILE_WeightedInfluenceT
	{
		uint8_t	posType;
		uint32_t  posIndex;
		uint32_t  infIndex;
		uint8_t	infType;
		int8_t	 infWeight;
	}PACK_STRUCT;

	const size_t FILE_WEIGHTED_INFLUENCE_SIZE = 11;

	struct MM3DFILE_PointT
	{
		uint16_t  flags;
		char		name[40];
		int32_t	type; //UNUSED
		int32_t	boneIndex; //UNUSED
		float32_t rot[3];
		float32_t trans[3];
	//	float32_t scale[3];
	}PACK_STRUCT;

	const size_t FILE_POINT_SIZE = 74; //74+12;

	struct MM3DFILE_KeyframeT
	{
		uint32_t	objectIndex;
		//0 is Rotate, 1 Translate, 2 Scale
		uint8_t	 keyframeType;
		float32_t  param[3];
	}PACK_STRUCT;

	const size_t FILE_KEYFRAME_SIZE = 17;

	struct MM3DFILE_TexCoordT
	{
		uint16_t  flags;
		uint32_t  triangleIndex;
		float32_t sCoord[3];
		float32_t tCoord[3];
	}PACK_STRUCT;

	const size_t FILE_TEXCOORD_SIZE = 30;
		
	struct MM3DFILE_ScaleFactorT
	{
		uint16_t type;
		uint16_t index;
		float32_t scale[3];
	};

	const size_t FILE_SCALE_FACTOR_SIZE = 16;

	#include "./../include/Compiler/poppack1.h"

	namespace Mm3d
	{
		//NOTE: Misfit Model 3D doesn't check the version number
		//but it does check this magic-number. 
		static const char MISFIT3D[] = "MISFIT3D";	
		static const char MM3D2020[] = "MM3D2020";

		//static const uint8_t VERSION_MAJOR = 1;
		//static const uint8_t VERSION_MINOR = 7;
		static const uint8_t VERSION_MAJOR = 2;
		static const uint8_t VERSION_MINOR = 1; //0;

		static const uint16_t OFFSET_TYPE_MASK  = 0x3fff;
		static const uint16_t OFFSET_UNI_MASK	= 0x8000;
		static const uint16_t OFFSET_DIRTY_MASK = 0x4000;
	}
	
} //namespace

static bool Mm3d_offsetIncluded(Mm3d_DataTypesE type, Mm3d_OffsetList &list)
{
	unsigned count = list.size();
	for(unsigned n=0;n<count;n++)
	if((list[n].offsetType&Mm3d::OFFSET_TYPE_MASK)==Mm3d_OffsetTypes[type])
	return true; return false;
}
static unsigned Mm3d_offsetGet(Mm3d_DataTypesE type, Mm3d_OffsetList &list)
{
	unsigned count = list.size();
	for(unsigned n=0;n<count;n++)
	if((list[n].offsetType&Mm3d::OFFSET_TYPE_MASK)==Mm3d_OffsetTypes[type])
	return list[n].offsetValue; return 0;
}
static bool Mm3d_offsetIsVariable(Mm3d_DataTypesE type, Mm3d_OffsetList &list)
{
	unsigned count = list.size();
	for(unsigned n=0;n<count;n++)
	if((list[n].offsetType&Mm3d::OFFSET_TYPE_MASK)==Mm3d_OffsetTypes[type])
	return (list[n].offsetType&Mm3d::OFFSET_UNI_MASK)==0; return false;
}

void Mm3dImporter::check(void *p)
{
	if(p>szEof) throw DeadlyImportError
	("Invalid MM3D file. The file is too small or contains invalid data");
}
void Mm3dImporter::seek(off_t offset)
{
	check(szPos=szBuf+offset);
}		
template<typename T>
T &Mm3dImporter::read(T &val)
{
	check(szPos+sizeof(T));
	val = AI_BE(*(T*)szPos);
	szPos+=sizeof(T); return val;
}
void Mm3dImporter::readBytes(void *buf, size_t bufLen)
{
	check(szPos+bufLen);
	memcpy(buf,szPos,bufLen);
	szPos+=bufLen;
}
void Mm3dImporter::readAsciiz(char *buf)
{
	auto p = szPos;
	auto d = szEof;
	for(;p<d;p++) if(!*p)
	{
		auto len = p+1-szPos;
				
		if(buf) memcpy(buf,szPos,len); 
				
		szPos+=len; return;
	}
	check(szEof+1); //HACK
}
bool Mm3dImporter::DetectFormat_MM3D()
{
	if(iFileSize>sizeof(MM3DFILE_HeaderT))
	if(!memcmp(mBuffer,Mm3d::MM3D2020,8)
	 ||!memcmp(mBuffer,Mm3d::MISFIT3D,8))
	return true; return false;
} 	
template<class T>
void Mm3d_xcpy(std::vector<T> &x, T* &y, unsigned &z)
{
	if(!x.size()) return;
	z = (unsigned)x.size(); y = new T[z];
	for(unsigned i=z;i-->0;) y[i] = x[i]; x.clear();
};
void Mm3dImporter::InternReadFile_MM3D()
{
	//using namespace Mm3d;
	szBuf = mBuffer;
	szPos = mBuffer;
	szEof = mBuffer+iFileSize;
		
	int compile[4==sizeof(float32_t)];

	MM3DFILE_HeaderT fileHeader;
	readBytes(fileHeader.magic,sizeof(fileHeader.magic));
	read(fileHeader.versionMajor);
	read(fileHeader.versionMinor);
	read(fileHeader.modelFlags); //UNUSED
	read(fileHeader.offsetCount);

	using namespace Mm3d;
	bool mm3d2020 = !memcmp(fileHeader.magic,MM3D2020,strlen(MISFIT3D));
	if(!mm3d2020)
	if(memcmp(fileHeader.magic,MISFIT3D,strlen(MISFIT3D))) //MISFIT3D?
	{
		//log_warning("bad magic number file\n");
		//return Model::ERROR_BAD_MAGIC;
		throw DeadlyImportError("bad magic number file");		
	}

	//FIX ME
	//Assuming can't read if MISFIT3D is newer than 1.7.
	const int major = mm3d2020?VERSION_MAJOR:1;
	const int minor = mm3d2020?VERSION_MINOR:7;
	const int fmajor = fileHeader.versionMajor;
	const int fminor = fileHeader.versionMinor;

	if(fmajor>major)
	{
		//return Model::ERROR_UNSUPPORTED_VERSION;
		throw DeadlyImportError("ERROR_UNSUPPORTED_VERSION");
	}
	else if(fmajor==major) //2020
	{
		if(fminor>minor)
		{
			//return Model::ERROR_UNSUPPORTED_VERSION;
			throw DeadlyImportError("ERROR_UNSUPPORTED_VERSION");
		}
	}
	
	//2021 removes most of 2.0 and adds Animations and
	//ScaleFactors.
	bool mm3d2021 = mm3d2020&&(fmajor>2||fminor>=1);		
	if(mm3d2020&&!mm3d2021)
	{
		throw DeadlyImportError("MM3D2020 2.0 is disabled");
	}
	else mm3d2020 = false; //2020 was a development version.

	unsigned offsetCount = fileHeader.offsetCount;

	Mm3d_OffsetList offsetList;

	unsigned lastOffset = 0;
	//bool lastUnknown = false;
	//UnknownDataList unknownList;
	for(unsigned t=0;t<offsetCount;t++)
	{
		Mm3d_OffsetT mo;
		read(mo.offsetType);
		read(mo.offsetValue);

		if(mo.offsetValue<lastOffset)
		{
			//log_error("Offset are out of order\n");
			//return Model::ERROR_BAD_DATA;
			throw DeadlyImportError("Offset are out of order");
		}

	/*	if(lastUnknown)
		{
			unknownList.back().dataLen = mo.offsetValue-lastOffset;
			//log_warning("unknown data size = %d\n",unknownList.back().dataLen);
			lastUnknown = false;
		}
	*/
		lastOffset = mo.offsetValue;

		offsetList.push_back(mo);

		bool found = false;
		for(unsigned e=0;!found&&e<MDT_MAX;e++)
		if(Mm3d_OffsetTypes[e]==(mo.offsetType&OFFSET_TYPE_MASK))
		{
			found = true;

			if(e==MDT_EndOfFile)
			if(mo.offsetValue>iFileSize)
			{
				//return Model::ERROR_UNEXPECTED_EOF;
				throw DeadlyImportError("ERROR_UNEXPECTED_EOF");
			}
			else if(mo.offsetValue<iFileSize)
			{
				//log_warning("EOF offset and file size do not match (%d and %d)\n",mo.offsetValue,iFileSize);
				//return Model::ERROR_BAD_DATA;
				throw DeadlyImportError("EOF offset and file size do not match");
			}
		}
	
	/*	if(!found)
		{
			lastUnknown = true;
			UnknownDataT ud;
			ud.offsetType = mo.offsetType;
			ud.offsetValue = mo.offsetValue;
			ud.dataLen = 0;

			unknownList.push_back(ud);
		}
	*/
	}

	// Vertices
	unsigned vc = 0;
	if(Mm3d_offsetIncluded(MDT_Vertices,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Vertices,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Vertices,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		if(size==sizeof(MM3DFILE_VertexT))
		vc = count;
	}
	//2022: may be a dummy model
	//if(!vc) throw DeadlyImportError("MDT_Vertices size unexpected/unimplemented");
	auto vp = (MM3DFILE_VertexT*)szPos;
	int compile3[sizeof(*vp)*2==sizeof(MM3DFILE_VertexT[2])];
	check(vp+vc);

	// Triangles
	unsigned tc = 0; 
	if(Mm3d_offsetIncluded(MDT_Triangles,offsetList))
	{
		bool	  variable = Mm3d_offsetIsVariable(MDT_Triangles,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Triangles,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		if(size==sizeof(MM3DFILE_TriangleT))
		tc = count;
	}
	//2022: may be a dummy model
	//if(!tc) throw DeadlyImportError("MDT_Triangles size unexpected/unimplemented");
	auto tp = (MM3DFILE_TriangleT*)szPos;
	int compile4[sizeof(*tp)*2==sizeof(MM3DFILE_TriangleT[2])];
	check(tp+tc);

	// Texture coordinates
	if(Mm3d_offsetIncluded(MDT_TexCoords,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_TexCoords,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_TexCoords,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		if(count!=tc)
		throw DeadlyImportError("MDT_TexCoords count unexpected/unimplemented");

		uint32_t size = 0;
		if(!variable) read(size);

		if(size!=sizeof(MM3DFILE_TexCoordT))
		throw DeadlyImportError("MDT_TexCoords size unexpected/unimplemented");
	}
	else szPos = NULL;
	auto tcp = (MM3DFILE_TexCoordT*)szPos;
	
	// Triangle Normals
	if(Mm3d_offsetIncluded(MDT_TriangleNormals,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_TriangleNormals,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_TriangleNormals,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		if(count!=tc)
		throw DeadlyImportError("MDT_TriangleNormals count unexpected/unimplemented");

		uint32_t size = 0;
		if(!variable) read(size);

		if(size!=sizeof(MM3DFILE_TriangleNormalsT))
		throw DeadlyImportError("MDT_TriangleNormals size unexpected/unimplemented");
	}
	else szPos = NULL;
	auto tnp = (MM3DFILE_TriangleNormalsT*)szPos;

	struct object
	{
		aiNode *jnode,*pnode;
		aiMatrix4x4 bone;
		aiVector3D rel,rot,xyz;
		std::vector<aiVertexWeight> buf;
		std::vector<aiVectorKey> pk;
		std::vector<aiQuatKey> rk;
		std::vector<aiVectorKey> sk;

		object():xyz(1,1,1){}
	};
	std::vector<object> ov;

	auto rn = pScene->mRootNode = new aiNode;
	rn->mName.Set("<assimp_scene_root>");

	// Joints
	unsigned jc = 0;
	if(Mm3d_offsetIncluded(MDT_Joints,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Joints,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Joints,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		//TODO: add parent field to ov/object?
		std::vector<int> parents;

		jc = count;
		ov.resize(jc);
		for(unsigned j=0;j<jc;j++)
		{
			if(variable) read(size);

			auto np = szPos+size;
			MM3DFILE_JointT fileJoint;			
			read(fileJoint.flags);
			readBytes(fileJoint.name,sizeof(fileJoint.name));
			fileJoint.name[sizeof(fileJoint.name)-1] = '\0';
			read(fileJoint.parentIndex);
			read(fileJoint.localRot[0]);
			read(fileJoint.localRot[1]);
			read(fileJoint.localRot[2]);
			read(fileJoint.localTrans[0]);
			read(fileJoint.localTrans[1]);
			read(fileJoint.localTrans[2]);
			/*if(mm3d2020)
			{
				read(fileJoint.localScale[0]);
				read(fileJoint.localScale[1]);
				read(fileJoint.localScale[2]);
			}*/
			if(np!=szPos)
			throw DeadlyImportError("MDT_Joints size unexpected/unimplemented");

			auto nd = ov[j].jnode = new aiNode(fileJoint.name);

			float *rot = fileJoint.localRot;
			//UNTESTED
			//MS3DLoader transposes
			//I think this will work (Transpose) since it worked with aiQuatKey but
			//I've no clue what's going on with Assimp's notion of Euler angles, so
			//look out!
			nd->mTransformation.FromEulerAnglesXYZ(rot[0],rot[1],rot[2]).Transpose();
			for(int i=3;i-->0;)
			nd->mTransformation[i][3] = fileJoint.localTrans[i];
			/*if(mm3d2020)
			{
				//UNTESTED ([j][i]?)
				for(int i=3;i-->0;) 
				for(int j=3;j-->0;)
				nd->mTransformation[i][j]*=fileJoint.localScale[i];
			}*/
			
			memcpy(&ov[j].rel,fileJoint.localTrans,sizeof(float)*3);
			memcpy(&ov[j].rot,fileJoint.localRot,sizeof(float)*3);
			//memcpy(&ov[j].xyz,fileJoint.localScale,sizeof(float)*3); 

			ov[j].bone = nd->mTransformation;

			//REMINDER: parents may be out-of-order
			parents.push_back(fileJoint.parentIndex);
		}
		for(unsigned j=0;j<jc;j++)
		{
			int parent = parents[j];

			auto nd = ov[j].jnode;

			if((unsigned)parent<jc)
			{
				ov[j].bone = ov[parent].bone*ov[j].bone;
				nd->mParent = ov[parent].jnode;
				nd->mParent->mNumChildren++;
			}
			else if(-1==parent)
			{
				nd->mParent = rn; rn->mNumChildren++;
			}
			else throw DeadlyImportError("MDT_Joints parent out-of-bounds");			
		}
	}
	for(auto&ea:ov) ea.bone.Inverse(); //inverts!

	// Points
	unsigned pc = 0;
	if(Mm3d_offsetIncluded(MDT_Points,offsetList))
	{
		//bool variable = Mm3d_offsetIsVariable(MDT_Points,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Points,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		pc = count;
	}

	typedef std::pair<MM3DFILE_WeightedInfluenceT*,MM3DFILE_WeightedInfluenceT*> ipair;
	std::vector<ipair> iv(vc+pc);
	
	// Weighted influences
	if(Mm3d_offsetIncluded(MDT_WeightedInfluences,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_WeightedInfluences,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_WeightedInfluences,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);
		
		if(size!=sizeof(MM3DFILE_WeightedInfluenceT))
		throw DeadlyImportError("MDT_WeightedInfluences size unexpected/unimplemented");

		for(unsigned t=0;t<count;t++)
		{			
			auto ip = (MM3DFILE_WeightedInfluenceT*)szPos;

			MM3DFILE_WeightedInfluenceT fileWi;
			read(fileWi);
			
			if(fileWi.infIndex>=ov.size())
			throw DeadlyImportError("MDT_WeightedInfluences bone index out-of-bounds");

			size_t pt = fileWi.posType;
			size_t pi = fileWi.posIndex;

			if(pt==2) //point?
			{
				pi+=vc; 

				//HACK: increase capacity just in case this
				//point will eventually parent to this node
				ov[fileWi.infIndex].jnode->mNumChildren++;
			}
			else if(pt) continue;

			if(pi>=iv.size())
			throw DeadlyImportError("MDT_WeightedInfluences vertex/point index out-of-bounds");

			if(!iv[pi].first) iv[pi].first = ip; iv[pi].second = ip; 
		}
	}

	rn->mChildren = new aiNode*[rn->mNumChildren+pc];
	rn->mNumChildren = 0;
	for(auto&ea:ov) if(auto&nc=ea.jnode->mNumChildren)
	{
		ea.jnode->mChildren = new aiNode*[nc]; nc = 0;
	}
	for(auto&ea:ov) 
	{
		auto *p = ea.jnode->mParent;
		p->mChildren[p->mNumChildren++] = ea.jnode;
	}
	ov.resize(std::max(ov.size(),pc)); //!!

	// Points 
	if(pc!=0)
	if(Mm3d_offsetIncluded(MDT_Points,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Points,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Points,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned j=0;j<pc;j++)
		{
			if(variable) read(size);

			auto np = szPos+size;
			MM3DFILE_PointT filePoint;
			read(filePoint.flags);
			readBytes(filePoint.name,sizeof(filePoint.name));
			read(filePoint.type); //UNUSED
			read(filePoint.boneIndex); ////UNUSED
			read(filePoint.rot[0]);
			read(filePoint.rot[1]);
			read(filePoint.rot[2]);
			read(filePoint.trans[0]);
			read(filePoint.trans[1]);
			read(filePoint.trans[2]);
			/*if(mm3d2020)
			{
				read(filePoint.scale[0]);
				read(filePoint.scale[1]);
				read(filePoint.scale[2]);
			}*/
			if(np!=szPos)
			throw DeadlyImportError("MDT_Points size unexpected/unimplemented");

			auto nd = ov[j].pnode = new aiNode(filePoint.name);

			//HACK: MDT_FrameAnimPoints is depending on this
			//even if points are actually parented to joints
			rn->mChildren[rn->mNumChildren++] = nd;
			nd->mParent = rn;
			
			float *rot = filePoint.rot;
			//UNTESTED
			//MS3DLoader transposes
			//I think this will work (Transpose) sense it worked with aiQuatKey but
			//I've no clue what's going on with Assimp's notion of Euler angles, so
			//look out!
			nd->mTransformation.FromEulerAnglesXYZ(rot[0],rot[1],rot[2]).Transpose();
			for(int i=3;i-->0;)
			nd->mTransformation[i][3] = filePoint.trans[i];
			/*if(mm3d2020)
			{
				//UNTESTED ([j][i]?)
				for(int i=3;i-->0;) 
				for(int j=3;j-->0;)
				nd->mTransformation[i][j]*=filePoint.scale[i];
			}*/

			nd->mNumMeshes = 1;
			nd->mMeshes = new unsigned(0);			
			
			auto &w = iv[vc+j]; if(auto*i=w.first)
			{
				auto *p = i;

				if(i->infWeight!=100||i!=w.second)
				{
					//UNFINISHED: Assimp can't represent
					//the point with aiBone unless it's 
					//transform is disposed of (and it 
					//would need a unique mesh in that
					//case as well. there will be data
					//loss either way)
				
					for(i++;i<=w.second;i++) 
					if(i->infWeight>p->infWeight)
					{
						p = i;					
					}
				}

				auto *jnd = ov[p->infIndex].jnode;
				nd->mParent = jnd;
				jnd->mChildren[jnd->mNumChildren++] = nd;

				//Hack: have to make the point relative to the parent
				//(is this the right multiplication order?)
				nd->mTransformation = ov[p->infIndex].bone*nd->mTransformation;
			}
		}		
	}	

	//2021 Scale Factors
	if(mm3d2021)
	if(Mm3d_offsetIncluded(MDT_ScaleFactors,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_ScaleFactors,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_ScaleFactors,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned j=0;j<count;j++)
		{
			if(variable) read(size);

			uint16_t type,index;
			read(type); read(index);
			aiVector3D v3; read(v3);
			aiNode *nd; switch(type)
			{
			case 1: 
				
				if(index>=ov.size()) 
				throw DeadlyImportError("MDT_ScaleFactors joint index out-of-bounds");
				nd = ov[index].jnode; 
				break;
				
			case 2:

				if(index>=pc) 
				throw DeadlyImportError("MDT_ScaleFactors point index out-of-bounds");
				nd = ov[index].pnode;
				ov[index].xyz = v3;
				break;

			default: throw DeadlyImportError("MDT_ScaleFactors unrecognized object type");
			}
			//UNTESTED ([j][i]?)
			for(int i=3;i-->0;) 
			for(int j=3;j-->0;) 
			nd->mTransformation[i][j]*=v3[i];
		}
	}

	// Animations
	unsigned sac = 0;
	if(!mm3d2021)
	if(Mm3d_offsetIncluded(MDT_SkelAnims,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_SkelAnims,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_SkelAnims,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		sac = count;
	}
	unsigned fac = 0;
	if(!mm3d2021)
	if(Mm3d_offsetIncluded(MDT_FrameAnims,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_FrameAnims,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_FrameAnims,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		fac = count;
	}
	if(mm3d2021)
	if(Mm3d_offsetIncluded(MDT_Animations,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Animations,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Animations,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		fac = count;
	}

	if(sac+fac)
	pScene->mAnimations = new aiAnimation*[sac+fac];

	enum //Interpolate2020E
	{
	Mm3d_InterpolateKeep =-2, // HACK: Default argument
	Mm3d_InterpolateVoid =-1, // HACK: Return value
	Mm3d_InterpolateNone = 0, // Enable sparse animation
	Mm3d_InterpolateCopy = 1, // Enable sparse animation
	Mm3d_InterpolateStep = 2, // Old way before 2020 mod
	Mm3d_InterpolateLerp = 3, // Linear interpolate			
	};

	std::vector<float> tt; //timetable

	// Skeletal Animations (LEGACY)
	if(!mm3d2021)
	if(Mm3d_offsetIncluded(MDT_SkelAnims,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_SkelAnims,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_SkelAnims,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned a=0;a<count;a++)
		{
			if(variable) read(size);

			auto sa = pScene->mAnimations[pScene->mNumAnimations++] = new aiAnimation;
		
			read(flags); //REPURPOSING 	
			bool wrap = (flags&MSAF_ANIM_WRAP)!=0;

			sa->mName.Set((char*)szPos);
			readAsciiz();

			float32_t fps;
			uint32_t frameCount;
			//float32_t frame2020;

			read(fps);
			sa->mTicksPerSecond = fps;

			read(frameCount);
			tt.resize(frameCount); /*if(mm3d2020)
			{
				for(uint32_t f=0;f<frameCount;f++)
				{
					read(frame2020);
					tt[f] = frame2020;
				}
				read(frame2020);
				sa->mDuration = frame2020;			
			}
			else*/
			{
				for(uint32_t f=0;f<frameCount;f++)
				tt[f] = f;
				sa->mDuration = frameCount;
			}

			//bool step = mm3d2020;

			//NOTE: The number of frames is at most the same
			//as the number of joints, so it might be better
			//to not filter by frames, but vertex-data is so
			for(unsigned f=0;f<frameCount;f++)
			{
				uint32_t keyframeCount;
				read(keyframeCount);

				for(unsigned k=0;k<keyframeCount;k++)
				{
					MM3DFILE_KeyframeT fileKf;
					read(fileKf);

					auto oi = fileKf.objectIndex;
					/*int e = Mm3d_InterpolateLerp;
					if(mm3d2020)
					{
						//assert((oi>>16&0xFF)==Model::PT_Joint); //1
						e = oi>>24&0xFF;
						oi&=0xFFFF;
						if(e==Mm3d_InterpolateLerp) 
						step = false;
					}*/

					if(oi>=jc)
					throw DeadlyImportError("MDT_SkelAnims index out-of-bounds");
				
					if(int kt=fileKf.keyframeType)
					{
						aiVectorKey vk(tt[f],{fileKf.param[0],fileKf.param[1],fileKf.param[2]});
						if(kt==1) vk.mValue+=ov[oi].rel;
						if(kt==2) vk.mValue = vk.mValue.SymMul(ov[oi].xyz);
						(kt==1?ov[oi].pk:ov[oi].sk).push_back(vk);
					}
					else
					{
						aiVector3D rot = ov[oi].rot;
						rot.x+=fileKf.param[0];
						rot.y+=fileKf.param[1];
						rot.z+=fileKf.param[2];
						//Assimp's Euler angle constructor has never worked for me???
						//aiQuatKey qk(tt[f],{rot.x,rot.y,rot.z});
						aiQuaternion q;
						//THIS WORKS FOR SOME ANIMATIONS BUT FAILS BADLY FOR OTHERS???
						//(this worries me, but it works everywhere else except here?)
						//Assimp::EulerAnglesToQuaternion<+1,1,2,3>(rot,q);
						aiMatrix4x4 m; m.FromEulerAnglesXYZ(rot);
						q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC
						aiQuatKey qk(tt[f],q);						
						ov[oi].rk.push_back(qk);
					}
				}
			}
			
			sa->mChannels = new aiNodeAnim*[jc];
			for(auto&ea:ov) if(!ea.pk.empty()||!ea.rk.empty()||!ea.sk.empty())
			{
				auto &ch = sa->mChannels[sa->mNumChannels++];

				ch = new aiNodeAnim;
				ch->mNodeName = ea.jnode->mName;
				if(!wrap)
				{					
					//this should be call extrapolate???
					//Reminder: AnimEvaluator.cpp only extrapolates
					//ch->mPreState = aiAnimBehaviour_LINEAR;
					ch->mPreState = aiAnimBehaviour_DEFAULT;
					ch->mPostState = aiAnimBehaviour_CONSTANT;

					//AnimEvaluator.cpp wraps
					/*2021: this looks like a mistake to me
					if(double t=sa->mDuration) for(auto&ea:ov)*/
					if(double t=sa->mDuration)
					{
						if(!ea.pk.empty())
						{
							if(ea.pk.front().mTime)
							{
								ea.pk.insert(ea.pk.begin(),aiVectorKey(0,ea.rel));
							}
							if(ea.pk.back().mTime<t)
							{
								ea.pk.push_back(ea.pk.back());
								ea.pk.back().mTime = t;
							}
						}
						if(!ea.rk.empty()) 
						{
							if(ea.rk.front().mTime)
							{
								aiQuaternion q;
								aiMatrix4x4 m; m.FromEulerAnglesXYZ(ea.rot);
								q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC						
								ea.rk.insert(ea.rk.begin(),aiQuatKey(0,q));
							}
							if(ea.rk.back().mTime<t)
							{
								ea.rk.push_back(ea.rk.back());
								ea.rk.back().mTime = t;
							}
						}
						if(!ea.sk.empty())
						{
							if(ea.sk.front().mTime)
							{
								ea.sk.insert(ea.sk.begin(),aiVectorKey(0,ea.xyz));
							}
							if(ea.sk.back().mTime<t)
							{
								ea.sk.push_back(ea.sk.back());
								ea.sk.back().mTime = t;
							}
						}						
					}
				}
				else ch->mPreState = ch->mPostState = aiAnimBehaviour_REPEAT;				
				
				//CUSTOM-EXTENSION
				//if(step) ch->mInterpolate = aiAnimInterpolate_NONE;

				Mm3d_xcpy(ea.pk,ch->mPositionKeys,ch->mNumPositionKeys);
				Mm3d_xcpy(ea.rk,ch->mRotationKeys,ch->mNumRotationKeys);
				Mm3d_xcpy(ea.sk,ch->mScalingKeys,ch->mNumScalingKeys);
			}
		}
	}
		
	std::vector<unsigned> fanone;	
	std::vector<std::pair<bool,float32_t*>> fatt;
	std::vector<std::vector<aiVector3D>> faverts;

	// Frame Animations (LEGACY)
	if(!mm3d2021)
	if(Mm3d_offsetIncluded(MDT_FrameAnims,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_FrameAnims,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_FrameAnims,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		fanone.assign(vc,0);
		fatt.resize(count);

		for(unsigned a=0;a<count;a++)
		{	
			if(variable) read(size);

			auto fa = pScene->mAnimations[pScene->mNumAnimations++] = new aiAnimation;

			read(flags); //REPURPOSING
			bool wrap = (flags&MFAF_ANIM_WRAP)!=0;
			fatt[a].first = wrap;

			fa->mName.Set((char*)szPos);
			readAsciiz();
			
			float32_t fps;
			uint32_t  frameCount;
			//float32_t frame2020;

			read(fps);
			fa->mTicksPerSecond = fps;

			read(frameCount);			
			tt.resize(frameCount); /*if(mm3d2020)
			{
				fatt[a].second = (float32_t*)szPos;

				for(uint32_t f=0;f<frameCount;f++)
				{
					read(frame2020);
					tt[f] = frame2020;
				}
				read(frame2020);
				fa->mDuration = frame2020;			
			}
			else*/
			{
				for(uint32_t f=0;f<frameCount;f++)
				tt[f] = f;
				fa->mDuration = frameCount;			
			}

			//bool step = mm3d2020;
		
			for(unsigned f=0,fan;f<frameCount;f++)
			{
				(void)fan; //warning
				auto fav = (unsigned)faverts.size();
				faverts.resize(fav+1);
				faverts[fav].reserve(vc);

				unsigned vM,vN,v = 0;

				vM = vc; //if(!mm3d2020)
				{
					vN = vM; for(;v<vN;v++)
					{
						aiVector3D coord;
						for(int i=0;i<3;i++) 
						read(coord[i]);
						faverts[fav].push_back(coord);
					}
					continue; //fanone?
				}	
				/*else				
				{
					vN = 0;

				restart2020:

					uint32_t e,n;					
					read(e);
					read(n);
					vN+=n;

					if(vN>vM) 
					{				
						//log_error("Vertex count for frame animation %d, frame %d has %d vertices, should be %d\n",anim,f,vN,vM);
						throw DeadlyImportError("Vertex count for frame animation mismatched");
					}

					if(e<=Mm3d_InterpolateCopy) 
					{
						if(e==Mm3d_InterpolateNone)
						{
							faverts[fav].resize(vN);

							for(;v<vN;v++) fanone[v]++;
						}
						else if(e==Mm3d_InterpolateCopy) for(;v<vN;v++)
						{
							if(fan=fanone[v]) fanone[v] = 0;

							aiVector3D coord; if(fan==f) 
							{
								auto c = vp[v].coord;
								coord.Set(c[0],c[1],c[2]);
							}
							else coord = faverts[fav-fan-1][v];

							for(fan=fav-fan;fan<fav;fan++) faverts[fan][v] = coord;

							faverts[fav].push_back(coord);
						}

						if(v<vM) goto restart2020;
					}
					
					if(e==Mm3d_InterpolateLerp) step = false;

					for(;v<vN;v++)
					{
						aiVector3D coord;
						for(int i=0;i<3;i++) read(coord[i]);

						if(fan=fanone[v])
						{
							fanone[v] = 0;

							aiVector3D other; if(fan==f)
							{
								auto c = vp[v].coord;
								other.Set(c[0],c[1],c[2]);
							}
							else other = faverts[fav-fan-1][v];

							if(e==Mm3d_InterpolateLerp) 
							{
								float *t = &tt[f-fan];
								float x = f==fan?0:tt[f-fan-1];
								float y = 1/(tt[f]-x);
								for(fan=fav-fan;fan<fav;fan++)
								{
									Assimp::Interpolator<aiVector3D> lerp;
									lerp(faverts[fan][v],other,coord,(*t++-x)*y);
								}
							}
							else for(fan=fav-fan;fan<fav;fan++) faverts[fan][v] = other;
						}

						faverts[fav].push_back(coord);
					}
				}
				if(vN<vM) goto restart2020;*/
			}

			//Finally, reset "fanone" and set unanimated
			//vertices to reflect the base mesh.
			for(auto&i:fanone) if(int fan=i)
			{
				i = 0; auto v = &i-fanone.data();

				auto fav = (unsigned)faverts.size();

				aiVector3D coord; if(fan==frameCount)
				{
					auto c = vp[v].coord;
					coord.Set(c[0],c[1],c[2]);
				}
				else coord = faverts[fav-fan-1][v];

				for(fan=fav-fan;fan<fav;fan++)
				{
					faverts[fan][v] = coord;
				}
			}
		}
	}

	std::vector<bool> fa2021;

	//2021 Animations
	if(mm3d2021)
	if(Mm3d_offsetIncluded(MDT_Animations,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Animations,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Animations,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		fatt.resize(count);
		fa2021.resize(count);

		for(unsigned a=0;a<count;a++)
		{	
			if(variable) read(size);

			auto fa = pScene->mAnimations[pScene->mNumAnimations++] = new aiAnimation;
			auto sa = fa; //VESTIGE

			read(flags); //REPURPOSING
			int type = flags&MAF_ANIM_TYPE; //7
			(void)type; //1 is skin, 2 is morph (3 if both)
			bool wrap = (flags&MAF_ANIM_WRAP)!=0; //8
			fatt[a].first = wrap;

			fa->mName.Set((char*)szPos);
			readAsciiz();
			
			float32_t fps;
			uint32_t  frameCount;
			float32_t frame2021;

			read(fps);
			fa->mTicksPerSecond = fps;

			read(frameCount);			
			tt.resize(frameCount); 
			fatt[a].second = (float32_t*)szPos;

			for(uint32_t f=0;f<frameCount;f++)
			{
				read(frame2021);
				tt[f] = frame2021;
			}
			read(frame2021);
			fa->mDuration = frame2021;

			uint32_t keyframeMask;
			read(keyframeMask);
					
			//Mesh animations?
			if(1&keyframeMask)
			{
				fa2021[a] = true;

				fanone.assign(vc,0);

				bool step = true;

				for(unsigned f=0,fan;f<frameCount;f++)
				{
					auto fav = (unsigned)faverts.size();
					faverts.resize(fav+1);
					faverts[fav].reserve(vc);

					unsigned vM,vN,v = 0;

					vM = vc;
					{
						vN = 0;

					restart2021:

						uint32_t m,n;
						uint8_t fd[4];
						//read(m);
						readBytes(fd,4); m = fd[0];
						read(n);
						vN+=n;

						//NOTE: A few development/demonstration files may
						//have size 0 for InterpolateStep/InterpolateLerp. 
						if(fd[1]||m>Mm3d_InterpolateLerp||fd[3]!=3&&fd[3])
						{
							/*Can try to recover here, but if the file is newer
							//than WRITE_VERSION_MAJOR/WRITE_VERSION_MINOR then
							//it should have been rejected.
							if(0) 
							{
								advanceBytes(4*fd[3]); continue;
							}*/
							throw DeadlyImportError("MDT_Animations unrecognized vertex keyframe format");
						}

						if(vN>vM) 
						{				
							//log_error("Vertex count for frame animation %d, frame %d has %d vertices, should be %d\n",anim,f,vN,vM);
							throw DeadlyImportError("Vertex count for frame animation mismatched");
						}

						if(m<=Mm3d_InterpolateCopy) 
						{
							if(m==Mm3d_InterpolateNone)
							{
								faverts[fav].resize(vN);

								for(;v<vN;v++) fanone[v]++;
							}
							else if(m==Mm3d_InterpolateCopy) for(;v<vN;v++)
							{
								if(fan=fanone[v]) fanone[v] = 0;

								aiVector3D coord; if(fan==f) 
								{
									auto c = vp[v].coord;
									coord.Set(c[0],c[1],c[2]);
								}
								else coord = faverts[fav-fan-1][v];

								for(fan=fav-fan;fan<fav;fan++) faverts[fan][v] = coord;

								faverts[fav].push_back(coord);
							}

							if(v<vM) goto restart2021;
						}
					
						if(m==Mm3d_InterpolateLerp) step = false;

						for(;v<vN;v++)
						{
							aiVector3D coord;
							for(int i=0;i<3;i++) read(coord[i]);

							if(fan=fanone[v])
							{
								fanone[v] = 0;

								aiVector3D other; if(fan==f)
								{
									auto c = vp[v].coord;
									other.Set(c[0],c[1],c[2]);
								}
								else other = faverts[fav-fan-1][v];

								if(m==Mm3d_InterpolateLerp) 
								{
									float *t = &tt[f-fan];
									float x = f==fan?0:tt[f-fan-1];
									float y = 1/(tt[f]-x);
									for(fan=fav-fan;fan<fav;fan++)
									{
										Assimp::Interpolator<aiVector3D> lerp;
										lerp(faverts[fan][v],other,coord,(*t++-x)*y);
									}
								}
								else for(fan=fav-fan;fan<fav;fan++) faverts[fan][v] = other;
							}

							faverts[fav].push_back(coord);
						}
					}
					if(vN<vM) goto restart2021;
				}
				//Finally, reset "fanone" and set unanimated
				//vertices to reflect the base mesh.
				for(auto&i:fanone) if(int fan=i)
				{
					i = 0; auto v = &i-fanone.data();

					auto fav = (unsigned)faverts.size();

					aiVector3D coord; if(fan==frameCount)
					{
						auto c = vp[v].coord;
						coord.Set(c[0],c[1],c[2]);
					}
					else coord = faverts[fav-fan-1][v];

					for(fan=fav-fan;fan<fav;fan++)
					{
						faverts[fan][v] = coord;
					}
				}
			}

			//2022: this was broken for joints+points
			//I'm a little rusty on this... let's see
			unsigned jc_pc = 0;
			if(2&keyframeMask) jc_pc+=jc;
			if(4&keyframeMask) jc_pc+=pc;
			sa->mChannels = new aiNodeAnim*[jc_pc];

			//Node animations?
			for(int bit=2;bit<=4;bit<<=1) if(bit&keyframeMask)
			{
				bool joints = bit==2, points = bit==4;

				auto oc = joints?jc:pc;

				uint32_t keyframeCount;
				read(keyframeCount);

				bool step = true;
				
				for(unsigned k=0;k<keyframeCount;k++)
				{
					uint8_t fd[4];
					readBytes(fd,4);

					if(fd[1]||fd[0]>Mm3d_InterpolateLerp||fd[3]!=4)
					{
						/*Can try to recover here, but if the file is newer
						//than WRITE_VERSION_MAJOR/WRITE_VERSION_MINOR then
						//it should have been rejected.
						if(0) 
						{
							advanceBytes(4*fd[3]); continue;
						}*/
						throw DeadlyImportError("MDT_Animations unrecognized object keyframe format");
					}
					if(fd[0]==Mm3d_InterpolateLerp) 
					step = false;

					uint16_t oi,f;
					aiVector3D v3;					
					read(oi); read(f); read(v3);

					if(oi>=oc)
					throw DeadlyImportError("MDT_Animations object index out-of-bounds");

					auto &o = ov[oi]; switch(int kt=fd[2]) //keyframeType
					{
					default:
					{
						throw DeadlyImportError("MDT_Animations unrecognized keyframe type");
					}
					case 1: case 4: //translation/scale
					{
						aiVectorKey vk(tt[f],v3);
						if(joints&&kt==1) vk.mValue+=o.rel;
						if(joints&&kt==4) vk.mValue = vk.mValue.SymMul(o.xyz);
						(kt==1?o.pk:o.sk).push_back(vk);
						break;
					}
					case 2: //rotation
					{
						if(joints)
						{
							aiVector3D rot = o.rot+v3;
							//Assimp's Euler angle constructor has never worked for me???
							//aiQuatKey qk(tt[f],{rot.x,rot.y,rot.z});
							aiQuaternion q;
							//THIS WORKS FOR SOME ANIMATIONS BUT FAILS BADLY FOR OTHERS???
							//(this worries me, but it works everywhere else except here?)
							//Assimp::EulerAnglesToQuaternion<+1,1,2,3>(rot,q);
							aiMatrix4x4 m; m.FromEulerAnglesXYZ(rot);
							q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC
							aiQuatKey qk(tt[f],q);						
							o.rk.push_back(qk);
						}
						if(points)
						{
							//Assimp's Euler angle constructor has never worked for me???
							//aiQuatKey qk(tt[f],v3);							
							aiQuaternion q;
							//THIS WORKS FOR SOME ANIMATIONS BUT FAILS BADLY FOR OTHERS???
							//(this worries me, but it works everywhere else except here?)
							//Assimp::EulerAnglesToQuaternion<+1,1,2,3>(v3,q);
							aiMatrix4x4 m; m.FromEulerAnglesXYZ(v3);
							q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC
							aiQuatKey qk(tt[f],q);
							o.rk.push_back(qk);
						}
						break;
					}}
				}				

				if(joints) //WIP: Copying from MDT_SkelAnims
				{			
					//sa->mChannels = new aiNodeAnim*[jc]; //jc+pc???
					for(auto&ea:ov) if(!ea.pk.empty()||!ea.rk.empty()||!ea.sk.empty())
					{
						auto &ch = sa->mChannels[sa->mNumChannels++];

						ch = new aiNodeAnim;
						ch->mNodeName = ea.jnode->mName;
						if(!wrap)
						{					
							//this should be call extrapolate???
							//Reminder: AnimEvaluator.cpp only extrapolates
							//ch->mPreState = aiAnimBehaviour_LINEAR;
							ch->mPreState = aiAnimBehaviour_DEFAULT;
							ch->mPostState = aiAnimBehaviour_CONSTANT;

							//AnimEvaluator.cpp wraps
							/*2021: this looks like a mistake to me
							if(double t=sa->mDuration) for(auto&ea:ov)*/
							if(double t=sa->mDuration)
							{
								if(!ea.pk.empty())
								{
									if(ea.pk.front().mTime)
									{
										ea.pk.insert(ea.pk.begin(),aiVectorKey(0,ea.rel));
									}
									if(ea.pk.back().mTime<t)
									{
										ea.pk.push_back(ea.pk.back());
										ea.pk.back().mTime = t;
									}
								}
								if(!ea.rk.empty()) 
								{
									if(ea.rk.front().mTime)
									{
										aiQuaternion q;
										aiMatrix4x4 m; m.FromEulerAnglesXYZ(ea.rot);
										q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC						
										ea.rk.insert(ea.rk.begin(),aiQuatKey(0,q));
									}
									if(ea.rk.back().mTime<t)
									{
										ea.rk.push_back(ea.rk.back());
										ea.rk.back().mTime = t;
									}
								}
								if(!ea.sk.empty())
								{
									if(ea.sk.front().mTime)
									{
										ea.sk.insert(ea.sk.begin(),aiVectorKey(0,ea.xyz));
									}
									if(ea.sk.back().mTime<t)
									{
										ea.sk.push_back(ea.sk.back());
										ea.sk.back().mTime = t;
									}
								}						
							}
						}
						else ch->mPreState = ch->mPostState = aiAnimBehaviour_REPEAT;				
				
						//CUSTOM-EXTENSION
						//if(step) ch->mInterpolate = aiAnimInterpolate_NONE;

						Mm3d_xcpy(ea.pk,ch->mPositionKeys,ch->mNumPositionKeys);
						Mm3d_xcpy(ea.rk,ch->mRotationKeys,ch->mNumRotationKeys);
						Mm3d_xcpy(ea.sk,ch->mScalingKeys,ch->mNumScalingKeys);
					}
				}
				else if(points) //WIP: Copying from MDT_FrameAnimPoints
				{
					bool wrap = fatt[a].first;

					//fa->mChannels = new aiNodeAnim*[pc]; //jc+pc???
					for(auto&ea:ov) if(!ea.pk.empty()||!ea.rk.empty()||!ea.sk.empty())
					{
						auto &ch = fa->mChannels[fa->mNumChannels++];

						ch = new aiNodeAnim;
						ch->mNodeName = ea.pnode->mName;
						if(!wrap)
						{
							ch->mPreState = aiAnimBehaviour_LINEAR;
							ch->mPostState = aiAnimBehaviour_CONSTANT;
						}
						else ch->mPreState = ch->mPostState = aiAnimBehaviour_REPEAT;				
				
						//CUSTOM-EXTENSION
						//if(step) ch->mInterpolate = aiAnimInterpolate_NONE;

						Mm3d_xcpy(ea.pk,ch->mPositionKeys,ch->mNumPositionKeys);
						Mm3d_xcpy(ea.rk,ch->mRotationKeys,ch->mNumRotationKeys);
						Mm3d_xcpy(ea.sk,ch->mScalingKeys,ch->mNumScalingKeys);
					}
				}
			}
		}
	}

	//2022: This is so much trouble :(
	std::vector<int> texMap;
	std::vector<aiUVTransform> uvAnims; //HACK: REPURPOSING (x2mdl)
	std::vector<std::pair<unsigned,int>> uvMats;

	// Materials (peeking)
	//
	// 2022: UvAnimation introduces a kink where synthetic materials
	// may need to be generated. The purpose of this pass is to know
	// what materials have textures so materials can go after groups.
	//
	if(Mm3d_offsetIncluded(MDT_Materials,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Materials,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Materials,offsetList);

		seek(offset);

		uint16_t flags = 0; read(flags);
		uint32_t count = 0; read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		texMap.resize(count,-1);

		for(unsigned m=0;m<count;m++)
		{
			if(variable) read(size);

			auto np = szPos+size;

			uint32_t texIndex = 0; //???

			read(flags); //REPURPOSING
			read(texIndex);

			if(0==(flags&0x0f)) //MATTYPE_TEXTURE
			{
				texMap[m] = (int)texIndex;
			}

			szPos = np; //seek(np);
		}
	}
	//2022: UvAnimation?
	if(Mm3d_offsetIncluded(MDT_UvAnimations,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_UvAnimations,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_UvAnimations,offsetList);

		seek(offset);

		uint16_t flags = 0; 
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned u=0;u<count;u++)
		{
			if(variable) read(size);

			auto p0 = szPos;
			auto np = szPos+size;

			uint16_t utilIndex = 0; //???

			read(flags); //REPURPOSING
			read(utilIndex);

			float fps; read(fps);

			szPos = p0+20; //seek?

			uint32_t keys; read(keys);

			uvAnims.resize(utilIndex+1);
			auto &x = uvAnims[utilIndex];

			if(keys!=0) //HACK: First key only?
			{
				float t; read(t); t = fps/t;

				char fd[4]; readBytes(fd,4);

				for(int n=fd[0];n-->0;)
				{
					readBytes(fd,4);

					bool ok = false;
					switch(fd[1]?0:fd[2])
					{
					case 2: ok = fd[3]==1;

						read(x.mRotation)*=t; break;

					case 4: ok = fd[3]==2;
					
						read(x.mScaling.x); 
						read(x.mScaling.y);						
						for(int i=2;i-->0;)
						{
							float &s = (&x.mScaling.x)[i];
							if(s>1) s = t*(s-1)+1;
							if(s<1) s = 1-t*(1-s);
						}
						break;
					
					case 1: ok = fd[3]==2;

						read(x.mTranslation.x)*=t; 
						read(x.mTranslation.y)*=t; break;
					}
					if(!ok||!fd[0])
					throw DeadlyImportError("MDT_UvAnimations format descriptor unexpected");
				}
			}

			szPos = np; //seek(np);
		}

		size_t grpUVs = uvAnims.size(); //PARTITIONING

		if(Mm3d_offsetIncluded(MDT_Utilities,offsetList))
		{
			bool variable = Mm3d_offsetIsVariable(MDT_Utilities,offsetList);
			uint32_t offset	= Mm3d_offsetGet(MDT_Utilities,offsetList);

			seek(offset);

			uint16_t flags = 0; 
			uint32_t count = 0;
			read(flags);
			read(count);

			uint32_t size = 0;
			if(!variable) read(size);

			for(unsigned u=0;u<count;u++)
			{
				if(variable) read(size);

				auto np = szPos+size;

				read(flags); //REPURPOSING
				readAsciiz(); //name
				read(flags); //REPURPOSING
				if(flags==1) //UvAnimation
				{
					uint32_t assoc = 0;
					if(read(assoc)) while(read(assoc))
					{
						read(flags); //REPURPOSING

						for(int n=flags;n-->0;)
						{
							read(flags); //REPURPOSING

							if(assoc==4) //PartGroups?
							{
								uvAnims.resize(grpUVs+flags+1);
								auto &x = uvAnims[u];
								auto &y = uvAnims[grpUVs+flags];

								y.mRotation+=x.mRotation;
								y.mScaling.SymMul(x.mScaling);
								y.mTranslation+=x.mTranslation;
							}
						}
					}
				}

				szPos = np; //seek(np);
			}
		}

		uvAnims.erase(uvAnims.begin(),uvAnims.begin()+grpUVs); //PARTITIONING
	}
	
	// Groups
	unsigned grouped = 0;
	for(auto it=tp,itt=tp+tc;it<itt;it++)
	{
		it->flags = 0; //HACK: Mark as not belonging to a group?
	}
	auto bone_subroutine = [&](aiMesh *m)
	{
		for(auto&ea:ov) if(!ea.buf.empty())
		m->mNumBones++;
		if(m->mNumBones)
		{
			auto b = m->mBones = new aiBone*[m->mNumBones];				
			for(auto&ea:ov) if(!ea.buf.empty())
			{					
				auto bone = *b++ = new aiBone;

				bone->mName = ea.jnode->mName;
				auto nw = (unsigned)ea.buf.size();
				bone->mNumWeights = nw;
				bone->mWeights = new aiVertexWeight[nw];
				while(nw-->0)
				bone->mWeights[nw] = ea.buf[nw];					

				bone->mOffsetMatrix = ea.bone;
					
				ea.buf.clear();
			}
		}
	};
	unsigned ameshes = (unsigned)faverts.size();
	if(Mm3d_offsetIncluded(MDT_Groups,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Groups,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Groups,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		//2022: uvAnims?
		//auto numMats = pScene->mNumMaterials;
		auto numMats = texMap.size()+1;

		unsigned g = pc!=0;
		auto mcount = g+count;
		pScene->mNumMeshes = mcount;
		pScene->mMeshes = new aiMesh*[mcount+1]; //1 extra for grouped?
		for(unsigned i=mcount;i-->0;)
		pScene->mMeshes[i] = new aiMesh;

		for(unsigned gu=0;g<mcount;g++,gu++)
		{
			if(variable) read(size);

			auto np = szPos+size;

			auto m = pScene->mMeshes[g];
			 						
			read(flags); //REPURPOSING

			m->mName = (char*)szPos;
			readAsciiz();

			bool uv = false;
			bool gc = false;

			uint32_t fcount;
			read(fcount);
			if(fcount)
			{
				m->mNumFaces = fcount;
				m->mFaces = new aiFace[fcount];
				m->mNumVertices = 3*fcount;
				m->mVertices = new aiVector3D[3*fcount];
				if(tnp) m->mNormals = new aiVector3D[3*fcount];
				auto materialIndex = 1+*(int32_t*)(szPos+4*fcount+1);
				if(tcp&&materialIndex>0)
				{
					if((unsigned)materialIndex>=numMats)
					throw DeadlyImportError("MDT_Materials index out-of-bounds");
					//2022: uvAnims?
					//if(pScene->mMaterials[materialIndex]->GetTextureCount(aiTextureType_DIFFUSE))
					if(-1!=texMap[materialIndex-1])
					m->mTextureCoords[0] = new aiVector3D[3*fcount];
				}
				uv = m->mTextureCoords[0]!=NULL;
				if(sp_gen_connectivity) //HACK/EXTENSION
				{
					//Emulating ComplexScene behavior
					m->mTextureCoords[uv] = new aiVector3D[3*fcount];
					m->mNumUVComponents[uv] = 3; //ScenePreprocessor.cpp doesn't consider 3
					for(unsigned i=3*fcount;i-->0;)
					m->mTextureCoords[uv][i][0] = 1; //Mesh marker?
				}
				gc = m->mTextureCoords[uv]!=NULL;
				m->mNumAnimMeshes = ameshes;
				m->mAnimMeshes = new aiAnimMesh*[ameshes];
				for(unsigned i=ameshes;i-->0;)
				{
					auto am = m->mAnimMeshes[i] = new aiAnimMesh;
					am->mVertices = new aiVector3D[am->mNumVertices=3*fcount];
				}
			}
			auto f = m->mFaces;
			auto v = m->mVertices;
			auto n = m->mNormals, nn = n;
			auto t = uv?m->mTextureCoords[0]:NULL, tt = t;
			auto c = gc?m->mTextureCoords[uv]:NULL, cc = c;
			for(unsigned i=fcount,j=0;i-->0;f++,v+=3,n+=3,t+=3,c+=3)
			{
				uint32_t ti;
				read(ti);

				if(ti>=tc)
				throw DeadlyImportError("MDT_Triangles index out-of-bounds");

				auto &tri = tp[ti];

				if(tri.flags!=0) //2022: double grouped?
				{
					//2022: note, this indicactes a bug in MM3D
					assert(tri.flags!=0);

					f--; m->mNumFaces--; m->mNumVertices-=3;

					continue; //breakpoint
				}

				f->mNumIndices = 3;
				f->mIndices = new unsigned int[3];
				for(int k=0;k<3;k++)
				{
					f->mIndices[k] = j++;

					auto vi = tri.vertex[k];

					if(vi>=vc)
					throw DeadlyImportError("MDT_Vertices index out-of-bounds");

					auto &vrt = vp[vi];					
					for(int l=3;l-->0;) 
					v[k][l] = vrt.coord[l];
					if(nn)
					{
						auto &nrm = tnp[ti].normal[k];
						for(int l=3;l-->0;) 
						n[k][l] = nrm[l];
					}
					if(tt)
					{
						auto &tcd = tcp[ti];
						t[k][0] = tcd.sCoord[k];
						t[k][1] = tcd.tCoord[k];
					}
					if(cc) //HACK/EXTENSION
					{
						c[k][2] = (float)vi;
					}

					if(auto it=iv[vi].first)					
					for(auto itt=iv[vi].second;it<=itt;it++)
					{
						aiVertexWeight vw;
						vw.mVertexId = j-1;
						vw.mWeight = it->infWeight/100.0f;
						ov[it->infIndex].buf.push_back(vw);
					}
				}
				for(unsigned i=ameshes;i-->0;)
				{
					auto &src = faverts[i];
					auto *dst = m->mAnimMeshes[i]->mVertices;
					j-=3; 
					for(auto k:tri.vertex) dst[j++] = src[k];
				}

				tri.flags = 1; //HACK: Mark as belonging to a group?
				grouped++;
			}

			uint8_t smoothness;
			int32_t materialIndex; //uint32_t
			read(smoothness);
			read(materialIndex);		
			if(materialIndex>=0)
			{
				//2022: Synthesize material? (x2mdl)
				if(!uvAnims.empty())
				{
					auto mu = std::make_pair((unsigned)materialIndex,-1);

					if(uvAnims.size()>gu)
					{
						aiUVTransform &cmp = uvAnims[gu], none;
						if(memcmp(&cmp,&none,sizeof(cmp)))
						for(auto&ea:uvAnims) if(!memcmp(&ea,&cmp,sizeof(ea)))
						{
							mu.second = &ea-uvAnims.data(); break;
						}
					}

					auto it = std::find(uvMats.begin(),uvMats.end(),mu);
					if(it==uvMats.end())
					{
						materialIndex = (int)uvMats.size(); 
						uvMats.push_back(mu);
					}
					else materialIndex = it-uvMats.begin();
				}

				m->mMaterialIndex = 1+materialIndex;
			}

			if(np!=szPos)
			throw DeadlyImportError("MDT_Groups size unexpected/unimplemented");
			szPos = np;

			bone_subroutine(m);
		}
	}
	if(grouped=tc-grouped) //YUCK: Same algorithm as above?
	{
		if(!pScene->mMeshes)
		{
			pScene->mNumMeshes = pc!=0;
			pScene->mMeshes = new aiMesh*[pc?2:1];
		}

		//REMINDER: +1 mMeshes is allocated above for this case.
		auto m = pScene->mMeshes[pScene->mNumMeshes++] = new aiMesh;

		m->mNumFaces = grouped;
		m->mFaces = new aiFace[grouped];
		m->mNumVertices = 3*grouped;
		m->mVertices = new aiVector3D[3*grouped];
		if(tnp) m->mNormals = new aiVector3D[3*grouped];
		//if(tcp) m->mTextureCoords[0] = new aiVector3D[3*grouped];
		if(sp_gen_connectivity) //HACK/EXTENSION
		{
			//Emulating ComplexScene behavior
			m->mTextureCoords[0] = new aiVector3D[3*grouped];
			m->mNumUVComponents[0] = 3; //ScenePreprocessor.cpp doesn't consider 3
			for(unsigned i=3*grouped;i-->0;)
			m->mTextureCoords[0][i][0] = 1; //Mesh marker?
		}
		m->mNumAnimMeshes = ameshes;
		m->mAnimMeshes = new aiAnimMesh*[ameshes];
		for(unsigned i=ameshes;i-->0;)
		{
			auto am = m->mAnimMeshes[i] = new aiAnimMesh;
			am->mVertices = new aiVector3D[am->mNumVertices=3*grouped];
		}
		auto f = m->mFaces;
		auto v = m->mVertices;
		auto n = m->mNormals, nn = n;
		//auto t = m->mTextureCoords[0];
		auto c = m->mTextureCoords[0], cc = c;
		unsigned j = 0;
		for(auto iit=tp,it=tp,itt=tp+tc;it<itt;it++) if(!it->flags) //HACK
		{
			uint32_t ti = it-iit;

			auto &tri = tp[ti];
			f->mNumIndices = 3;
			f->mIndices = new unsigned int[3];
			for(int k=0;k<3;k++)
			{
				f->mIndices[k] = j++;

				auto vi = tri.vertex[k];

				if(vi>=vc)
				throw DeadlyImportError("MDT_Vertices index out-of-bounds");

				auto &vrt = vp[vi];					
				for(int l=3;l-->0;) 
				v[k][l] = vrt.coord[l];
				if(nn)
				{
					auto &nrm = tnp[ti].normal[k];
					for(int l=3;l-->0;) 
					n[k][l] = nrm[l];
				}
				/*if(tt)
				{
					auto &tcd = tcp[ti];
					t[k][0] = tcd.sCoord[k];
					t[k][1] = tcd.tCoord[k];
				}*/
				if(cc) //HACK/EXTENSION
				{
					c[k][2] = (float)vi;
				}

				if(auto it=iv[vi].first)					
				for(auto itt=iv[vi].second;it<=itt;it++)
				{
					aiVertexWeight vw;
					vw.mVertexId = j-1;
					vw.mWeight = it->infWeight/100.0f;
					ov[it->infIndex].buf.push_back(vw);
				}
			}
			for(unsigned i=ameshes;i-->0;)
			{
				auto &src = faverts[i];
				auto *dst = m->mAnimMeshes[i]->mVertices;
				j-=3; 
				for(auto k:tri.vertex) dst[j++] = src[k];
			}

			f++; v+=3; n+=3; //t+=3;
		}

		bone_subroutine(m);
	}
	if(pc!=0)
	{
		//This is as close as Assimp comes to describing a point.
		//TODO? Rotation and scale could be represented by lines.
		auto m = pScene->mMeshes[0];		
		m->mNumVertices = 1;
		m->mVertices = new aiVector3D[1];
		m->mNumFaces = 1;
		auto f = m->mFaces = new aiFace[1];
		f->mNumIndices = 1;
		f->mIndices = new unsigned[1]();		
	}
	for(unsigned i=0,v0=0;i<fac;i++)
	{
		if(!fa2021.empty()&&!fa2021[i]) continue;

		auto a = pScene->mAnimations[sac+i];
		int mcount = pScene->mNumMeshes;
		unsigned j = pc!=0;
		a->mMeshChannels = new aiMeshAnim*[mcount-j];		
		float32_t *tt = fatt[i].second; //SHADOWING
		auto nk = tt?((uint32_t*)tt)[-1]:(uint32_t)a->mDuration;
		for(;j<mcount;j++)
		{
			auto &ma = a->mMeshChannels[a->mNumMeshChannels++];
			ma = new aiMeshAnim;
			ma->mName = pScene->mMeshes[j]->mName;
			
			ma->mNumKeys = nk;
			ma->mKeys = new aiMeshKey[nk];
			for(int k=nk;k-->0;)
			{
				ma->mKeys[k].mValue = v0+k;
				ma->mKeys[k].mTime = tt?tt[k]:k;
			}

			if(!fatt[i].first) //wrap? //REPURPOSING
			{
				//this should be call extrapolate???
				//ma->mPreState = aiAnimBehaviour_LINEAR;
				ma->mPreState = aiAnimBehaviour_DEFAULT;
				ma->mPostState = aiAnimBehaviour_CONSTANT;
			}
			else ma->mPreState = ma->mPostState = aiAnimBehaviour_REPEAT;
		}
		v0+=nk;
	}

	// Frame Animation Points (LEGACY)
	if(!mm3d2021)
	if(pc!=0&&fac!=0)
	if(Mm3d_offsetIncluded(MDT_FrameAnimPoints,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_FrameAnimPoints,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_FrameAnimPoints,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned a=0;a<count;a++)
		{
			if(variable) read(size);

			uint32_t anim;
			uint32_t frameCount;

			read(flags); //REPURPOSING

			read(anim);
			read(frameCount);
		
			if(sac+anim>=sac+fac)
			throw DeadlyImportError("MDT_FrameAnimPoints index out-of-bounds");

			aiAnimation *fa = pScene->mAnimations[sac+anim];

			/*float32_t *tt; if(mm3d2020) //SHADOWING
			{
				tt = fatt[anim].second;
				if(frameCount!=*(uint32_t*)(tt-1))
				throw DeadlyImportError("MDT_FrameAnimPoints index out-of-bounds");
			}*/

			//bool step = mm3d2020;

			//NOTE: The number of frames is at most the same
			//as the number of points, so it might be better
			//to not filter by frames, but vertex-data is so
			for(unsigned f=0;f<frameCount;f++)
			{
				/*if(!mm3d2020)*/ 
				for(unsigned j=0;j<pc;j++)
				{
					auto &ea = ov[j];
					aiVector3D pk,rk;
					for(int i=0;i<3;i++) read(rk[i]);
					for(int i=0;i<3;i++) read(pk[i]);
					//2021: This looks like a mistake
					//ea.pk.push_back(aiVectorKey(tt[f],pk));
					//ea.rk.push_back(aiQuatKey(tt[f],{rk[0],rk[1],rk[2]}));
					ea.pk.push_back(aiVectorKey(f,pk));
					ea.rk.push_back(aiQuatKey(f,{rk[0],rk[1],rk[2]}));
				}
				/*else
				{
					uint32_t keyframeCount;
					read(keyframeCount);

					for(unsigned k=0;k<keyframeCount;k++)
					{
						MM3DFILE_KeyframeT fileKf;
						read(fileKf);

						auto oi = fileKf.objectIndex;
						//assert((oi>>16&0xFF)==Model::PT_Point); //2
						int e = oi>>24&0xFF;
						oi&=0xFFFF;
						if(e==Mm3d_InterpolateLerp) 
						step = false;

						if(oi>=pc)
						throw DeadlyImportError("MDT_FrameAnimPoints index out-of-bounds");
				
						if(int kt=fileKf.keyframeType)
						{
							aiVectorKey vk(tt[f],{fileKf.param[0],fileKf.param[1],fileKf.param[2]});
							(kt==1?ov[oi].pk:ov[oi].sk).push_back(vk);
						}
						else
						{
							//Assimp's Euler angle constructor has never worked for me???
							//aiQuatKey qk(tt[f],{fileKf.param[0],fileKf.param[1],fileKf.param[2]});							
							aiQuaternion q;
							//THIS WORKS FOR SOME ANIMATIONS BUT FAILS BADLY FOR OTHERS???
							//(this worries me, but it works everywhere else except here?)
							//Assimp::EulerAnglesToQuaternion<+1,1,2,3>(*(aiVector3D*)fileKf.param,q);
							aiMatrix4x4 m; m.FromEulerAnglesXYZ(*(aiVector3D*)fileKf.param);
							q = aiMatrix3x3(m.Transpose()); //MS3DLoader BLACK MAGIC
							aiQuatKey qk(tt[f],q);
							ov[oi].rk.push_back(qk);
						}
					}
				}*/
			}

			bool wrap = fatt[anim].first;

			fa->mChannels = new aiNodeAnim*[pc];
			for(auto&ea:ov) if(!ea.pk.empty()||!ea.rk.empty()) //!ea.sk.empty()
			{
				auto &ch = fa->mChannels[fa->mNumChannels++];

				ch = new aiNodeAnim;
				ch->mNodeName = ea.pnode->mName;
				if(!wrap)
				{
					ch->mPreState = aiAnimBehaviour_LINEAR;
					ch->mPostState = aiAnimBehaviour_CONSTANT;
				}
				else ch->mPreState = ch->mPostState = aiAnimBehaviour_REPEAT;				
				
				//CUSTOM-EXTENSION
				//if(step) ch->mInterpolate = aiAnimInterpolate_NONE;

				Mm3d_xcpy(ea.pk,ch->mPositionKeys,ch->mNumPositionKeys);
				Mm3d_xcpy(ea.rk,ch->mRotationKeys,ch->mNumRotationKeys);
			//	Mm3d_xcpy(ea.sk,ch->mScalingKeys,ch->mNumScalingKeys);
			}
		}
	}
	//HACK: remove points from root?
	for(unsigned i=0,j=0,&nc=rn->mNumChildren,n=nc;i<n;i++)
	{
		auto &ci = rn->mChildren[i]; if(ci->mParent!=rn)
		{
			nc--;
		}
		else rn->mChildren[j++] = ci;
	}

	int g = pc!=0;
	int nm = pScene->mNumMeshes;
	rn->mMeshes = new unsigned int[rn->mNumMeshes=nm-g];
	for(int i=g,j=g;i<nm;i++)
	if(pScene->mMeshes[i]->mNumVertices)
	{
		pScene->mMeshes[j] = pScene->mMeshes[i];

		rn->mMeshes[j-g] = j++;
	}
	else
	{
		delete pScene->mMeshes[i];

		pScene->mNumMeshes--;

		rn->mNumMeshes--;
	}



	///// MATERIALS (2022) /////


	
	// External Textures
	std::vector<char*> texNames;
	if(Mm3d_offsetIncluded(MDT_ExtTextures,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_ExtTextures,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_ExtTextures,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		for(unsigned t=0;t<count;t++)
		{
			if(variable) read(size);

			auto np = szPos+size;
			read(flags); //REPURPOSING
			texNames.push_back((char*)szPos);
			readAsciiz();
			if(np!=szPos)
			throw DeadlyImportError("MDT_ExtTextures size unexpected/unimplemented");
		}
	}

	// Materials (including UvAnimations)
	if(Mm3d_offsetIncluded(MDT_Materials,offsetList))
	{
		bool variable = Mm3d_offsetIsVariable(MDT_Materials,offsetList);
		uint32_t offset	= Mm3d_offsetGet(MDT_Materials,offsetList);

		seek(offset);

		uint16_t flags = 0;
		uint32_t count = 0;
		read(flags);
		read(count);

		uint32_t size = 0;
		if(!variable) read(size);

		auto nMats = count;
		if(!uvMats.empty()) nMats = uvMats.size();

		pScene->mNumMaterials = 1+nMats;
		pScene->mMaterials = new aiMaterial*[1+nMats];
		auto mat = new MaterialHelper;
		pScene->mMaterials[0] = mat;
		aiString name("<assimp_default_material>");
		mat->AddProperty(&name,AI_MATKEY_NAME);

		//for(unsigned m=1;m<=count;m++)
		for(unsigned m=0;m<count;m++)
		{
			if(variable) read(size);

			auto np = szPos+size;

			uint32_t texIndex = 0; //???

			read(flags); //REPURPOSING
			read(texIndex);

			name.Set((char*)szPos);			
			readAsciiz();
				 			
			aiColor4D ambt,diff,spec,emit; 
			float32_t f;
			for(int i=0;i<4;i++){ read(f); ambt[i] = f; }
			for(int i=0;i<4;i++){ read(f); diff[i] = f; }
			for(int i=0;i<4;i++){ read(f); spec[i] = f; }
			for(int i=0;i<4;i++){ read(f); emit[i] = f; }
			read(f);
						
			if(np!=szPos)
			throw DeadlyImportError("MDT_Materials size unexpected/unimplemented");
			szPos = np;

			auto itt = uvMats.end();
			auto it = uvMats.begin(); do
			{
				int mu,u = -1; if(it<itt)
				{
					mu = -1; for(;it<itt;it++) if(m==it->first)
					{
						mu = 1+(it-uvMats.begin());

						u = it->second; break;
					}
					if(mu==-1) break; it++;
				}
				else mu = 1+m;

				pScene->mMaterials[mu] = mat = new MaterialHelper;

				if(u!=-1) //HACK: REPURPOSING (x2mdl)
				mat->AddProperty(&uvAnims[u],1,AI_MATKEY_UVTRANSFORM(aiTextureType_NONE,0));

				mat->AddProperty(&name,AI_MATKEY_NAME);
			
				if(0==(flags&0x0f) //MATTYPE_TEXTURE			
				&&texIndex<texNames.size())
				{
					aiString texname(/*"bmp/"+*/texNames[texIndex]);
					mat->AddProperty(&texname,AI_MATKEY_TEXTURE_DIFFUSE(0));

					aiTextureMapMode u = 
					flags&MF_MAT_CLAMP_S?aiTextureMapMode_Clamp:aiTextureMapMode_Wrap;
					aiTextureMapMode v = 
					flags&MF_MAT_CLAMP_T?aiTextureMapMode_Clamp:aiTextureMapMode_Wrap;

					mat->AddProperty(&u,1,AI_MATKEY_MAPPINGMODE_U_DIFFUSE(0));
					mat->AddProperty(&v,1,AI_MATKEY_MAPPINGMODE_V_DIFFUSE(0));

					if(flags&MF_MAT_ACCUMULATE&&mm3d2021) //Nov. 2021
					{
						aiBlendMode bm = aiBlendMode_Additive; 
						mat->AddProperty(&bm,1,AI_MATKEY_BLEND_FUNC);
					}
				}

				mat->AddProperty(&ambt,1,AI_MATKEY_COLOR_AMBIENT);
				mat->AddProperty(&diff,1,AI_MATKEY_COLOR_DIFFUSE);
				//mat->AddProperty(&diff.a,1,AI_MATKEY_OPACITY);
				mat->AddProperty(&spec,1,AI_MATKEY_COLOR_SPECULAR);
				mat->AddProperty(&emit,1,AI_MATKEY_COLOR_EMISSIVE);
				mat->AddProperty(&f,1,AI_MATKEY_SHININESS);

				//Assimp will quietly delete the material if this property is undefined.
				const int iMode = (int)aiShadingMode_Gouraud; 
				mat->AddProperty<int>(&iMode,1,AI_MATKEY_SHADING_MODEL);

			}while(it<itt);
		}
	}
}

#endif //ASSIMP_BUILD_NO_MM3D_IMPORTER