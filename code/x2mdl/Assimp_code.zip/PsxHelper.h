		/*
Open Asset Import Library (ASSIMP)
----------------------------------------------------------------------

Copyright (c) 2006-2008, ASSIMP Development Team
All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the 
following conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------
*/


//
//! @file Definition of in-memory structures for the Sword of Moonlight
//  MDL file format. Model reverse engineered from the files themselves.
//

#ifndef AI_PSXHELPER_H_INC
#define AI_PSXHELPER_H_INC

#ifndef AI_N
#define AI_N(n) n //! N array elements. For debugging convenience
#endif

#include "./../include/Compiler/pushpack1.h"

namespace Assimp{  
namespace Psx{		
					
//! Playstation TIM image format
struct Header_TIM
{
	//! 8 bytes
	uint8_t      id;   //! historically 0x10
	uint8_t version;   //! historically zero
	int16_t       :16; //! reserved
	uint8_t  pmode:3;  //! data block bits per pixel
	uint8_t     cf:1;  //! CLUT (color lookup table) present
	uint8_t       :4;  //! reserved
    uint8_t       :8;  //! reserved
	int16_t       :16; //! reserved

	struct Data 
	{
		//! 12 bytes
		uint32_t bnum; //! sizeof block in bytes
		uint16_t dx;   //! x position in framebuffer
		uint16_t dy;   //! y position in framebuffer
		uint16_t w;    //! width in 16bit units
		uint16_t h;    //! height

		/* Data/CLUT entries
		* depends on the following settings for pmode
		* 0x00: 4bits per texel lookup into CLUT (up to 16x16)
		* 0x01: 8bits per texel lookup into CLUT (up to 256x256)
		* 0x02: 5bits per rgb plus highest order transparency mode bit
		* 0x03: 2/3rds of a 24-bit rgb triplet (3 entries per two texels)
		* 0x04: mixed mode (interpretation requires external info)
		*/
		union
		{						  
		uint16_t data[AI_N(16)];
		uint16_t clut[AI_N(16)];
		};

	}PACK_STRUCT;

	typedef Data Clut;

	const Data *data_block()const
	{
		const Data *out = clut_block(); 
		
		if(!out) return (const Data*)(this+1);
		
		return (const Data*)((const char*)out+AI_BE(out->bnum));
	}
	const Clut *clut_block()const
	{
		return (const Clut*)(cf?this+1:NULL);
	}

} PACK_STRUCT;

//! For decoding 32bit words
union Packet_TMD //! 4 bytes
{		
	inline operator uint32_t()const 
	{ 
		return *(uint32_t*)this; 
	}						 

	struct{ uint16_t lo, hi; } PACK_STRUCT;

	struct{	uint8_t u, v, s, t; } PACK_STRUCT;

	struct{	uint8_t r, g, b; } PACK_STRUCT;	

} PACK_STRUCT;

//! TMD format object information
struct Object_TMD //! 28 bytes
{
	uint32_t vert_top; //*
	uint32_t n_vert;
	uint32_t normal_top; //*
	uint32_t n_normal;
	uint32_t primitive_top; //*
	uint32_t n_primitive;
	int32_t scale;
};

enum //too many compilers whine about the multi-char spec
{
	vert = 1, norm, prim //[f]ourcc codes not part of PlayStation spec
};

//! TMD format header information
struct Header_TMD //! 12 bytes
{
	uint32_t id;
	uint32_t flags; 
	uint32_t nobj;
	
	//! this is the actual order of the data blocks in the file
	inline int offset(int fourcc, int obj=0)const
	{
		switch(fourcc) 
		{		
		case Psx::vert: return 12+AI_BE(obj_table[obj].vert_top);
		case Psx::norm: return 12+AI_BE(obj_table[obj].normal_top);
		case Psx::prim: return 12+AI_BE(obj_table[obj].primitive_top);

		default: return 0x7FFFFFFF;
		}
	}

	Object_TMD obj_table[AI_N(24)] PACK_STRUCT;

} PACK_STRUCT;

} // end namespace Psx

#include "./../include/Compiler/poppack1.h"

class PsxHelper
{
	friend class SomHelper; //MaterialMatrix

public:

	int som_not_processing;
	int sp_gen_connectivity;

	bool header(const Psx::Header_TMD*)const;

	//! The addressing is not in PlayStation word based but in bytes!
	const int8_t *offset(const Psx::Header_TMD*, int fourcc, int objnum=0)const;

	bool packet(const Psx::Header_TMD*,
				const Psx::Packet_TMD**, int fourcc, int objnum=0)const;

	//! Automatic pointer casting templates

	template<typename t>
	inline const t *offset(const Psx::Header_TMD* in, const t** out, int fourcc, int part=0)const
	{		
		const t *off = (const t*)offset(in,fourcc,part); if(out) *out = off; return off;
	}
	template<typename t>
	inline bool packet(const Psx::Header_TMD* in, const t** p, int fourcc, int part=0)const
	{		
		return packet(in,(const Psx::Packet_TMD**)p,fourcc,part);
	}	   

	PsxHelper(const void* eof, aiScene* out = NULL, Assimp::IOSystem *io=NULL);

	~PsxHelper(); //flushes pScene

	//static: avoid construction of quite large helper
	static void CheckEof(const void *eof, const void* szPos);
	static void CheckEof(const void *eof, const void* szPos, const char* szFile, unsigned int iLine);

	inline void CheckEof(const void* szPos)const
	{
		CheckEof(pcEof,szPos);
	}
	inline void CheckEof(const void* szPos, const char* szFile, unsigned int iLine)const
	{
		CheckEof(pcEof,szPos,szFile,iLine);
	}

private:
	
	Assimp::IOSystem *pIo;

	mutable aiScene *pScene; 

	mutable Assimp::ComplexScene *pScene2; 

	const void* pcEof;

	inline bool Warning(const char *w)const
	{
		if(pScene) DefaultLogger::get()->warn(w); return false;
	}
	inline bool Warning(const std::string &w)const
	{
		if(pScene) DefaultLogger::get()->warn(w.c_str()); return false;
	}

	static const float xinvert;
	static const float yinvert;
	static const float zinvert;

	//triangle order
	static inline unsigned int T(unsigned int i)
	{
		//want to be reversible
		//switch(i){ case 0: return 1; case 1: return 0; } return i;
		return 2-i;
	}
	//quadrangle order
	static inline unsigned int Q(unsigned int i)
	{
		/*3-1 should work but it's not. I don't know, maybe TMD quads
		//are ordered unusually?
		//matching T (may break?)
		//switch(i){ case 0: return 1; case 1: return 0; } return i;
		return 3-i;*/
		return i<=1?!i:i;
	}

	mutable uint8_t mUCache[256], mVCache[256];

	unsigned int UV(uint16_t)const;

	//returns UV count and clears cache
	unsigned int UVs()const;

	mutable aiVector3D *pTmpUVs;
	mutable unsigned int nTmpUVs;

	mutable uint16_t mRGCache[256];
	mutable uint8_t mBCache[256];

	unsigned int RGB(uint32_t)const;

	//returns RGB count and clears cache
	unsigned int RGBs()const;

	mutable aiColor4D *pTmpRGBs;
	mutable unsigned int nTmpRGBs;

	struct MaterialMatrix
	{
		struct //TexturePageNumber
		{
			//00    50%back + 50%polygon
			//01   100%back + 100%polygon
			//10   100%back - 100%polygon
			//11   100%back + 25%polygon
			struct //SemiTransparency
			{
				unsigned int lgt[3]; //flat/gouraud/unlit

			}abr[5]; //4: non transparent

		}tpn[33]; //32: non-textured

		//specification for TMD primitive packets
		inline unsigned int &tmd(uint16_t modeflag, uint16_t tsb=0)		
		{
			//assert(0); //report: 0xF to 0x3
			//0x400: TME (texture present) 0x200: ABE (transparent) 0x100: TGE (lit: ignoring LGT)  
			//return tpn[modeflag&0x400?tsb>>7&0x1F:32].abr[modeflag&0x200?tsb>>3&0xF:4].lgt[modeflag&0x100?2:modeflag>>12&1];
			//TPN seems wrong?
			//return tpn[modeflag&0x400?tsb>>7&0x1F:32].abr[modeflag&0x200?tsb>>3&0x3:4].lgt[modeflag&0x100?2:modeflag>>12&1];
			return tpn[modeflag&0x400?tsb&0x1F:32].abr[modeflag&0x200?tsb>>5&0x3:4].lgt[modeflag&0x100?2:modeflag>>12&1];
		}
	};
	
	mutable MaterialMatrix mMaterialMatrix; //1485 bytes 

	//Acquire a material index (assuming TMD compatible)
	inline unsigned int N(uint16_t modeflag, uint16_t tsb=0)const 
	{
		unsigned int &out = mMaterialMatrix.tmd(modeflag,tsb);

		if(!out) out = 1+pScene2->mNumMaterials++; return out-1;
	}
};

aiTexture *PsxTexture(const Psx::Header_TIM*); 

} // end namespace Assimp

#endif // ! AI_PSXHELPER_H_IN