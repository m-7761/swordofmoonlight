/*
---------------------------------------------------------------------------
Open Asset Import Library (ASSIMP)
---------------------------------------------------------------------------

Copyright (c) 2006-2008, ASSIMP Development Team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/

/** @file Implementation of the Playstation helper routines */

#include "AssimpPCH.h"	   
#ifndef ASSIMP_BUILD_NO_PLAYSTATION_IMPORTER

#include "ComplexScene.h"

// internal headers

#include "PsxLoader.h"
#include "PsxHelper.h" 

typedef int aiBool; //assimp.h

using namespace Assimp;

// --------------------------------------------------------------------------------------
// Include file/line information in debug builds
#ifdef ASSIMP_BUILD_DEBUG
#define _CHECK_EOF(pos) CheckEof(pos,__FILE__,__LINE__)
#else
#define _CHECK_EOF(pos) CheckEof(pos)
#endif

// ------------------------------------------------------------------------------------------------
// Constructor to be privately used by Importer
PsxImporter::PsxImporter()
{
	som_not_processing = sp_gen_connectivity = 0;
}

// ------------------------------------------------------------------------------------------------
// Destructor, private as well 
PsxImporter::~PsxImporter()
{

}

// ------------------------------------------------------------------------------------------------
// Returns whether the class can handle the format of the given file. 
bool PsxImporter::CanRead( const std::string& pFile, IOSystem* pIOHandler, bool checkSig) const
{
	const std::string extension = GetExtension(pFile);

	if (extension == "tmd" ) return true; //unacceptable

	return false;
}
// ------------------------------------------------------------------------------------------------
// Setup configuration properties
void PsxImporter::SetupProperties(const Importer* pImp)
{
	som_not_processing = pImp->GetPropertyInteger("SOM_NOT_POSTPROCESSING",0);

	sp_gen_connectivity = pImp->GetPropertyInteger("SP_GEN_CONNECTIVITY",0);
}

// ------------------------------------------------------------------------------------------------
// Get a list of all supported extensions
void PsxImporter::GetExtensionList(std::set<std::string>& extensions)
{
	extensions.insert( "tmd" );
}

// ------------------------------------------------------------------------------------------------
// Imports the given file into the given scene structure. 
void PsxImporter::InternReadFile( const std::string& pFile, 
	aiScene* _pScene, IOSystem* _pIOHandler)
{
	pScene     = _pScene;
	pIOHandler = _pIOHandler;
	boost::scoped_ptr<IOStream> file( pIOHandler->Open( pFile));

	// Check whether we can read from the file
	if( file.get() == NULL) {
		throw DeadlyImportError( "Failed to open PlayStation TMD file " + pFile + ".");
	}

	iFileSize = (unsigned int)file->FileSize();

	// Allocate storage and copy the contents of the file to a memory buffer
	std::vector<unsigned char> buffer(iFileSize+1);
	mBuffer = &buffer[0];
	file->Read( (void*)mBuffer, 1, iFileSize);

	// Append a binary zero to the end of the buffer.
	// this is just for safety that string parsing routines
	// find the end of the buffer ...
	mBuffer[iFileSize] = '\0';

	// Determine the file type and call the appropriate member function

	if(DetectFormat_TMD()) 
	{
		DefaultLogger::get()->debug("PlayStation TMD format detected");
		
		InternReadFile_TMD(); 
		
/*		//Comment: the following changes are now baked into the vertex positions.
			
		if(pScene->mRootNode!=NULL) 
		{
			aiMatrix4x4 o; //From PlayStation
			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationZ(AI_MATH_PI,o);
			pScene->mRootNode->mTransformation*=aiMatrix4x4::RotationY(AI_MATH_PI,o);
		}
*/	}
	else	
	{
		// print the magic word to the log file
		throw DeadlyImportError("Unknown PlayStation format "+pFile);
	}

	// delete the file buffer and cleanup
	AI_DEBUG_INVALIDATE_PTR(mBuffer);
	AI_DEBUG_INVALIDATE_PTR(pIOHandler);
	AI_DEBUG_INVALIDATE_PTR(pScene);
}

// ------------------------------------------------------------------------------------------------
// Check whether we're still inside the valid file range
void PsxImporter::CheckEof(const void* szPos)const
{
	if(!szPos||(const unsigned char*)szPos>mBuffer+iFileSize)
	{
		throw DeadlyImportError("Invalid PlayStation file. The file is too small or contains invalid data");
	}
}

// ------------------------------------------------------------------------------------------------
// Just for debgging purdiffs
void PsxImporter::CheckEof(const void* szPos, const char* szFile, unsigned int iLine)const
{
	return PsxHelper::CheckEof(mBuffer+iFileSize,szPos,szFile,iLine);
}

void PsxImporter::InternReadFile_TMD()
{
	const Psx::Header_TMD* pcHeader = 
		(const Psx::Header_TMD*)mBuffer; 

	PsxHelper Psx(mBuffer+iFileSize,pScene,pIOHandler);

	Psx.som_not_processing = som_not_processing;
	Psx.sp_gen_connectivity = sp_gen_connectivity;
		
	Psx.header(pcHeader); ai_assert(pcHeader->nobj>=1);

	const void* szCurrent = mBuffer;

	for(unsigned int i=0;i<pcHeader->nobj;i++)
	{
		//Go ahead and get the primitives out of the way
		_CHECK_EOF(Psx.offset(pcHeader,&szCurrent,Psx::prim,i));

		while(Psx.packet(pcHeader,&szCurrent,Psx::prim,i));

		_CHECK_EOF(Psx.offset(pcHeader,&szCurrent,Psx::vert,i));

		while(Psx.packet(pcHeader,&szCurrent,Psx::vert,i));
		
		_CHECK_EOF(Psx.offset(pcHeader,&szCurrent,Psx::norm,i));

		while(Psx.packet(pcHeader,&szCurrent,Psx::norm,i));
	}	
}

bool PsxImporter::DetectFormat_TMD()
{
	PsxHelper Psx(mBuffer+iFileSize); //dry run

	return Psx.header((const Psx::Header_TMD*)mBuffer); 
}
  
namespace Assimp{ namespace Psx
{
	static void SubmeshNameTMD(unsigned ch, aiString &set);
}}

const float PsxHelper::xinvert = +1;
const float PsxHelper::yinvert = -1;
const float PsxHelper::zinvert = -1;

PsxHelper::PsxHelper(const void *eof, aiScene *out, Assimp::IOSystem *io)
{	
	sp_gen_connectivity = 0;

	pIo = io; sp_gen_connectivity = 0;

	pcEof = eof; pScene = out; 
	
	pScene2 = NULL; if(pScene==NULL) return;

	pScene2 = new ComplexScene(out);
	
	*mUCache = *mVCache = 0; pTmpUVs = 0; nTmpUVs = 0; 

	*mRGCache = *mBCache = 0; pTmpRGBs = 0; nTmpRGBs = 0;

	memset(&mMaterialMatrix,0x00,sizeof(MaterialMatrix));
}

#include "TriangulateProcess.h"
#include "MakeVerboseFormat.h"
typedef struct : public TriangulateProcess
{
friend class PsxHelper;
}Triangulate;
typedef struct : public MakeVerboseFormatProcess
{
friend class PsxHelper;
}Verbosify;

PsxHelper::~PsxHelper()
{		
	if(pScene==NULL) 
	{
		ai_assert(pScene2==NULL); return;
	}
	else if(pScene2==NULL) return;

	if(pTmpUVs) delete [] pTmpUVs;
	if(pTmpRGBs) delete [] pTmpRGBs;

	if(pScene2->SimplifyInto(pScene,sp_gen_connectivity)==NULL) 
	{
		//CAN'T DO IN DESTRUCTOR
		//if(pScene) throw DeadlyImportError("[PlayStation TMD] Importer failure.");
		//I think it's impossible
		ai_assert(pScene);
		
		return;
	}

	aiNode *pRoot = pScene->mRootNode;

	pRoot->mMeshes = new unsigned int[pRoot->mNumMeshes=pScene->mNumMeshes];

	for(unsigned int i=0;i<pScene->mNumMeshes;i++) pRoot->mMeshes[i] = i;
	
	MaterialHelper *pDef = 0, *pMat = 0; 
	
	aiColor4D one(1,1,1,1), _one(-1,-1,-1,1);

	if(pScene->mNumMaterials==0) //should not normally occur!
	{
		pScene->mMaterials = new aiMaterial*[pScene->mNumMaterials=1];

		pScene->mMaterials[0] = pDef = new MaterialHelper;
		
		const int iMode = (int)aiShadingMode_Gouraud; 

		pDef->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);		

		pDef->AddProperty(&one,1,AI_MATKEY_COLOR_AMBIENT);
		pDef->AddProperty(&one,1,AI_MATKEY_COLOR_DIFFUSE);

		aiString name("<assimp provided material>");

		pDef->AddProperty(&name,AI_MATKEY_NAME);
	}
	else pScene->mMaterials = new aiMaterial*[pScene->mNumMaterials];

	if(!pDef)
	for(int i=0;i<33;i++) for(int j=0;j<5;j++) for(int k=0;k<3;k++)
	{
		unsigned int n = mMaterialMatrix.tpn[i].abr[j].lgt[k]; if(!n--) continue;

		pScene->mMaterials[n] = pMat = new MaterialHelper;
			
		int iMode = aiShadingMode_Flat;
		if(k) iMode = k==1?aiShadingMode_Gouraud:aiShadingMode_NoShading;
		pMat->AddProperty(&iMode,1,AI_MATKEY_SHADING_MODEL);
		
		int iBlend = 
		j==0||j==4?aiBlendMode_Default:aiBlendMode_Additive;
		if(j==0||j==3)
		{
			float alpha = j?0.25f:0.5f;
			pMat->AddProperty(&alpha,1,AI_MATKEY_OPACITY);
		}
		pMat->AddProperty(&iBlend,1,AI_MATKEY_BLEND_FUNC);
		pMat->AddProperty(j==2?&_one:&one,1,AI_MATKEY_COLOR_AMBIENT);
		pMat->AddProperty(j==2?&_one:&one,1,AI_MATKEY_COLOR_DIFFUSE);		
		
		char tpn[33]; _itoa(i,tpn,10);
		std::string strname = i==32?"Tex-less":"Tex Pg #";

		if(i<32) strname+=tpn;

		switch(j)
		{
		case 0: strname+=" 50+50"; break;
		case 1: strname+=" 100+100"; break;

		/*Subtractive?
		*+  DestColor*1 - SourceColor*1
		*/
		case 2: strname+=" 100-100"; break;

		/*aiBlendMode_Additive
		*+  SourceColor*SourceAlpha + DestColor*1
		*/
		case 3: strname+=" 100+25"; break;
		}

		switch(k)
		{
		case 0: strname+=" Flat"; break;
		case 1: strname+=" Gouraud"; break;
		case 2: strname+=" Unlit"; break;
		}

		strname+=" Mat";

		aiString name(strname);
		pMat->AddProperty(&name,AI_MATKEY_NAME);	
	}

	if(!som_not_processing)
	{
		//7/23/2011 This is still required
		//"aiMesh::mVertices[%i] is referenced twice - second time by aiMesh::mFaces[%i]::mIndices[%i]"
		Triangulate T; T.Execute(pScene);
		Verbosify V; V.Execute(pScene);
	}
}									   

// ------------------------------------------------------------------------------------------------
// Check whether we're still inside the valid file range
void PsxHelper::CheckEof(const void *eof, const void* szPos) //static
{
	if(!szPos||(const unsigned char*)szPos>eof)
	{
		throw DeadlyImportError("Invalid PlayStation file. The file is too small or contains invalid data");
	}
}		

// ------------------------------------------------------------------------------------------------
// Just for debgging purdiffs
void PsxHelper::CheckEof(const void *eof, const void* szPos, const char* szFile, unsigned int iLine) //static
{
	ai_assert(eof!=NULL);

	if(!szPos||(const unsigned char*)szPos>eof)
	{
		// remove a directory if there is one
		const char* szFilePtr = ::strrchr(szFile,'\\');
		if (!szFilePtr)	{
			if(!(szFilePtr = ::strrchr(szFile,'/')))
				szFilePtr = szFile;
		}
		if (szFilePtr)++szFilePtr;
						  
		char szBuffer[1024];
		::sprintf(szBuffer,"Invalid PlayStation file. The file is too small "
			"or contains invalid data (File: %s Line: %i)",szFilePtr,iLine);

		throw DeadlyImportError(szBuffer);
	}
}		

bool PsxHelper::header(const Psx::Header_TMD *in)const
{
	if(!in||in->id!=0x41) return false;

	ai_assert(pcEof!=NULL);

	if(!AI_BE(in->nobj))
	{	
		if(pScene) throw DeadlyImportError("[PlayStation TMD] A TMD must contain at least one model");

		return false;
	}

	if(!pScene) return true;

	ai_assert(pScene2->mNumMeshes==0);

	//1: shared mesh
	pScene2->mNumMeshes = AI_BE(in->nobj);

	pScene2->mMeshes2 = new ComplexMesh*[pScene2->mNumMeshes]; 

	memset(pScene2->mMeshes2,0x00,sizeof(void*)*pScene2->mNumMeshes);
		
	//temporary: scheduled obsolete
	pScene2->mRootNode = new aiNode("<assimp_scene_root>");

	return true; 
}

const int8_t *PsxHelper::offset(const Psx::Header_TMD *in, int cc, int pt)const
{		
	return (const int8_t*)(in?(const int8_t*)in+in->offset(cc,pt):NULL);
}

unsigned int PsxHelper::UV(uint16_t in)const
{ 
	uint8_t u = in&0xFF, v = 0xFF&(in>>8);

	for(int i=*mVCache!=0?255:*mUCache;i!=0;i--) 
		if(mUCache[i]==u&&mVCache[i]==v) 
			if(i<=*mUCache) return 255UL**mVCache+i-1;
				else return 255UL**mVCache-255+i-1;

	if(mUCache[0]++==255) 
		{ *mVCache+=1; *mUCache = 1; }

	mUCache[*mUCache] = u; mVCache[*mUCache] = v;

	return 255UL**mVCache+*mUCache-1;
}

unsigned int PsxHelper::UVs()const
{ 
	unsigned int iOut = 255UL**mVCache+*mUCache;

	*mUCache = *mVCache = 0; return iOut;
}

unsigned int PsxHelper::RGB(uint32_t in)const
{ 
	uint16_t rg = uint16_t(in&0xFFFF); 
	uint8_t b = uint8_t(0xFF&(in>>16));

	for(int i=*mBCache!=0?255:*mRGCache;i!=0;i--) 
	if(mRGCache[i]==rg&&mBCache[i]==b) 
	if(i<=*mRGCache) return 255UL**mBCache+i-1;
				else return 255UL**mBCache-255+i-1;

	if(mRGCache[0]++==255) 
	{
		*mBCache+=1; *mRGCache = 1; 
	}

	mRGCache[*mRGCache] = rg; mBCache[*mRGCache] = b;

	return 255UL**mBCache+*mRGCache-1;
}

unsigned int PsxHelper::RGBs()const
{ 
	unsigned int iOut = 255UL**mBCache+*mRGCache;

	*mRGCache = *mBCache = 0; return iOut;
}

bool PsxHelper::packet(const Psx::Header_TMD *in, 
					   const Psx::Packet_TMD **inout, int fourcc, int objnum)const
{
	ai_assert(pScene&&pcEof);

	const Psx::Packet_TMD *p = *inout;
		
	pScene2->mFlags2|=AI_SCENE_FLAGS_INCOMPLETE; 

	ai_assert(pScene2!=NULL&&pScene2->mNumMeshes>=objnum);

	ComplexMesh *pMesh = pScene2->mMeshes2[objnum];

	if(pMesh==NULL) switch(fourcc)
	{
	case Psx::prim: case Psx::vert: case Psx::norm:	 		

		pMesh = pScene2->mMeshes2[objnum] = new ComplexMesh;

		Psx::SubmeshNameTMD(objnum,pMesh->mName);

//		pMesh->mPrimitiveTypes = 
//		aiPrimitiveType_TRIANGLE|aiPrimitiveType_POLYGON;

		pMesh->mNumUVComponents[0] = 2;
	}

	switch(fourcc)
	{
	case Psx::prim: //! prim packets block
	{	
		unsigned int iFaces = AI_BE(in->obj_table[objnum].n_primitive);

		if(iFaces==0) return false; //faces absent: empty object??

		ComplexFace *pFace = 
		pMesh->mFaces2 = new ComplexFace[iFaces];

		unsigned int iCoords = 0, iColors = 0;

		int nSkip = 0;

		for(unsigned int i=0;i<iFaces;i++)
		{
			bool bSkipped = false;

			int iHi = AI_BE(p->hi), iLo = AI_BE(p->lo);

			if(iHi&0x8000) iHi|=0x100; //testing: AC patch

			switch(iHi>>8&0x68) //01101000
			{
			case 0x00: //default 
				
				//Unclear what this means

				nSkip++; bSkipped = true; break; 

			case 0x20: //00100000 (triangle)
			case 0x28: //00101000 (quadrangle)
			{	
				//PSX doc names for these flags
				//q: <unnamed>
				//lit: !lgt 
				//grad: grd
				//tex: tme
				//tint: !tge
				//flat: !iip

				//Lost in translation???
				//in practice the lit flag seems 
				//to be tied to the tint flag, and
				//the tint flag actually determines 
				//if the packet is lit (has normals)
				//or not!?

				aiBool q = iHi&0x800, //quad
				lit = !(iHi&1), grad = iHi&4, 
				tex = iHi&0x400, tint = !(iHi&0x100), 
								  flat = !(iHi&0x1000);
				int paranoia = 0;

				pFace->mNumIndices = 2; //face normal/color

				//UVs - Clr - Nrm - Vtx (order of packet data)

				if(tex) //texcoords
				{	
					iCoords+=q?4:3; paranoia+=q?16:12;

					pFace->mNumIndices+=q?4:3; 
				}

				if(!grad) //face color
				{
					if(!tex||!tint) //!lit
					{
						//Logic:
						//unlit/untextured 
						//primitives need some color

						iColors+=1; paranoia+=4;

						pFace->mNumIndices++; 
					}
				}
				else //vertex color
				{
					iColors+=q?4:3; paranoia+=q?16:12;

					pFace->mNumIndices+=q?4:3; 
				}
								
				//normal/vertex data is interleaved

				if(!flat&&tint) //lit
				{
					paranoia+=q?8:4; 

					pFace->mNumIndices+=q?4:3; //vertex normals
				}
				else if(flat&&tint) //lit
				{
					paranoia+=q?4:0; //face normal mandatory
				}

				pFace->mNumIndices+=q?4:3;
				
				paranoia+=8; //vertices

				if(paranoia==p->v*4) break;

				//HACK: FALLING THRU FOR NOW
			}
			case 0x40: //01000000 (line) 

				//FALLING THRU FOR NOW

			case 0x60: 
			case 0x68://0110?000 (sprite)			 

				//FALLING THRU FOR NOW

				//debugging
				nSkip++; bSkipped = true; break; 

			default: ai_assert(0); 
			{
				char szHi[33]; _itoa(iHi,szHi,16);

				return Warning("PlayStation TMD unrecognized prim packet code "+std::string(szHi)+". Block left incomplete");
			}
			} //end switch			 

			if(!bSkipped) pFace++;

			p+=1+p->v;
		}

		if(iCoords>nTmpUVs)
		{
			if(pTmpUVs) delete [] pTmpUVs;

			pTmpUVs = new aiVector3D[nTmpUVs=iCoords];
		}

		if(iColors>nTmpRGBs)
		{
			if(pTmpRGBs) delete [] pTmpRGBs;

			pTmpRGBs = new aiColor4D[nTmpRGBs=iColors];
		}

		p = *inout; //roll back for second pass			

		pFace = pMesh->mFaces2;

		for(unsigned int i=0;i<iFaces;i++)
		{		
			bool bSkipped = false;

			int iHi = AI_BE(p->hi), iLo = AI_BE(p->lo);

			if(iHi&0x8000) iHi|=0x100; //testing: AC patch

			switch(iHi>>8&0x68) //01101000
			{
			case 0x00: //default
				
				bSkipped = true; break; 

			case 0x20: //00100000 (triangle)
			case 0x28: //00101000 (quadrangle)
			{			
				//Lost in translation???
				//in practice the lit flag seems 
				//to be tied to the tint flag, and
				//the tint flag actually determines 
				//if the packet is lit (has normals)
				//or not!?

				aiBool q = iHi&0x800, //quad
				lit = !(iHi&1), grad = iHi&4, 
				tex = iHi&0x400, tint = !(iHi&0x100),
								  flat = !(iHi&0x1000);
				int paranoia = 0;

				pFace->mStride = 1;
				pFace->mIndices = new unsigned int[pFace->mNumIndices];
				pFace->mNumCorners = q?4:3;

				pFace->mMaterialIndex = N(iHi,AI_BE(tex?p[2].hi:0)); //tsb

				if(iHi&2) pFace->mFaceFeatures|=aiFaceFeature_TWOSIDED;

				//UVs - Clr - Nrm - Vtx (order of packet data)

				const Psx::Packet_TMD *cp = p+1; int ci = 2; //current index

				if(tex) //texcoords
				{	
					pFace->mTextureCoords = ci;

					for(int j=0;j<(q?4:3);j++,cp++)
					pTmpUVs[pFace->mIndices[ci+(q?Q(j):T(j))]=UV(cp->lo)] = 
						aiVector3D(cp->u,cp->v,0.0f); 

					ci+=q?4:3; paranoia+=q?16:12;
				}

				if(!grad) //face color
				{
					if(!tex||!tint) //!lit 
					{
						//Logic:
						//unlit/untextured 
						//primitives need some color

						pFace->mFaceFeatures|=aiFaceFeature_COLOR;

						pTmpRGBs[pFace->mIndices[1]=RGB(*cp)] = 
							aiColor4D(cp->r,cp->g,cp->b,255)/255.0f; 
						
						ci++; cp++; paranoia+=4; 
					}
				}
				else //vertex color
				{
					pFace->mColors = ci;

					for(int j=0;j<(q?4:3);j++,cp++)
					pTmpRGBs[pFace->mIndices[ci+(q?Q(j):T(j))]=RGB(*cp)] = 
						aiColor4D(cp->r,cp->g,cp->b,255)/255.0f; 
					
					ci+=q?4:3; paranoia+=q?16:12;
				}
							
				//normal/vertex data is interleaved

				if(!flat&&tint) //lit
				{	
					paranoia+=q?8:4; //vertex normals

					int ni = pFace->mNormals = ci;
					int vi = pFace->mVertices = ci+(q?4:3);
					pFace->mIndices[ni+(q?Q(0):T(0))] = AI_BE(cp->lo); 
					pFace->mIndices[vi+(q?Q(0):T(0))] = AI_BE(cp->hi); cp++;
					pFace->mIndices[ni+(q?Q(1):T(1))] = AI_BE(cp->lo); 
					pFace->mIndices[vi+(q?Q(1):T(1))] = AI_BE(cp->hi); cp++; 
					pFace->mIndices[ni+(q?Q(2):T(2))] = AI_BE(cp->lo); 
					pFace->mIndices[vi+(q?Q(2):T(2))] = AI_BE(cp->hi); cp++;

					if(q) pFace->mIndices[ni+Q(3)] = AI_BE(cp->lo); 
					if(q) pFace->mIndices[vi+Q(3)] = AI_BE(cp->hi), cp++;					

					ci+=q?8:6;
				}
				else if(flat&&tint) //lit
				{	
					paranoia+=q?4:0; //face normal only

					pFace->mFaceFeatures|=aiFaceFeature_NORMAL;

					pFace->mIndices[0] = AI_BE(cp->lo); //0 reserved for face normal 
										
					pFace->mVertices = ci;
					pFace->mIndices[ci+(q?Q(0):T(0))] = AI_BE(cp->hi); cp++;
					pFace->mIndices[ci+(q?Q(1):T(1))] = AI_BE(cp->lo); 
					pFace->mIndices[ci+(q?Q(2):T(2))] = AI_BE(cp->hi); cp++;

					if(q) pFace->mIndices[ci+Q(3)] = AI_BE(cp->lo), cp++;

					ci+=q?4:3;
				}
				else //vertices only (unlit)
				{								
					pFace->mVertices = ci;
					pFace->mIndices[ci+(q?Q(0):T(0))] = AI_BE(cp->lo); 
					pFace->mIndices[ci+(q?Q(1):T(1))] = AI_BE(cp->hi); cp++;
					pFace->mIndices[ci+(q?Q(2):T(2))] = AI_BE(cp->lo); 
					
					if(q) pFace->mIndices[ci+Q(3)] = AI_BE(cp->hi); cp++;

					ci+=q?4:3;
				}
				
				paranoia+=8; //vertices

				if(cp-p!=1+p->v||ci!=pFace->mNumIndices)
				{
					ai_assert(0);

					char szHi[] = "        "; _itoa(iHi,szHi,16);

					return Warning("PlayStation TMD mishandled prim packet code "+std::string(szHi)+". Block left incomplete");
				}

				if(paranoia==p->v*4) break;

				//HACK: FALLING THRU FOR NOW
			}
			case 0x40: //01000000 (line) 

				//FALLING THRU FOR NOW

			case 0x60: 
			case 0x68://0110?000 (sprite)			 

				//FALLING THRU FOR NOW
		
				//debugging
				nSkip++; bSkipped = true; break; 

			default: ai_assert(0); 
			{
				//second pass: should never get here unless passes are asymmetric

				ai_assert(0);

				char szHi[] = "        "; _itoa(iHi,szHi,16);

				return Warning("PlayStation TMD unrecognized prim packet code "+std::string(szHi)+". Block left incomplete");
			}
			} //end switch			 

			if(!bSkipped) pMesh->mNumFaces++, pFace++;

			p+=1+p->v;
		}

		pMesh->mNumTextureCoords = UVs();

		if(pMesh->mNumTextureCoords)
		{
			pMesh->mTextureCoords[0] = new aiVector3D[pMesh->mNumTextureCoords];
			
			//2022: In practice textures are atlased into the texture pages
			//In my case an awful lot divide the page into four quadrants so
			//it helps when decomposing them into non-atlased textures if each
			//quadrant falls into the 0-1 range of modern texture mapping
			//Of course this is an arbitrary guess to hopefully reduce work in
			//striking a balance (each quadrant is a 128x128 pixel image)
			//float x = 0.003921568627f; //1/255
			float x = 0.007843137254f; //1/255*2

			//2018
			//255 isn't technically correct, but edge sampling side-by-side
			//won't work otherwise. (On the PlayStation 255 surely sampled 
			//the last pixel, but if it doesn't hit the edge, two polygons
			//edge-to-edge will not be filtered correctly. The PlayStation 
			//did not filter textures.)
			for(int i=0,iN=pMesh->mNumTextureCoords;i<iN;i++)
			{
				pTmpUVs[i].x*=x; 
				//precision errors
				//pTmpUVs[i].y = 1-pTmpUVs[i].y/255;
				pTmpUVs[i].y = float(255-(int)pTmpUVs[i].y)*x;
			}

			memcpy(pMesh->mTextureCoords[0],pTmpUVs,sizeof(aiVector3D)*pMesh->mNumTextureCoords);
		}

		pMesh->mNumColors = RGBs();

		if(pMesh->mNumColors)
		{
			pMesh->mColors[0] = new aiColor4D[pMesh->mNumColors];

			memcpy(pMesh->mColors[0],pTmpRGBs,sizeof(aiColor4D)*pMesh->mNumColors);
		}

		break;		
	}
	case Psx::vert: //! vertex packets block
	{	
		int iVerts = AI_BE(in->obj_table[objnum].n_vert);

		if(iVerts==0) return false; //vertices absent
				
		_CHECK_EOF((const char*)p+iVerts*8); //expected end of block

		pMesh->mVertices = new aiVector3D[pMesh->mNumVertices=iVerts];

		for(int i=0;i<iVerts;i++)
		{
			//ai_assert(p[1].hi==0);

			//TODO: correction option via object scale value
			pMesh->mVertices[i].x = xinvert*int16_t(AI_BE(p->lo));
			pMesh->mVertices[i].y = yinvert*int16_t(AI_BE(p->hi)); p++;
			pMesh->mVertices[i].z = zinvert*int16_t(AI_BE(p->lo)); p++;
		}

		break;
	}
	case Psx::norm: //! normal packets block
	{	
		int iNorms = AI_BE(in->obj_table[objnum].n_normal);

		if(iNorms==0) return false; //normals absent

		_CHECK_EOF((const char*)p+iNorms*8); //expected end of block

		pMesh->mNormals = new aiVector3D[pMesh->mNumNormals=iNorms];

		for(int i=0;i<iNorms;i++)
		{	
			//ai_assert(p[1].hi==0);

			pMesh->mNormals[i].x = xinvert*int16_t(AI_BE(p->lo));
			pMesh->mNormals[i].y = yinvert*int16_t(AI_BE(p->hi)); p++;			
			pMesh->mNormals[i].z = zinvert*int16_t(AI_BE(p->lo)); p++;
			
			pMesh->mNormals[i]/=4096.0f; //.Normalize();
		}

		break;
	}
	default: return false;
	} 

	pScene2->mFlags2&=~AI_SCENE_FLAGS_INCOMPLETE; 

	*inout = p; return false;
}
 
static void Psx::SubmeshNameTMD(unsigned pc, aiString &set)
{
	char sz[] = "<Obj id00000>"; 
	
	sprintf(sz,"<Obj id%d>",pc+1);

	set = sz;
}						 

static void TIMpixelmode2(aiTexel *inout, uint16_t pm2)
{
	//! 0xFF&() added in order to precent an MSVC runtime check

	inout->r = 0xFF&((pm2&0x001F)*8+7); inout->g = 0xFF&(((pm2&0x03E0)>>5)*8+7); 
			
	inout->b = 0xFF&(((pm2&0x7C00)>>10)*8+7); inout->a = 255;
}

//Won't link without Assimp:: ???
aiTexture *Assimp::PsxTexture(const Psx::Header_TIM *pIn) //PsxHelper.h
{
	if(!pIn||pIn->id!=0x10) return 0; //TIM signature 

	const Psx::Header_TIM::Clut *clut = pIn->clut_block();
	const Psx::Header_TIM::Data *data = pIn->data_block();
		
	float fWidth = AI_BE(data->w);

	switch(pIn->pmode)
	{
	case 0x00: fWidth*=4.0f; break;
	case 0x01: fWidth*=2.0f; break;
	case 0x02:               break;
	case 0x03:
	case 0x04: fWidth = fWidth/3.0f*2.0f;
	}
	
	if(fWidth-int(fWidth)!=0.0f) return 0; //maybe not a TIM texture
	
	if(pIn->pmode==0x04) return 0; //"mixed mode" (cannot help this)

	aiTexture *pOut = new aiTexture;

	pOut->mWidth = (unsigned int)fWidth; pOut->mHeight = AI_BE(data->h);

	aiTexel *d = pOut->pcData = new aiTexel[pOut->mWidth*pOut->mHeight];
		
	int h = AI_BE(data->h), w = AI_BE(data->w);

	for(int i=0;i<h;i++) for(int j=0;j<w;j++) 
	{
		uint16_t e = data->data[i*w+j]; AI_SWAP2(e);

		switch(pIn->pmode)
		{
		case 0x00:
			
			if(clut) 
			{
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0x000F)>>0])); 
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0x00F0)>>4])); 
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0x0F00)>>8])); 
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0xF000)>>12])); 
			}
			else //output gray scale visualization?
			{
				TIMpixelmode2(d++,(e&0x000F)>>0); 
				TIMpixelmode2(d++,(e&0x00F0)>>4); 
				TIMpixelmode2(d++,(e&0x0F00)>>8); 
				TIMpixelmode2(d++,(e&0xF000)>>12); 
			}

			break;

		case 0x01: 
			
			if(clut) 
			{
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0x00FF)>>0])); 
				TIMpixelmode2(d++,AI_BE(clut->clut[(e&0xFF00)>>8])); 
			}
			else //output gray scale visualization?
			{
				TIMpixelmode2(d++,(e&0x00FF)>>0); 
				TIMpixelmode2(d++,(e&0xFF00)>>8); 
			}
			
			break;

		case 0x02: TIMpixelmode2(d++,e); break;

		case 0x03: case 0x04: j++; //3 and 4??? 
			
			d->r = e&0xFF; d->g = (e&0xFF00)>>8;

			e = data->data[i*w+j]; AI_SWAP2(e);

			d->b = e&0xFF; d->a = 255; 
				
			d++; j++;
				
			d->r = (e&0xFF00)>>8; 

			e = data->data[i*w+j]; AI_SWAP2(e);

			d->g = e&0xFF; d->b = (e&0xFF00)>>8; d->a = 255; 
		
			d++; break;
		}
	}

	return pOut;
}

#endif //ASSIMP_BUILD_NO_PLAYSTATION_IMPORTER