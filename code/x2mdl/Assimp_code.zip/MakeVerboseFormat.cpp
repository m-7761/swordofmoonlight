/*
---------------------------------------------------------------------------
Open Asset Import Library (ASSIMP)
---------------------------------------------------------------------------

Copyright (c) 2006-2010, ASSIMP Development Team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the ASSIMP team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the ASSIMP Development Team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
*/
/** @file Implementation of the post processing step "MakeVerboseFormat"
*/

#include "AssimpPCH.h"
#include "MakeVerboseFormat.h"

using namespace Assimp;

// ------------------------------------------------------------------------------------------------
MakeVerboseFormatProcess::MakeVerboseFormatProcess()
{
	// nothing to do here
}
// ------------------------------------------------------------------------------------------------
MakeVerboseFormatProcess::~MakeVerboseFormatProcess()
{
	// nothing to do here
}
// ------------------------------------------------------------------------------------------------
// Executes the post processing step on the given imported data.
void MakeVerboseFormatProcess::Execute( aiScene* pScene)
{
	ai_assert(NULL != pScene);
	DefaultLogger::get()->debug("MakeVerboseFormatProcess begin");

	bool bHas = false;
	for( unsigned int a = 0; a < pScene->mNumMeshes; a++)
	{
		if(	MakeVerboseFormat( pScene->mMeshes[a]))
			bHas = true;
	}
	if (bHas) DefaultLogger::get()->info("MakeVerboseFormatProcess finished. There was much work to do ...");
	else DefaultLogger::get()->debug("MakeVerboseFormatProcess. There was nothing to do.");

	pScene->mFlags &= ~AI_SCENE_FLAGS_NON_VERBOSE_FORMAT;
}
template<class T>
static bool MakeVerboseFormat_MakeVerboseFormat(aiMesh* pcMesh, T *pcMesh2)
{
	ai_assert(NULL != pcMesh&&NULL != pcMesh2);
	ai_assert(pcMesh2->mNumVertices==pcMesh->mNumVertices);

	unsigned int iOldNumVertices = pcMesh2->mNumVertices;
	const unsigned int iNumVerts = pcMesh->mNumFaces*3;

	aiVector3D* pvPositions = new aiVector3D[ iNumVerts ];

	aiVector3D* pvNormals = NULL;
	if (pcMesh2->HasNormals()) 
	{
		pvNormals = new aiVector3D[iNumVerts];
	}
	aiVector3D* pvTangents = NULL, *pvBitangents = NULL;
	if (pcMesh2->HasTangentsAndBitangents()) 
	{
		pvTangents = new aiVector3D[iNumVerts];
		pvBitangents = new aiVector3D[iNumVerts];
	}

	aiVector3D* apvTextureCoords[AI_MAX_NUMBER_OF_TEXTURECOORDS] = {0};
	aiColor4D* apvColorSets[AI_MAX_NUMBER_OF_COLOR_SETS] = {0};

	unsigned int p = 0;
	while (pcMesh2->HasTextureCoords(p))
		apvTextureCoords[p++] = new aiVector3D[iNumVerts];

	p = 0;
	while (pcMesh2->HasVertexColors(p))
		apvColorSets[p++] = new aiColor4D[iNumVerts];

	std::vector<aiVertexWeight>* newWeights; if(pcMesh==(void*)pcMesh2)
	{
		// allocate enough memory to hold output bones and vertex weights ...
		newWeights = new std::vector<aiVertexWeight>[pcMesh->mNumBones];
		for (unsigned int i = 0;i < pcMesh->mNumBones;++i) {
			newWeights[i].reserve(pcMesh->mBones[i]->mNumWeights*3);
		}
	}

	// iterate through all faces and build a clean list
	unsigned int iIndex = 0;
	for (unsigned int a = 0; a< pcMesh->mNumFaces;++a)
	{
		aiFace* pcFace = &pcMesh->mFaces[a];
		for (unsigned int q = 0; q < pcFace->mNumIndices;++q,++iIndex)
		{	
			unsigned int qIndex = pcFace->mIndices[q];

			pvPositions[iIndex] = pcMesh2->mVertices[qIndex];

			if (pcMesh2->HasNormals()) 
			{
				pvNormals[iIndex] = pcMesh2->mNormals[qIndex];
			}
			if (pcMesh2->HasTangentsAndBitangents()) 
			{
				pvTangents[iIndex] = pcMesh2->mTangents[qIndex];
				pvBitangents[iIndex] = pcMesh2->mBitangents[qIndex];
			}

			unsigned int p = 0;
			while (pcMesh2->HasTextureCoords(p))
			{
				apvTextureCoords[p][iIndex] = pcMesh2->mTextureCoords[p][qIndex];
				++p;
			}
			p = 0;
			while (pcMesh2->HasVertexColors(p))
			{
				apvColorSets[p][iIndex] = pcMesh2->mColors[p][qIndex];
				++p;
			}

			if(pcMesh==(void*)pcMesh2)
			{
				// need to build a clean list of bones, too
				for (unsigned int i = 0;i < pcMesh->mNumBones;++i) 
				{
					for (unsigned int a = 0;  a < pcMesh->mBones[i]->mNumWeights;a++)
					{
						const aiVertexWeight& w = pcMesh->mBones[i]->mWeights[a];
						if(qIndex == w.mVertexId)
						{
							aiVertexWeight wNew;
							wNew.mVertexId = iIndex;
							wNew.mWeight = w.mWeight;
							newWeights[i].push_back(wNew);
						}
					}
				}

				pcFace->mIndices[q] = iIndex; //qIndex
			}
		}
	}

	if(pcMesh==(void*)pcMesh2)
	{
		// build output vertex weights
		for (unsigned int i = 0;i < pcMesh->mNumBones;++i) 
		{
			delete pcMesh->mBones[i]->mWeights;
			if (!newWeights[i].empty())
			{
				pcMesh->mBones[i]->mWeights = new aiVertexWeight[newWeights[i].size()];
				memcpy(pcMesh->mBones[i]->mWeights,&newWeights[i][0],
					sizeof(aiVertexWeight) * newWeights[i].size());
			}
			else pcMesh->mBones[i]->mWeights = NULL;
		}
	}

	// delete the old members
	delete[] pcMesh2->mVertices;
	pcMesh2->mVertices = pvPositions;

	p = 0;
	while (pcMesh2->HasTextureCoords(p))
	{
		delete pcMesh2->mTextureCoords[p];
		pcMesh2->mTextureCoords[p] = apvTextureCoords[p];
		++p;
	}
	p = 0;
	while (pcMesh2->HasVertexColors(p))
	{
		delete pcMesh2->mColors[p];
		pcMesh2->mColors[p] = apvColorSets[p];
		++p;
	}
	pcMesh2->mNumVertices = iNumVerts;

	if (pcMesh2->HasNormals()) 
	{
		delete[] pcMesh2->mNormals;
		pcMesh2->mNormals = pvNormals;
	}
	if (pcMesh2->HasTangentsAndBitangents()) 
	{
		delete[] pcMesh2->mTangents;
		pcMesh2->mTangents = pvTangents;
		delete[] pcMesh2->mBitangents;
		pcMesh2->mBitangents = pvBitangents;
	}
	return (pcMesh2->mNumVertices != iOldNumVertices);
}
// ------------------------------------------------------------------------------------------------
// Executes the post processing step on the given imported data.
bool MakeVerboseFormatProcess::MakeVerboseFormat(aiMesh* pcMesh)
{
	//NOTE: anim-meshes must go first in order to be correct
	for(unsigned i=pcMesh->mNumAnimMeshes;i-->0;)
	if(!MakeVerboseFormat_MakeVerboseFormat(pcMesh,pcMesh->mAnimMeshes[i]))
	return false;
	if(!MakeVerboseFormat_MakeVerboseFormat(pcMesh,pcMesh))
	return false; return true;
}
